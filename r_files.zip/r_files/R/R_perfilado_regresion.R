
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)


###########################
############################


con <- dbConnect(Oracle(), user="expeam", password="!mayo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                                 
            SELECT *
            FROM EXPEAM.TMP_BASE_PERFILADO_CHURN_5
                                 
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
str(df)
dbDisconnect(con)

table(df$CHURN)

# Create Training Data
input_ones <- df[which(df$CHURN == 1), ]  # all 1's
input_zeros <- df[which(df$CHURN == 0), ]  # all 0's
set.seed(100)  # for repeatability of samples
input_ones_training_rows <- sample(1:nrow(input_ones), 0.7*nrow(input_ones))  # 1's for training
input_zeros_training_rows <- sample(1:nrow(input_zeros), 0.7*nrow(input_ones))  # 0's for training. Pick as many 0's as 1's
training_ones <- input_ones[input_ones_training_rows, ]  
training_zeros <- input_zeros[input_zeros_training_rows, ]
trainingData <- rbind(training_ones, training_zeros)  # row bind the 1's and 0's 

remove(df)
remove(df_bkp)

# Create Test Data
test_ones <- input_ones[-input_ones_training_rows, ]
test_zeros <- input_zeros[-input_zeros_training_rows, ]
testData <- rbind(test_ones, test_zeros)  # row bind the 1's and 0's 
head(test_ones)
head(test_zeros)

