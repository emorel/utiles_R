#debug(utils:::unpackPkgZip)
#install.packages('Rmpi')


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!noviembre2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                    /*SELECT r.ar_key as nro_cuenta
                    ,to_char(r.fecha,'yyyy-mm-dd') as fecha_datos
                     ,r.monto
                     FROM rpt_information.compra_paquetes_x_canal r
                     join expeam.tmp_base_compra_pq_notm n
                     on (r.ar_key = n.ar_key)
                     where r.fecha between DATE'2018-05-01' and DATE'2018-10-31'
                     and r.ar_key is not null*/
                     
                      select b.nro_cuenta
                      ,b.fecha_datos
                     ,b.monto
                     ,b.precio
                     from expeam.tmp_base_paquetes_btyd b
                     where b.precio = 3000
                     and b.canal not in ('PRESTAMO')
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
str(df)

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-10-01")


####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 200,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)


##################################
###INSERTAMOS   CUST,LITT #######
#################################

dfinsert<-dfCBS[,c("cust","litt")]

rs <- dbSendQuery(con, "truncate table expeam.TMP_PAQ_REG", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.TMP_PAQ_REG values(:1,:2)", data=dfinsert)

dbCommit(con)



