
library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)

con <- dbConnect(Oracle(), user="expeam", password="!noviembre2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                      b.MSISDN as NRO_CUENTA
                     ,to_char(b.fecha,'yyyy-mm-dd') as fecha_datos
                     ,sum(monto) as monto
                     from expeam.tmp_base_agente_90d a
                     join expeam.v_base_agentes_dms v
                     on (a.agent_id=v.AGENT_ID)
                     JOIN tigo_cash_rpt.base_agente_mfs_daily b
                     on (a.agent_id=b.agent_id)
                     where b.fecha between date'2017-10-01' and date'2018-10-31'
                     and b.MSISDN in
                     (
                     
                         select
                         b.MSISDN
                         from tigo_cash_rpt.base_agente_mfs_daily b
                         where b.fecha between date'2017-10-01' and date'2018-10-31'
                         group by b.MSISDN
                         having count (distinct to_char(b.fecha,'YYYYMM')) >1
                         
                         
                     
                     )
                      GROUP BY
                      b.MSISDN
                     ,to_char(b.fecha,'yyyy-mm-dd')
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
#df<-subset(df, df$NRO_CUENTA %in% sample(df$NRO_CUENTA,50000))

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-08-01")
dfk<-dfCBS

####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 200,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)


str(dfCBS)


##############
###CLUSTER###
#############

dfksc<-scale(dfCBS[-c(1,6,8)])



fit <- kmeans(dfksc, 6, iter.max=3000)

#str(dfk)

dfk$cluster<-as.factor(fit$cluster)
dfkl<-merge(x = df, y = dfk[c(1,11)], by = "cust", all.x = TRUE)

dfCBSkl<-merge(x = dfCBS, y = dfk[c(1,11)], by = "cust", all.x = TRUE)

## Timing Patterns
op <- par(mfrow = c(2, 3))
p1<-plotTimingPatterns(subset(dfkl, cluster==1), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
p2<-plotTimingPatterns(subset(dfkl, cluster==2), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
p3<-plotTimingPatterns(subset(dfkl, cluster==3), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
p4<-plotTimingPatterns(subset(dfkl, cluster==4), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
p5<-plotTimingPatterns(subset(dfkl, cluster==5), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
p6<-plotTimingPatterns(subset(dfkl, cluster==6), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
par(op)

###  BOX Plot Parametros

p1<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
  geom_boxplot()
p2<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
  geom_boxplot()
p3<-ggplot(data = dfk, mapping = aes(x = cluster, y = x)) +
  geom_boxplot()
p4<-ggplot(data = dfk, mapping = aes(x = cluster, y = t.x)) +
  geom_boxplot()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)


## Regularity
op <- par(mfrow = c(2, 3))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==1), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==2), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==3), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==4), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==5), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
par(op)

###cada cuantos dias transaccionan


(nbd.EstimateParameters(subset(dfk,cluster==1))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==1))[1])
(nbd.EstimateParameters(subset(dfk,cluster==2))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==2))[1])
(nbd.EstimateParameters(subset(dfk,cluster==3))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==3))[1])
(nbd.EstimateParameters(subset(dfk,cluster==4))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==4))[1])
(nbd.EstimateParameters(subset(dfk,cluster==5))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==5))[1])
(nbd.EstimateParameters(subset(dfk,cluster==6))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==6))[1])

write.table(dfCBSkl,sep = ";",row.names = FALSE,file = "C:/Users/expeam/Documents/segment/2018/10-octubre/tendencia_ptm/base_ptm_palive.csv")



##Generamos un vector con los mejores clusters

cluster<-unique(fit$cluster)
clust<-NULL
for (i in cluster) {
  if ((k.wheat <- estimateRegularity(subset(dfkl, cluster==i), method = "wheat", title = "Wheat & Morrison")) >1) {
    clust<-c(clust,i)
  }
}

table(fit$cluster)

clust<-c(2)

dfinsert<-subset(dfk[,c("cust","cluster")],cluster %in% clust)

rs <- dbSendQuery(con, "truncate table expeam.base_para_bulk", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.base_para_bulk values(:1,:2)", data=dfinsert)

dbCommit(con)


