library(ROracle)
library(dplyr)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
FINMES = c(
  
  "2016-01-31","2016-02-29","2016-03-31","2016-04-30"
  ,"2016-05-31","2016-06-30","2016-07-31","2016-08-31"
  ,"2016-09-30","2016-10-31","2016-11-30","2016-12-31"
  ,"2017-01-31","2017-02-28","2017-03-31","2017-04-30"
  ,"2017-05-31","2017-06-30","2017-07-31","2017-08-31"
  ,"2017-09-30","2017-10-31","2017-11-30","2017-12-31"
  ,"2018-01-31","2018-02-28"
)

m.mat <- matrix(, nrow = 36, ncol = 3)
i=1
for (MONTH in FINMES){
 
  
  
FECHA_DATOS <- data.frame(FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH))

query <- dbSendQuery(con,"
                     
                     select 
                     count(distinct b.nro_cuenta) as cant_clientes
                     from tigo_cash_rpt.base_cliente_mfs_daily  b
                     where b.fecha_datos between to_date(:1,'YYYY-MM-DD')-30 and to_date(:2,'YYYY-MM-DD')
                     and (/*b.service_id = 5 and b.tipo ='from CARD' or*/ b.service_id = 98)
                     and b.nro_cuenta not in (select f.nro_linea from expeam.funcionarios f)
                     ",data=FECHA_DATOS)

df1 <- fetch(query)

query <- dbSendQuery(con,"
                     
                     select 
                     count(distinct b.nro_cuenta) as cant_clientes
                     from tigo_cash_rpt.base_cliente_mfs_daily  b
                     where b.fecha_datos between to_date(:1,'YYYY-MM-DD')-30 and to_date(:2,'YYYY-MM-DD')
                     and (b.service_id = 5 and b.tipo ='from CARD' /*or b.service_id = 98*/)
                     and b.nro_cuenta not in (select f.nro_linea from expeam.funcionarios f)
                     ",data=FECHA_DATOS)

df2 <- fetch(query)

m.mat[i,1]=df1$CANT_CLIENTES
m.mat[i,2]=df2$CANT_CLIENTES
m.mat[i,3]=MONTH

print(paste(m.mat[i,1]," ",m.mat[i,2]," ",m.mat[i,3]))

i=i+1

}

m.mat

base_30d<-as.data.frame(m.mat)
str(base_30d)

colnames(base_30d)<-c("RETIRO","COMPRA","FECHA")
base_30d<-na.omit(base_30d)
write.csv(base_30d,"base_cc_30d.csv")
