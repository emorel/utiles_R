library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
con<-dbConnect(Oracle(),user="expeam",password="!febrero2018",dbname="DWH")
query<-dbSendQuery(con, "
                   
                   select 
                   b.cant_ptm
                   ,b.circuito
                   ,b.cantidad_num as cant_cliente
                   from  expeam.base_ptm_circ_ci_60d_mensual b
                   ")
result <- fetch(query)
library(readr)
base_para_modelo <- read_delim("segment/2018/cash_out/base_para_modelo.csv", 
                               ";", escape_double = FALSE, 
                               trim_ws = TRUE)

t1<-base_para_modelo
t1<-select(t1,c(monto_carga,cant_trx_carga,base_carga))
t1<-select(t1,c(monto_giro,cant_trx_giro,base_giro))
t1<-select(t1,c(monto_retiro,cant_trx_retiro,base_retiro))
str(t1)
chart.Correlation(t1, histogram=TRUE, pch=19)
linearMod<-lm(monto_retiro~cant_trx_retiro+base_retiro,data = t1)
print(linearMod)
summary(linearMod)
as.formula(
  paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
         paste(sprintf(" %+.2f*%s ", 
                       coefficients(linearMod)[-1],  
                       names(coefficients(linearMod)[-1])), 
               collapse="")
  )
)



t$CANT_PTM<-log(t$CANT_PTM)
t$CANT_CLIENTES<-log(t$CANT_CLIENTES)
t$CANT_CLIENTE<-log(t$CANT_CLIENTES)
t$CANT_CLIENTESS<-log(t$CANT_CLIENTES)

t1$CANT_PTM<-log(t1$CANT_PTM)
t1$CANT_CLIENTE<-log(t1$CANT_CLIENTE)
t1$CIRCUITO <-as.factor(t1$CIRCUITO)

str(t1)


#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)



plot(t)
chart.Correlation(t1, histogram=TRUE, pch=19)
linearMod<-lm(monto_carga~cant_trx_carga+base_carga,data = t1)
print(linearMod)
as.formula(
  paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
         paste(sprintf(" %+.2f*%s ", 
                       coefficients(linearMod)[-1],  
                       names(coefficients(linearMod)[-1])), 
               collapse="")
  )
)


#CANT_CLIENTES=837783.4+(82.1*CANT_PTM)
summary(linearMod)

# outlierKD(t1, ANTIGUEDAD_MESES)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, EDAD)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, REVENUE_PROM_4M)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, RECARGA_PROM_4M)
# yes
# t1<-na.omit(t1)
# 


#tomamos una muestra aleatoria

# t1<-subset(t1,AR_KEY %in% (sample(t1$AR_KEY,1700)))
# summary(t1)




#print(res)
plot(t1)
chart.Correlation(t1, histogram=TRUE, pch=19)
boxplot(t1$CANT_PTM)
boxplot(t1$CANT_CLIENTES)
##buscamos el modelo
linearMod<-lm(CANT_CLIENTE~CANT_PTM+CIRCUITO,data = t1)
print(linearMod)
#CANT_CLIENTES=837783.4+(82.1*CANT_PTM)
summary(linearMod)
#extraemos solo las variables significativas
summary(linearMod)$coef[summary(linearMod)$coef[,4] <= .05, 4]
model.ptm.signif<-data.frame(summary(linearMod)$coef[summary(linearMod)$coef[,4] <= .05, 4])
colnames(model.ptm.signif)<-c("CANT_PTM","CIRCUITO","FECHA")

