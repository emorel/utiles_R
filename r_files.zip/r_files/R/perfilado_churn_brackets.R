
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)

###########################
############################

con <- dbConnect(Oracle(), user="expeam", password="!mayo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
            select * from TMP_BASE_PERFILADO_CHURN_Q t
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)


library(DMwR)
tic()
df <- knnImputation(select(df,-AR_KEY,-CHURN),k=3)
toc()
anyNA(df)



df$AR_KEY <- df_bkp$AR_KEY
df$CHURN <- df_bkp$CHURN

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_BASE_PERFILADO_CHURN2", df, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

options(scipen=999)

#########
####ARPU####
##########
breaks<-quantile(df$ARPU_M1,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$ARPU_M1_SGM<- cut( df$ARPU_M1, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$ARPU_M1_SGM)

breaks<-quantile(df$ARPU_M2,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$ARPU_M2_SGM<- cut( df$ARPU_M2, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$ARPU_M2_SGM)

breaks<-quantile(df$ARPU_M3,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$ARPU_M3_SGM<- cut( df$ARPU_M3, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$ARPU_M3_SGM)


###############
#####PRECIO_MB########
##############

df$PRECIO_MB_M1_RANK <- rank(df$PRECIO_MB_M1, ties.method = "first")
breaks<-quantile(df$PRECIO_MB_M1_RANK,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$PRECIO_MB_M1_SGM<- cut( df$PRECIO_MB_M1, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$PRECIO_MB_M1_SGM)

breaks<-quantile(df$PRECIO_MB_M2,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$PRECIO_MB_M2_SGM<- cut( df$PRECIO_MB_M2, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$PRECIO_MB_M2_SGM)

breaks<-quantile(df$PRECIO_MB_M3,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$PRECIO_MB_M3_SGM<- cut( df$PRECIO_MB_M3, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$PRECIO_MB_M3_SGM)

###############
#####AVG_RECHARGE########
##############

breaks<-quantile(df$AVG_RECHARGE_M1,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$AVG_RECHARGE_M1_SGM<- cut( df$AVG_RECHARGE_M1, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$AVG_RECHARGE_M1_SGM)

breaks<-quantile(df$AVG_RECHARGE_M2,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$AVG_RECHARGE_M2_SGM<- cut( df$AVG_RECHARGE_M2, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$AVG_RECHARGE_M2_SGM)

breaks<-quantile(df$AVG_RECHARGE_M3,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$AVG_RECHARGE_M3_SGM<- cut( df$AVG_RECHARGE_M3, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$AVG_RECHARGE_M3_SGM)


###############
#####MB_FREE########
##############

breaks<-quantile(df$MB_FREE_M1,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$MB_FREE_M1_SGM<- cut( df$MB_FREE_M1, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_FREE_M1_SGM)

breaks<-quantile(df$MB_FREE_M2,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$MB_FREE_M2_SGM<- cut( df$MB_FREE_M2, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_FREE_M2_SGM)

breaks<-quantile(df$MB_FREE_M3,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
df$MB_FREE_M3_SGM<- cut( df$MB_FREE_M3, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_FREE_M3_SGM)

###############
#####MB_BILLED########
##############

df$MB_BILLED_M0_RANK <- rank(df$MB_BILLED_M0, ties.method = "first")
breaks<-quantile(df$MB_BILLED_M0_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df$MB_BILLED_M0_SGM<- cut( df$MB_BILLED_M0_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_BILLED_M0_SGM)


df$MB_BILLED_M1_RANK <- rank(df$MB_BILLED_M1, ties.method = "first")
breaks<-quantile(df$MB_BILLED_M1_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df$MB_BILLED_M1_SGM<- cut( df$MB_BILLED_M1_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_BILLED_M1_SGM)

df$MB_BILLED_M2_RANK <- rank(df$MB_BILLED_M2, ties.method = "first")
breaks<-quantile(df$MB_BILLED_M2_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
df$MB_BILLED_M2_SGM<- cut( df$MB_BILLED_M2_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_BILLED_M2_SGM)

df$MB_BILLED_M3_RANK <- rank(df$MB_BILLED_M3, ties.method = "first")
breaks<-quantile(df$MB_BILLED_M3_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
df$MB_BILLED_M3_SGM<- cut( df$MB_BILLED_M3_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MB_BILLED_M3_SGM)

###############
#####MOU########
##############
df$MOU_M0_RANK <- rank(df$MOU_M0, ties.method = "first")
breaks<-quantile(df$MOU_M0_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df$MOU_M0_SGM<- cut( df$MOU_M0_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MOU_M0_SGM)


df$MOU_M1_RANK <- rank(df$MOU_M1, ties.method = "first")
breaks<-quantile(df$MOU_M1_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df$MOU_M1_SGM<- cut( df$MOU_M1_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MOU_M1_SGM)

df$MOU_M2_RANK <- rank(df$MOU_M2, ties.method = "first")
breaks<-quantile(df$MOU_M2_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
df$MOU_M2_SGM<- cut( df$MOU_M2_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MOU_M2_SGM)

df$MOU_M3_RANK <- rank(df$MOU_M3, ties.method = "first")
breaks<-quantile(df$MOU_M3_RANK,c(0,1/5,2/5,3/5,4/5,1))
breaks[1]=breaks[1]-Inf
breaks[6]=breaks[6]+Inf
df$MOU_M3_SGM<- cut( df$MOU_M3_RANK, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df$MOU_M3_SGM)


#################

df$CHURN<-ifelse(df$CHURN==1,'SI','NO')
df$CHURN<-as.factor(df$CHURN)
str(df)

ggplot(df) +
  geom_bar(aes(x = ARPU_M1_SGM, fill = CHURN), position = "dodge")

exp1 <- ggplot(df, aes(ARPU_M3_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "ARPU M-3", y = "") + theme(legend.position = "none")
exp2 <- ggplot(df, aes(ARPU_M2_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "ARPU M-2", y = "") + theme(legend.position = "none")
exp3 <- ggplot(df, aes(ARPU_M1_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "ARPU M-1", y = "") + theme(legend.position = "right")


exp4 <- ggplot(df, aes(AVG_RECHARGE_M3_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "AVG_RECHARGE M-3", y = "") + theme(legend.position = "none")
exp5 <- ggplot(df, aes(AVG_RECHARGE_M2_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "AVG_RECHARGE M-2", y = "") + theme(legend.position = "none")
exp6 <- ggplot(df, aes(AVG_RECHARGE_M1_SGM, fill = CHURN)) + geom_bar(position = "fill") + labs(x = "AVG_RECHARGE M-1", y = "") + theme(legend.position = "right")

#exp4 <- ggplot(dfChurnTrain, aes(number_customer_service_calls, fill = churn)) + geom_bar(position = "fill") + labs(x = "Customer calls", y = "") + theme(legend.position = "none") 
grid.arrange(exp1, exp2, exp3,exp4, exp5, exp6, ncol = 3, nrow = 2, top = "Churn/Non-churn Proportion")
#df<-select (df,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION)

fun <- function(x) (trunc(x,0))
df<-mutate_if(df,is.numeric,fun)


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_BASE_PERFILADO_CHURN3", df, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
