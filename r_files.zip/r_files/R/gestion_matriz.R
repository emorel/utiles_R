#debug(utils:::unpackPkgZip)
#install.packages("imputeTS")

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)

###########################
############################



con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                      b.circuito
                      ,b.id_pdv
                     --,b.zona
                     --,sum(b.cant_clientes)/count(distinct b.id_pdv) as capilaridad
                     --,sum(b.poblacion-b.cant_clientes)/nullif(sum(case when p.id_pdv is null then 0 else 1 end),0) as oportunidad
                     ,sum(b.cant_clientes) as cant_clientes
                     --,count(distinct b.id_pdv) as cantidad_pdv
                     --,sum(b.poblacion) as poblacion
                     --,sum(b.hs_sin_saldo)/(13*31*count(distinct b.id_pdv)) as quiebre
                     --,sum(b.hs_sin_saldo)/(13*31*1) as quiebre
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                    ,sum(b.ventas) as ventas
                    --,sum(b.compras) as compras
                    ,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes >= 201811
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     --and b.zona = 'ITAP�A'
                     --and b.circuito not in ('ZK000087')
                     group by 
                     b.circuito
                     ,b.id_pdv
                     ,b.mes
                     --,b.zona
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
str(df)
dbDisconnect(con)


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                      b.circuito
                      ,b.id_pdv
                     --,b.zona
                     --,sum(b.cant_clientes)/count(distinct b.id_pdv) as capilaridad
                     --,sum(b.poblacion-b.cant_clientes)/nullif(sum(case when p.id_pdv is null then 0 else 1 end),0) as oportunidad
                      ,sum(b.ventas)/sum(b.cant_clientes) as arpu_cliente
                      ,sum(b.cant_clientes) as cant_clientes
                     --,count(distinct b.id_pdv) as cantidad_pdv
                     --,sum(b.poblacion) as poblacion
                     --,sum(b.hs_sin_saldo)/(13*31*count(distinct b.id_pdv)) as quiebre
                     --,sum(b.hs_sin_saldo)/(13*31*1) as quiebre
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                      ,sum(b.ventas) as ventas
                     --,sum(b.compras) as compras
                     --,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes >= 201811
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     --and b.zona = 'ITAP�A'
                     --and b.circuito not in ('ZK000087')
                     group by 
                     b.id_pdv
                     --,b.mes
                     ,b.circuito
                     --,b.zona
                     
                     
                     ")
my_data_bkp<- fetch(query)
toc()
my_data<-my_data_bkp
dbDisconnect(con)


#library(naniar)
#vis_miss(df)


#df$CANT_CLIENTES<-ifelse(df$CANT_CLIENTES==0,NA,df$CANT_CLIENTES)
#df$VENTAS<-ifelse(df$VENTAS==0,NA,df$VENTAS)



# for (i in 1:1) {
#   outlierKD(df, CANT_CLIENTES)
# }
# 
# for (i in 1:1) {
#   outlierKD(df, VENTAS)
# }


library(DMwR)
tic()
df <- knnImputation(select(df,-CIRCUITO,-ID_PDV,-MES),k=3)
toc()
#anyNA(df)
df$CIRCUITO <- df_bkp$CIRCUITO
df$ID_PDV <- df_bkp$ID_PDV
df$MES <- df_bkp$MES

df<-select (df,CIRCUITO,ID_PDV,CANT_CLIENTES,HS_SIN_SALDO,VENTAS,MES)

library(sqldf)

df<-sqldf("SELECT 
           CIRCUITO
            ,ID_PDV
            ,SUM(VENTAS)/SUM(CANT_CLIENTES) ARPU_CLIENTE
            ,SUM(CANT_CLIENTES) CANT_CLIENTES
            ,SUM(HS_SIN_SALDO) HS_SIN_SALDO
            ,SUM(VENTAS) VENTAS
            ,MES
            FROM \"df\"
            GROUP BY CIRCUITO,ID_PDV,MES
            ORDER BY 1")


#df <- na.omit(df)
#str(my_data)



options(scipen=999)
telecomModel <- lm(VENTAS ~  ARPU_CLIENTE+CANT_CLIENTES+HS_SIN_SALDO-1 ,data=select(df,-CIRCUITO,-ID_PDV,-MES))

#telecomModel_q <- lm(HS_SIN_SALDO ~  CANT_CLIENTES-1 ,data=df)

#coefficients(telecomModel)
#coefficients(telecomModel_q)


## generamos las formulas por segmento
######################
##### POR ID_PDV####
######################
#str(my_data)
data<-df

df_coef<-data.frame(CIRCUITO="CIRCUITO",ID_PDV="ID_PDV"
                    ,ARPU_CLIENTE=as.numeric(coefficients(telecomModel)[1])
                    ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                    ,HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[3])
                    )

df_coef$ID_PDV<-as.character(df_coef$ID_PDV)


df_coef <- df_coef[0,]


#str(df_coef)
tic()
for (i in sort(unique(df$ID_PDV))) {
  data<-subset(df,df$ID_PDV ==i)
  #print(head(data))
  #print(i)
  telecomModel <- lm(VENTAS ~ ARPU_CLIENTE+CANT_CLIENTES+HS_SIN_SALDO-1 ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_por_circuito/residuals_ventas_quiebre_circuito_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  #print(i)
  #print(coefficients(telecomModel))
  CIRCUITO<-as.character(data[1,1])
  ID_PDV<-as.character(data[1,2])
  #ZONA=as.character(data[1,2])
  #NOMBRE_DEALER=as.character(data[1,3])
  New<-data.frame(CIRCUITO=CIRCUITO,ID_PDV=ID_PDV
                  ,ARPU_CLIENTE=as.numeric(coefficients(telecomModel)[1])
                  ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                  ,HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[3])
  )  
  
  df_coef<-rbind(df_coef,New)
  
  #print(coefficients(telecomModel))
}
toc()



df_coef_totales<-merge(df_coef,my_data,by=c("CIRCUITO","ID_PDV"),all.x=TRUE,no.dups = FALSE)

df_coef_totales<-na.omit(df_coef_totales)

str(df_coef_totales)

df_coef_totales<-select(df_coef_totales,CIRCUITO,ID_PDV,ARPU_CLIENTE.x,CANT_CLIENTES.x,HS_SIN_SALDO.x,ARPU_CLIENTE.y,CANT_CLIENTES.y,HS_SIN_SALDO.y,VENTAS)

colnames(df_coef_totales)<-c("CIRCUITO","ID_PDV","ARPU_CLIENTE_C","CANT_CLIENTES_C","HS_SIN_SALDO_C","ARPU_CLIENTE","CANT_CLIENTES","HS_SIN_SALDO","VENTAS")


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_MATRIZ_GESTION", df_coef_totales, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

##########################################
###########cut por circuito###############
##########################################


#########################################
#############ARPU_CLIENTE_C#############
##########################################

df_coef_totales<-subset(df_coef_totales, !(CIRCUITO %in% c('ZK000087','ZK000074')))

#data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data1$ARPU_CLIENTE_RANK <- rank(data1$ARPU_CLIENTE_C, ties.method = "first")
breaks<-quantile(data1$ARPU_CLIENTE_RANK,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data1$ARPU_CLIENTE_C,n=breaks)[2])[,1]
data1$ARPU_CLIENTE_SGM<- cut( data1$ARPU_CLIENTE_RANK, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data1$ARPU_CLIENTE_SGM)

data1<-data1[0,]

tic()
for (i in sort(unique(df_coef_totales$CIRCUITO))) {
  data2<-subset(df_coef_totales,df_coef_totales$CIRCUITO ==i)
  #print(i)
  data2$ARPU_CLIENTE_RANK <- rank(data2$ARPU_CLIENTE_C, ties.method = "first")
  breaks<-quantile(data2$ARPU_CLIENTE_RANK,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-Inf
  breaks[4]=breaks[4]+Inf
  mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
  data2$ARPU_CLIENTE_SGM<- cut( data2$ARPU_CLIENTE_RANK, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data1<-rbind(data1,data2)
}
toc()

#########################################
#############HS_SIN_SALDO_C#############
##########################################

df_coef_totales<-subset(df_coef_totales, !(CIRCUITO %in% c('ZK000087','ZK000074')))

data3<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data3$HS_SIN_SALDO_RANK <- rank(data3$HS_SIN_SALDO_C, ties.method = "first")
breaks<-quantile(data3$HS_SIN_SALDO_RANK,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-Inf
breaks[4]=breaks[4]+Inf
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data1$ARPU_CLIENTE_C,n=breaks)[2])[,1]
data3$HS_SIN_SALDO_SGM<- cut( data3$HS_SIN_SALDO_RANK, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data3$HS_SIN_SALDO_SGM)

data3<-data3[0,]

tic()
for (i in sort(unique(df_coef_totales$CIRCUITO))) {
  data4<-subset(df_coef_totales,df_coef_totales$CIRCUITO ==i)
  #print(i)
  data4$HS_SIN_SALDO_RANK <- rank(data4$HS_SIN_SALDO_C, ties.method = "first")
  breaks<-quantile(data4$HS_SIN_SALDO_RANK,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-Inf
  breaks[4]=breaks[4]+Inf
  mylabels<-c("1.-ALTO","2.-MEDIO","3.-BAJO")
  data4$HS_SIN_SALDO_SGM<- cut( data4$HS_SIN_SALDO_RANK, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data3<-rbind(data3,data4)
}
toc()
data1<-select (data1,-ARPU_CLIENTE_RANK)
data3<-select (data3,CIRCUITO,ID_PDV,HS_SIN_SALDO_SGM)

df_coef_totales<-merge(data1,data3,by=c("CIRCUITO","ID_PDV"),all.x=TRUE,no.dups = FALSE)

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_MATRIZ_ARPU_QUIEBRE", df_coef_totales, overwrite = TRUE, append = FALSE)
dbDisconnect(con)






####################################################
####BRAKETS - CUT - break - quantiles - cuantiles###
####################################################

df_coef_sgm<-df_coef
df_coef_sgm<-df_coef_totales
options(scipen=999)

breaks<-5

mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")

#df_coef_sgm$cant_clientes_sgm<- cut( df_coef_sgm$CANT_CLIENTES_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
#table(df_coef_sgm$cant_clientes_sgm)

#df_coef_sgm$HS_SIN_SALDO_sgm<- cut( df_coef_sgm$HS_SIN_SALDO_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
#table(df_coef_sgm$HS_SIN_SALDO_sgm)

breaks<-data.frame(classIntervals(df_coef_sgm$CANT_CLIENTES,n=5)[2])[,1]
df_coef_sgm$CANT_CLIENTES_SGM<- cut( df_coef_sgm$CANT_CLIENTES, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df_coef_sgm$CANT_CLIENTES_SGM)

breaks<-data.frame(classIntervals(df_coef_sgm$HS_SIN_SALDO,n=5)[2])[,1]
df_coef_sgm$HS_SIN_SALDO_SGM<- cut( df_coef_sgm$HS_SIN_SALDO, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df_coef_sgm$HS_SIN_SALDO_SGM)

#CUT POR QUANTILES - PRETTY PRINT

mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df_coef_sgm$cant_clientes_sgm<-cut(df_coef_sgm$CANT_CLIENTES_C,breaks=data.frame(classIntervals(df_coef_sgm$CANT_CLIENTES,n=5)[2])[,1],include.lowest=T,dig.lab=8,labels = mylabels)
table(df_coef_sgm$cant_clientes_sgm)
table(df_coef_sgm$CANT_CLIENTES_BKT)

df_coef_sgm$hs_sin_saldo_sgm<-cut(df_coef_sgm$HS_SIN_SALDO,breaks=data.frame(classIntervals(df_coef_sgm$HS_SIN_SALDO,n=5)[2])[,1],include.lowest=T,dig.lab=8,labels = mylabels)
table(df_coef_sgm$hs_sin_saldo_sgm)
table(df_coef_sgm$HS_SIN_SALDO_BKT)

#colnames(df_coef_sgm)<-c("ID_PDV","CANT_CLIENTES_C","HS_SIN_SALDO_C","CANT_CLIENTES_BKT","HS_SIN_SALDO_BKT")
con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_PDV_CLIENTE_QUIEBRE_SGM", df_coef_sgm, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

