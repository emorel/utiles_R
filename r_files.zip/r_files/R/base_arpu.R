library(ROracle)
library(dplyr)
library(tictoc)

con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")

m.mat <- matrix(, nrow = 21, ncol = 5)
i=1
for (MONTH in c(
                #"2017-01-01","2017-02-01","2017-03-01","2017-04-01"
                #,"2017-05-01","2017-06-01","2017-07-01","2017-08-01"
                #,"2017-09-01","2017-10-01","2017-11-01","2017-12-01"
                #,"2018-01-01","2018-02-01","2018-03-01"
                "2018-04-01","2018-05-01","2018-06-01"
                ,"2018-07-01","2018-08-01","2018-09-01"
                ))
  {
  
  
  
  FECHA_DATOS <- data.frame(MONTH)
  
  
tic()  
  query <- dbSendQuery(con,"
                       
                       select count(distinct ar.AR_SSCRBR_DD) as cant_clientes
                      ,sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT-ar.rev_e_voice_xnet_m2m-ar.rev_e_voice_xnet_f2m) as revenue
                      ,sum(ar.MB_DATA_TRAFFIC) as traffic
                       from smy.ar_monthly_base_fct ar
                       where
                       ar.AR_SSCRBR_DD in 
                       (

                          select t.ar_sscrbr_dd 
                          from TMP_TREAT t
                     
                       )
                       and ar.FCT_DT = last_day(to_date(:1,'YYYY-MM-DD'))
                      and ar.AR_CMMRCL_ST_KEY = 54
                      and ar.PAYMENT = 'PRE'
                       
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  m.mat[i,1]=df$CANT_CLIENTES
  m.mat[i,2]=df$REVENUE
  m.mat[i,3]=df$TRAFFIC
  #ARPU
  m.mat[i,4]=m.mat[i,2]/m.mat[i,1]
  #DATA_PER_USER
  m.mat[i,5]=m.mat[i,3]/m.mat[i,1]
  
  print(m.mat)
  
  i=i+1
  toc()
  
}


