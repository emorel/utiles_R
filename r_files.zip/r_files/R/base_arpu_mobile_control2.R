library(ROracle)
library(dplyr)
library(tictoc)

con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")

m.mat <- matrix(, nrow = 21, ncol = 7)
i=1
for (MONTH in c(
  "2017-01-01","2017-02-01","2017-03-01","2017-04-01"
  ,"2017-05-01","2017-06-01","2017-07-01","2017-08-01"
  ,"2017-09-01","2017-10-01","2017-11-01","2017-12-01"
  ,"2018-01-01","2018-02-01","2018-03-01","2018-04-01"
  ,"2018-05-01","2018-06-01","2018-07-01","2018-08-01"
  ,"2018-09-01"
))
{
  
  
  
  FECHA_DATOS <- data.frame(MONTH)
  
  
  tic()  
  query <- dbSendQuery(con,"
                       
                       select count(distinct f.AR_SSCRBR_DD) as NUMBER_USERS_PRODUCTO
                       , (sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT-f.rev_e_voice_xnet_m2m-f.rev_e_voice_xnet_f2m)/6000)/count(distinct f.AR_SSCRBR_DD) as ARPU_MOBILE
                       ,(sum(f.MB_DATA_TRAFFIC)/1000)/count(distinct f.AR_SSCRBR_DD) as GB_PER_USER
                       from smy.ar_monthly_base_fct f
                       left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                       left join dtl.pd_dim p on p.PD_KEY = at.PD_KEY
                       where f.PAYMENT= 'PRE' -- payment type group
                       and f.CMMRCL_BS_UN_KEY = 1 --Mobile Business unit --DTL.BS_UN_DIM t
                       and f.TOTAL_ARPU_BRCKT_KEY not in (9,10)
                       and f.MB_DATA_4G > 0 -- user technology
                       and f.AR_CMMRCL_ST_KEY = 54 --existing --dtl.     ar_st_dim
                       and f.FCT_DT= at.FCT_DT
                       and nvl(p.DVC_TP_CD, 'HS') = 'HS' -- linea 118 : smy_cstmr.v_qos_existing
                       and f.AR_SSCRBR_DD in 
                       (
                       
                       select t.ar_sscrbr_dd 
                       from TMP_CONTROL2 t
                       --minus
                       --select t.ar_sscrbr_dd
                       --from expeam.tmp_base_core_mfs_monthly_sft t
                       --where t.fct_dt between last_day(to_date(:1,'YYYY-MM-DD')) -60 and last_day(to_date(:2,'YYYY-MM-DD'))-- cambio
                       
                       )
                       and f.FCT_DT = last_day(to_date(:3,'YYYY-MM-DD'))
                       
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  m.mat[i,1]=df$NUMBER_USERS_PRODUCTO
  m.mat[i,3]=df$ARPU_MOBILE
  m.mat[i,5]=df$GB_PER_USER
  
  FECHA_DATOS <- data.frame(MONTH)
  
  query <- dbSendQuery(con,"
                       
                       select count(distinct f.AR_SSCRBR_DD) as NUMBER_USERS_BASE
                       from smy.ar_monthly_base_fct f
                       left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                       left join dtl.pd_dim p on p.PD_KEY = at.PD_KEY
                       where f.PAYMENT= 'PRE' -- payment type group
                       and f.CMMRCL_BS_UN_KEY = 1 --Mobile Business unit --DTL.BS_UN_DIM t
                       and f.TOTAL_ARPU_BRCKT_KEY not in (9,10)
                       and f.MB_DATA_4G > 0 -- user technology
                       and f.AR_CMMRCL_ST_KEY = 54 --existing --dtl.     ar_st_dim
                       and f.FCT_DT= at.FCT_DT
                       and nvl(p.DVC_TP_CD, 'HS') = 'HS' -- linea 118 : smy_cstmr.v_qos_existing
                       and f.AR_SSCRBR_DD in 
                       (
                       
                       select t.ar_sscrbr_dd 
                       from TMP_CONTROL2 t

                       
                       )
                       and f.FCT_DT = last_day(to_date(:1,'YYYY-MM-DD'))
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  
  m.mat[i,2]=df$NUMBER_USERS_BASE
  
  
  FECHA_DATOS <- data.frame(MONTH)
  
  query <- dbSendQuery(con,"
                       select
                       (sum(p.revenue)/6000)/ count(distinct p.nro_cuenta)  as ARPU_MFS
                       from expeam.product_tracking_rev_mensual p
                       where p.fecha_datos = last_day(to_date(:1,'YYYY-MM-DD'))
                       and p.nro_cuenta in
                       (
                       
                       select t.ar_sscrbr_dd 
                       from TMP_CONTROL2 t
                       --minus
                       --select t.ar_sscrbr_dd
                       --from expeam.tmp_base_core_mfs_monthly_sft t
                       --where t.fct_dt between last_day(to_date(:2,'YYYY-MM-DD')) -60 and last_day(to_date(:3,'YYYY-MM-DD'))-- cambio
                       
                       
                       )
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  m.mat[i,4]=df$ARPU_MFS
  
  FECHA_DATOS <- data.frame(MONTH)
  
  query <- dbSendQuery(con,"
                       SELECT (sum(c.total_carga)/6000)/count(distinct c.nro_cuenta) as avg_reload
                       ,sum(c.cant_trz)/count(distinct c.nro_cuenta) as reload_freq
                       FROM rpt_recarga.carga_saldo_x_cta_dtl c
                       where c.fecha_acreditacion = last_day(to_date(:1,'YYYY-MM-DD'))
                       and c.nro_cuenta in 
                       (
                       select t.ar_sscrbr_dd 
                       from TMP_CONTROL2 t
                       --minus
                       --select t.ar_sscrbr_dd
                       --from expeam.tmp_base_core_mfs_monthly_sft t
                       --where t.fct_dt between last_day(to_date(:2,'YYYY-MM-DD')) -60 and last_day(to_date(:3,'YYYY-MM-DD'))-- cambio
                       
                       )                    
                       
                       
                       
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  m.mat[i,6]=df$AVG_RELOAD
  m.mat[i,7]=df$RELOAD_FREQ
  


  
  
  print(m.mat)
  
  i=i+1
  toc()
  
}


