base_arpu_linea

xs=quantile(base_arpu_linea$REVENUE,c(0,1/5,2/5,3/5,4/5,1))
xs[1]=xs[1]-.00005
base_arpu_linea <- base_arpu_linea %>% mutate(REVENUE_f=cut(base_arpu_linea$REVENUE, breaks=xs, labels=c("1.~very~low","2.~low","3.~middle","4.~high","5.~very high")))
boxplot(base_arpu_linea$REVENUE~base_arpu_linea$REVENUE_f,col=3:5)

write.table(base_arpu_linea,file = "base_arpu_ci.csv",sep = ";",row.names = FALSE)
