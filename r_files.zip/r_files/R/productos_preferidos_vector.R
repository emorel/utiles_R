
con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")


n<- c("carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura","pago_salario","retiro_dinero","pago_comercio","retiro_atm")
#l<-2:ncol(dfCBSl)
i<-1
#i=211
l<-as.vector(dfCBSl[i,-c(1)])
m<-c(dfCBSl[i,1],n[order(l, decreasing=TRUE)])
i=i+1

while (i<=nrow(dfCBSl)) {
  l<-as.vector(dfCBSl[i,-c(1)])
  m<-rbind(m,c(dfCBSl[i,1],n[order(l, decreasing=TRUE)]))
  i=i+1
}
m<-as.data.frame(m)
minsert<-m[c(1,2,3,4,5,6,7,8)]
rs <- dbSendQuery(con, "truncate table expeam.BASE_CLIENTE_PRODUCTO_PREF", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.BASE_CLIENTE_PRODUCTO_PREF values(:1,:2,:3,:4,:5,:6,:7,:8)", data=minsert)

dbCommit(con)
