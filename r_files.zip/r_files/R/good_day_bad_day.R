library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)
library(scales)
#i <- c(7,6,5,4,3,2,1)
i<-7:1
par(mfrow=c(1,7))

con <- dbConnect(Oracle(), user="expeam", password="!diciembre2018", dbname="DWH/dwh_olap")
#creamos el data frame y cargamos la primera fila
dfa <- data.frame("FECHA" = "Vie 01-06-2018", "DIA_SEMANA" = 51, "MONTO" = 1000 , "CANT_TRX" = 1000 ,"FECHA_TRX"=as.Date("2018-12-01"))
str(dfa)
for (dia in i){
    
    ##11 = lunes primera semana
    ##71 = domingo primera semana
    
    query <- dbSendQuery(con,"
                         
                         select to_char(trunc(sysdate-:1),'Dy DD-MM-YYYY') as ds  from dual
                         ",data=dia)
    y <- fetch(query)
    
    
    ##11 = lunes primera semana
    ##71 = domingo primera semana
    query <- dbSendQuery(con,"
                         
                    select to_char(trunc(sysdate-:1),'DW') as ds  from dual
                         ",data=dia)
    ydw <- fetch(query)
    
    ##11 = lunes primera semana
    ##71 = domingo primera semana
    #tiff('C:/Users/expeam/Documents/segment/2018/10-octubre/good_day_bad_day/ultimos_30_dias.tiff', width = 35, height = 25, units = 'in', res = 200)
 
    query <- dbSendQuery(con,"
                         
                         
                        select 
                        to_char(p.fecha_datos,'Dy DD-MM-YYYY') as fecha
                         --,to_char(p.fecha_datos,'yyyymmddiw') as fecha
                         ,to_char(p.fecha_datos,'DW') as dia_semana
                         ,sum(p.monto)/1000000 as monto
                        --,sum(p.cant_trx)/1000 as cant_trx
                          ,sum(p.cant)/1000 as cant_trx
                        ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_trx
                         from tigo_cash_rpt.base_cliente_mfs_daily p
                          --from tigo_cash_rpt.product_tracking p
                         -- join expeam.tmp_base_envio_minicarga e
                        --  on (p.nro_cuenta= e.nro_cuenta
                         --and p.fecha_datos = e.fecha_datos)
                         where p.fecha_datos between date'2017-01-01' and date'2018-12-16'
                         --and p.servicio in ('Envio','Envio App')
                         --and p.servicio in ('Minicarga')
                        --and p.subcategoria in ('Menu')
                        --and p.service_id in (3,30,502,515,521,522,524,525) 
                        --and p.service_id in (502,515,521,522,524,525) 
                        and to_char(p.fecha_datos,'DW') = :1
                         group by to_char(p.fecha_datos,'Dy DD-MM-YYYY')
                         ,to_char(p.fecha_datos,'DW')
                        ,to_char(p.fecha_datos,'YYYY-MM-DD')
                         order by 1
                         
                         
                         ",data=ydw)
    df <- fetch(query)
    df$FECHA_TRX<-as.Date(df$FECHA_TRX)
    dfa<-rbind(dfa,df)
    #write.table(df,file="C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/envio_performance_control.csv",append = TRUE,row.names = FALSE,col.names = FALSE,sep = ";",)
    #str(df)
    
    
    #boxplot(df$MONTO ~ reorder(df$DIA_SEMANA,df$FECHA) , xaxt="n" , xlab="" , col=my_colors , pch=20 , cex=0.3 , ylab="value" )
    #hist(df$MONTO)
    #summary(df$MONTO)
    obs<-subset(df,FECHA==y$DS)$MONTO
    
    
    #boxplot(df$MONTO ~ df$DIA_SEMANA , xaxt="n" , xlab=y$DS ,  pch=20 , cex=0.3 , ylab="monto")
    #points(obs,col="red",pch=17)
}
#eliminamos la primera fila
dfa<-dfa[-c(1),]


write.table(dfa,file="C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/envio_performance_control_cant_trx.csv",append = FALSE,row.names = FALSE,col.names = TRUE,sep = ";")


dfa_m<-dfa %>%
  select(DIA_SEMANA, MONTO, CANT_TRX,FECHA,FECHA_TRX) %>%
  group_by(DIA_SEMANA) %>%
  summarise(MONTO = median(MONTO)
            ,CANT_TRX = median(CANT_TRX)
            ,FECHA_TRX = max(FECHA_TRX))


j<-1
dfa_m$ACTUAL<-10000
dfa_m$DIF<-10000
dfa_m$ACTUAL_TRX<-10000
dfa_m$DIF_TRX<-10000

for (i in dfa_m$FECHA_TRX) {
  dfa_m[j,5]<-subset(dfa,FECHA_TRX==as.Date(i,origin="1970-01-01"))$MONTO
  dfa_m[j,6]<-dfa_m[j,5]-dfa_m[j,2]
  dfa_m[j,7]<-subset(dfa,FECHA_TRX==as.Date(i,origin="1970-01-01"))$CANT_TRX
  dfa_m[j,8]<-dfa_m[j,7]-dfa_m[j,3]
  j<-j+1
}
dfa_g<-data.frame(FECHA=as.Date("2018-12-01"),MONTO=1000,TIPO="MEDIA")
dfa_g$TIPO<-as.character(dfa_g$TIPO)
j<-1
for (i in dfa_m$FECHA_TRX) {
  dfa_g[j,1]<-as.Date(i,origin="1970-01-01")
  j<-j+1
}
k<-1
for (i in dfa_m$MONTO) {
  dfa_g[k,2]<-i
  dfa_g[k,3]<-"MEDIA"
  k<-k+1
}

for (i in dfa_m$FECHA_TRX) {
  dfa_g[j,1]<-as.Date(i,origin="1970-01-01")
  j<-j+1
}

for (i in dfa_m$ACTUAL) {
  dfa_g[k,2]<-i
  dfa_g[k,3]<-"ACTUAL"
  k<-k+1
}
dfa_g$TIPO<-as.factor(dfa_g$TIPO)






write.table(dfa_m,file="C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/envio_performance_control_media.csv",append = FALSE,row.names = FALSE,col.names = TRUE,sep = ";")

ggplot(dfa_g,aes(FECHA, MONTO, fill=TIPO,alpha=TIPO))+
  geom_bar(stat = "identity",position ="identity")+
  scale_x_date(breaks=pretty_breaks(n=56))+
  scale_colour_manual(values=c("lightgreen","gray")) +
  scale_fill_manual(values=c("lightgreen","gray")) +
  scale_alpha_manual(values=c(.3, .9))+
  theme(axis.text.x = element_text(angle=45))+
  ggtitle("Envio - Monto Vs Promedio diario")+
  theme(plot.title = element_text(hjust=0.5),legend.text = element_text(size = 12))
  #scale_fill_brewer(palette="Greens")

