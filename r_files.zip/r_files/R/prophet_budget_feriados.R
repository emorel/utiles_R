library(prophet)
library(dplyr)
library(ROracle)
con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")
query <- dbSendQuery(con,"
                     
                     /*SELECT
                     SUM(CASE WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'OTC Remittances'           THEN p.revenue/1.1
                     WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'P2P Remittances'           THEN p.revenue/1.1
                     WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'APP P2P Remittances'       THEN p.revenue/1.1
                     WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'P2P Envio'                 THEN p.revenue/1.1
                     WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'APP P2P Envio'             THEN p.revenue/1.1
                     WHEN p.categoria    = 'Salary Payment'       AND p.subcategoria = 'Salary Payment - Bulk'     THEN p.revenue/1.1
                     WHEN p.categoria    = 'Cash Out'             AND p.subcategoria = 'Cash Out'                  THEN p.revenue/1.1
                     WHEN p.categoria    = 'Cash Out'             AND p.subcategoria = 'Companion Card'            THEN p.revenue/1.1
                     
                     ELSE p.monto*d.fee
                     END) AS monto
                     ,p.fecha_datos as fecha
                     FROM
                     ( SELECT * FROM expeam.product_tracking_rev2 p
                     UNION ALL
                     SELECT * FROM expeam.product_tracking_rev2_o p
                     ) p
                     JOIN expeam.product_daily_bdgt_fcst_v4 d
                     ON (p.fecha_datos = d.fecha
                     AND p.categoria= d.categoria
                     AND p.subcategoria= d.subcategoria)
                     WHERE p.fecha_datos BETWEEN DATE'2016-01-01' AND DATE'2017-07-31'
                     AND p.categoria NOT IN ('TIGO TV Pago anticipado','Sales Warranty')
                     AND p.subcategoria NOT IN ('Error','Salary Payment')
                     GROUP BY p.fecha_datos*/
                     
select sum(p.revenue)/1.1 as monto
,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha
                     from expeam.product_tracking_rev_diario p
                     where p.fecha_datos between date'2016-01-01' and date'2018-07-24'
                     GROUP BY p.fecha_datos
                     order by 1
                     ")


result <- fetch(query)


df <- result


df$FECHA <- as.Date(df$FECHA, format = "%Y-%m-%d")
str(t)
df<-t[,c("OTC_REM","FECHA_DATOS")]
str(df)
colnames(df)<-c("y","ds")

feriados <- data_frame(
  holiday = 'feriados',
  ds = as.Date(c('2016-01-01','2016-02-29','2016-03-24','2016-03-25','2016-03-26','2016-03-27'
                 ,'2016-05-01','2016-05-15','2016-06-12','2016-08-15','2016-10-03','2016-12-08'
                 ,'2016-12-25','2017-01-01','2017-02-27','2017-04-13','2017-04-14','2017-04-15'
                 ,'2017-04-16','2017-05-01','2017-05-14','2017-05-15','2017-06-12','2017-08-15'
                 ,'2017-10-02','2017-12-08','2017-12-25','2018-01-01','2018-02-26','2018-03-29'
                 ,'2018-03-30','2018-03-31','2018-04-01','2018-05-01','2018-05-14','2018-05-15'
                 ,'2018-06-11','2018-08-15','2018-09-29','2018-12-08','2018-12-25','2019-01-01'
                 ,'2019-03-04','2019-04-18','2019-04-19','2019-04-20','2019-04-21','2019-05-01'
                 ,'2019-05-14','2019-05-15','2019-06-10','2019-08-15','2019-09-29','2019-12-08'
                 ,'2019-12-25')),
  lower_window = 0,
  upper_window = 1
)


m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality=TRUE,holidays = feriados)
#m <- prophet(df,seasonality.prior.scale = 20,changepoint.prior.scale = 0.001)


future <- make_future_dataframe(m, periods = 518)
tail(future)

##OUTLIERS
#outliers <- (as.Date(df$ds) > as.Date('2015-01-01')
#             & as.Date(df$ds) < as.Date('2016-01-31'))
#df$y[outliers] = NA
#m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE)
#m <- prophet(df)



forecast <- predict(m, future)
tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

prophet_plot_components(m, forecast)
plot(m, forecast)

##definimos las fechas para el subset
#sf <- c(as.Date('2017-04-01', format = "%Y-%m-%d"),as.Date('2017-04-08', format = "%Y-%m-%d"))
#i <- as.Date('2017-04-15', format = "%Y-%m-%d")
#while (i<=Sys.Date()+28){
#	sf <- append(sf,i)
#	i<-i+7
#}
#solo seleccionamos las fechas del reporte del comite
##cada 7 dias
#subset(forecast[c("ds","yhat")],forecast$ds %in% sf)
#write.csv(subset(forecast[c("ds","yhat")],forecast$ds %in% sf),"forecast_merchant_payment.csv")
write.csv(forecast[c("ds","yhat", "yhat_lower")],"forecast_new_wallet.csv")
