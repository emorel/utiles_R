
#debug(utils:::unpackPkgZip)
#install.packages("pscl")

library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)
library(stats)
library(scales)
library(lsr)
library(Amelia)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     with
                     dms AS
                     (
                     select
                     t.id_pdv 
                     ,t.cant_veces_sin_saldo
                     ,t.horas_sin_saldo
                     ,t.compras
                     ,t.ventas
                     --,t.fecha_creacion
                     ,round(months_between(sysdate, t.fecha_creacion),0) AS ANTIGUEDAD_MESES
                     ,t.categoria
                     ,t.prom_ventas30
                     ,t.compras30
                     ,t.ventas30
                     ,t.cant_compras30
                     ,t.hora_compra
                     ,t.venta_mes
                     ,t.compra_mes
                     ,t.venta_dom
                     ,t.venta_lun
                     ,t.venta_mar
                     ,t.venta_mie
                     ,t.venta_jue
                     ,t.venta_vie
                     ,t.venta_sab
                     --,t.segmentacion
                     ,t.distrito_tm
                     ,t.departamento_tm
                     ,t.estado_pdv
                     ,t.region
                     ,t.commercial_zone
                     from RPT_DISTRIBUCION.EPIN_M_SALDO_CERO_AG_PDV t
                     where t.mes = '201812'
                     )
                     ,mts as
                     (
                     SELECT am.MSISDN
                     ,ttc.MOBILE
                     ,ttc.ID_POS
                     from rpl_tigo_cash.agent a
                     join rpl_tigo_cash.agent_mobile am
                     on (a.AGENT_ID= am.AGENT_ID and a.FECHA = date'2018-12-31' and am.FECHA = date'2018-12-31' and a.DELETED is null)
                     JOIN rpl_dms2.tbl_tigo_cash ttc
                     ON (am.MSISDN= ttc.MOBILE)
                     
                     )
                     select distinct dms.*
                     ,NVL2(mts.ID_POS,1,0) as TIPO
                     from dms
                     left join mts
                     on (dms.id_pdv= mts.ID_POS)
                     
                     ")
t <- fetch(query)
toc()


t.idpdv.sample <- sample(unique(t$ID_PDV),2000)
t<- subset(t,ID_PDV %in% t.idpdv.sample)
summary(t)

str(t)

# all character columns to factor:
t <- mutate_if(t, is.character, as.factor)
#t %>% summarise_if(is.numeric, sum, na.rm = TRUE)



# select character columns 'char1', 'char2', etc. to factor:
#t <- mutate_at(t, vars(char1, char2), as.factor)




training.data.raw <- t
training.data.raw<-na.omit(training.data.raw)
##unique values
#sapply(training.data.raw,function(x) sum(is.na(x)))
#sapply(training.data.raw, function(x) length(unique(x)))

## null values
#tic()
#tiff('C:/Users/expeam/Documents/segment/2019/01-enero/analisis_ptm_alta_baja/missmap_ptm.tiff', width = 55, height = 35, units = 'in', res = 200)
#missmap(training.data.raw, main = "Missing values vs observed")
#dev.off()
#toc()




data<-training.data.raw

remove(t)
remove(training.data.raw)

train <- data[1:nrow(data)/2,]
nrow(data)
test <- data[(nrow(data)/2)+1:nrow(data),]

remove(data)

train<-train[-c(1)]

tic()
model <- glm(TIPO ~COMPRAS+ANTIGUEDAD_MESES+CATEGORIA+CANT_COMPRAS30+VENTA_MES+COMPRA_MES+VENTA_DOM+VENTA_LUN+VENTA_MAR+VENTA_MIE+VENTA_JUE+VENTA_VIE+VENTA_SAB,family=binomial(link='logit'),data=train)
toc()

options(max.print=5000)
summary(model)

tic()
anova(model, test="Chisq")
toc()

library(pscl)
pR2(model)


fitted.results <- predict(model,newdata=subset(test,select=c('COMPRAS','ANTIGUEDAD_MESES','CATEGORIA','CANT_COMPRAS30','VENTA_MES','COMPRA_MES','VENTA_DOM','VENTA_LUN','VENTA_MAR','VENTA_MIE','VENTA_JUE','VENTA_VIE','VENTA_SAB')),type='response')

#test$TIPO<-as.character(test$TIPO)

#test$TIPO[test$TIPO=="NO"] <- 0
#test$TIPO[test$TIPO=="SI"] <- 1

fitted.results <- ifelse(fitted.results > 0.5,1,0)
misClasificError <- mean(fitted.results != test$TIPO)
print(paste('Accuracy',1-misClasificError))

library(ROCR)
p <- predict(model, newdata=subset(test,select=c('COMPRAS','ANTIGUEDAD_MESES','CATEGORIA','CANT_COMPRAS30','VENTA_MES','COMPRA_MES','VENTA_DOM','VENTA_LUN','VENTA_MIE','VENTA_VIE','VENTA_SAB')), type="response")
pr <- prediction(p, test$TIPO)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
plot(prf)

auc <- performance(pr, measure = "auc")
auc <- auc@y.values[[1]]
auc
