

library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(ROracle)
library(tictoc)
library(gridExtra)
library(grid)
library(scales)


con <- dbConnect(Oracle(), user="expeam", password="!enero2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select 
                      max(fecha_datos) as fecha_datos
                     ,TO_CHAR(max(fecha_datos),'YYYYMMDD') as fecha_f
                     ,median(monto) as monto
                     ,semanadia
                     ,'MONTO PROMEDIO' as tipo
                     from
                     (
                     SELECT to_char(p.fecha_datos,'yyyymmddwd') as fechasemanadia
                     ,to_char(p.fecha_datos,'wd') as semanadia
                     ,p.fecha_datos
                     ,sum(p.monto) as monto
                     ,sum(p.cant_trx) as cant_trx
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2017-01-01' and date'2019-01-21'
                     --and p.servicio in ('Envio','Envio App')
                    --and p.servicio in ('Transferencia')
                      --and p.categoria = 'Self Top Up'
                     group by
                     to_char(p.fecha_datos,'yyyymmddwd')
                     ,to_char(p.fecha_datos,'wd')
                     ,p.fecha_datos
                     )
                     group by semanadia
                     
                     
                     ")
df_bkp <- fetch(query)
toc()



dfa<-df_bkp[c("FECHA_DATOS","MONTO","TIPO")]
##eliminamos todas las filas de dfa

dfa <- dfa[0,]
df_mediana<-df_bkp


f<-seq(as.Date("2018/11/01"), as.Date("2019/01/21"), "days")

#dfa1<-subset(dfa1,as.character(FECHA_DATOS) %in% as.character(f))


fc<-as.character(f)
#db<-as.numeric(f[length(f)]-as.Date("2018/10/01"))

for (i in 1:length(f))
{
  tic()
  query <- dbSendQuery(con,"
                       
                       
                       SELECT p.fecha_datos
                        ,sum(p.monto) as monto
                      ,to_char(p.fecha_datos,'wd') as semanadia
                       ,'MONTO ACTUAL' as tipo
                       from tigo_cash_rpt.product_tracking p
                       where p.fecha_datos = to_date(:1,'yyyy-mm-dd')
                       --and p.servicio in ('Envio','Envio App')
                      --and p.servicio in ('Transferencia')
                      --and p.categoria = 'Self Top Up'
                       group by
                       p.fecha_datos
                       
                       ",data=fc[i])
  
  df_bkp1 <- fetch(query)
  toc()
  dfa2<-df_bkp1
  
  ##append a row in the data frame dfa
  
  dfa[nrow(dfa) + 1,] <-
    data.frame(
      FECHA_DATOS= dfa2$FECHA_DATOS,
      subset(df_mediana,SEMANADIA==dfa2$SEMANADIA)[c("MONTO")],
      subset(df_mediana,SEMANADIA==dfa2$SEMANADIA)[c("TIPO")]
    )
  
  dfa[nrow(dfa) + 1,] <-dfa2[c("FECHA_DATOS","MONTO","TIPO")]
  
  
  
}

dfa$FECHA_DATOS<-as.Date(dfa$FECHA_DATOS)

tiff('C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/Total_diario.tiff', width = 55, height = 25, units = 'in', res = 100)
ggplot(dfa,aes(FECHA_DATOS, MONTO, fill=TIPO,alpha=TIPO))+
  geom_bar(stat = "identity",position ="identity")+
  scale_x_date(breaks=pretty_breaks(n=56))+
  scale_colour_manual(values=c("blue","grey")) +
  scale_fill_manual(values=c("blue","grey")) +
  scale_alpha_manual(values=c(.3, .9))+
  xlab("FECHA")+ 
  ylab("MONTO (MMG)")+
  theme(axis.text.x = element_text(angle=90,size = 30),axis.text.y = element_text(angle=0,size = 30),legend.position="right",title = element_text(size = 30))+
  theme(plot.title = element_text(hjust=0.5),legend.text = element_text(size = 50),legend.title=element_blank())
dev.off()



dbDisconnect(con)

write.table(dfa,"C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/Envio_diario.csv",row.names = FALSE,sep = ";")

#tiff('C:/Users/expeam/Documents/segment/2018/12-diciembre/analisis_hora_trx/promedio_dia_1.tiff', width = 55, height = 25, units = 'in', res = 100)
#do.call(grid.arrange,p)
#dev.off()


