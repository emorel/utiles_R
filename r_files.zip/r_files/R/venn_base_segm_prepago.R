

#upload library
library(ROracle)
library(VennDiagram)
library(gplots)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
##ene-2018
tic()
query <- dbSendQuery(con,"
                     
                  select p.ar_key
                  from expeam.tmp_base_paq_4 p
                  where p.servicio = '800mbx7000gsx2d'
                     
                     ")
base1 <- fetch(query)
toc()

##ene-2019
tic()
query <- dbSendQuery(con,"
                     
                     
                    select p.ar_key
                    from expeam.tmp_base_paq_4 p
                    where p.servicio = '1,5gbx10000gsx3d'
                     
                     ")
base2 <- fetch(query)
toc()
##ene-2019
tic()
query <- dbSendQuery(con,"
                     
                  select p.ar_key
                  from expeam.tmp_base_paq_4 p
                  where p.servicio = '1,5gb+Ilitigo+30minx12000gsx3d'
                     
                     ")
base3 <- fetch(query)
toc()
##TIGO_BILL_PAYS
tic()
query <- dbSendQuery(con,"
                     
            select p.ar_key
            from expeam.tmp_base_paq_4 p
            where p.servicio = '2gb+Ilimtigo+100minx15000gsx5d'   

                     ")
base4 <- fetch(query)
toc()



#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$AR_KEY
#base1[is.na(base1)]<-"1"
base2<-base2$AR_KEY
#base2[is.na(base2)]<-"1"
base3<-base3$AR_KEY
#base3[is.na(base3)]<-"1"
base4<-base4$AR_KEY
#base4[is.na(base4)]<-"1"



#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base1,base2,base3,base4),
  category.names = c("800mbx7000","1_5gbx10000","1_5gbx12000","2gbx15000"),
  filename = 'C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/venn_diagramm_paquetes_1.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow','purple','green','red'),
  cex = 0.5,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.5,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 


ItemsList<-venn(list(A=1:5,B=4:6,C=c(4,8:10)))


itemlist<-venn(list(B7000=base1,B10000=base2,B12000=base3,B15000=base4))
#B7000 [12]
#B10000 [13]
#B12000 [14]
#B15000 [15]

BASE7000<-data.frame(AR_KEY=attr(itemlist,"intersections")[12],SERVICIO="800mbx7000")
BASE10000<-data.frame(AR_KEY=attr(itemlist,"intersections")[13],SERVICIO="1_5gbx10000")
BASE12000<-data.frame(AR_KEY=attr(itemlist,"intersections")[14],SERVICIO="1_5gbx12000")
BASE15000<-data.frame(AR_KEY=attr(itemlist,"intersections")[15],SERVICIO="2gbx15000")

colnames(BASE7000) <-c("AR_KEY","SERVICIO")
colnames(BASE10000) <-c("AR_KEY","SERVICIO")
colnames(BASE12000) <-c("AR_KEY","SERVICIO")
colnames(BASE15000) <-c("AR_KEY","SERVICIO")

BASE_PAQUETES_FEB <- rbind(BASE7000,BASE10000,BASE12000,BASE15000)



con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")

dbWriteTable(con,'TMP_BASE_PAQUETES_FEB_SOMBRA', BASE_PAQUETES_FEB, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
