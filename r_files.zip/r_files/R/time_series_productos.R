debug(utils:::unpackPkgZip)
install.packages('msts')

library('ggplot2')
library('forecast')
library('tseries')
library(ROracle)
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH")
tic()
query <- dbSendQuery(con,"

                    /* 
                     select sum(t.AMOUNT) as monto
                     ,TO_CHAR(t.FECHA, 'YYYY-MM-DD') as fecha
                     from rpl_tigo_cash.transaction t
                     where t.FECHA BETWEEN DATE'2016-01-01' AND DATE'2018-06-30'
                     and t.SERVICE_ID in (1)
                     group by TO_CHAR(t.FECHA, 'YYYY-MM-DD')
                     order by 2                   
                     */
                      SELECT sum(p.monto) as monto
                  ,TO_CHAR(p.fecha_datos, 'YYYY-MM-DD') as fecha
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos BETWEEN DATE'2016-01-01' AND DATE'2018-06-30'
                     --and p.servicio in ('Carga de dinero','Giros Nacionales')
                    and p.servicio in ('Retiro de dinero')
                     group by TO_CHAR(p.fecha_datos, 'YYYY-MM-DD')
                     order by 2
                     
                     
                     ")


result <- fetch(query)
toc()
df <- result
daily_data<-df
#daily_data<-edit(daily_data)
daily_data$FECHA<-as.Date(daily_data$FECHA,format="%Y-%m-%d")
#########################
##Step 1: Load R Packages 
#########################

## obteniendo el dato
##  https://archive.ics.uci.edu/ml/datasets/Bike+Sharing+Dataset
#daily_data = read.csv('day.csv', header=TRUE, stringsAsFactors=FALSE)

###########################
##Step 2: Examine Your Data
##########################
#daily_data$Date = as.Date(daily_data$dteday)


ggplot(daily_data, aes(FECHA, MONTO)) + geom_line() + scale_x_date('week')  + ylab("Daily Bike Checkouts") +  xlab("")



# R provides a convenient method for removing time series outliers: 
#   tsclean() as part of its forecast package. 
#   tsclean() identifies and replaces outliers using series smoothing and 
#   decomposition.
#This method is also capable of inputing missing values in the series 
#if there are any.
#Note that we are using the ts() command to create a time series object 
#to pass to tsclean():   

count_ts = ts(daily_data[, c('MONTO')])

daily_data$clean_cnt = tsclean(count_ts)
str(count_ts)
ggplot() +  geom_line(data = daily_data, aes(x = FECHA, y = clean_cnt)) + ylab('Cleaned Bicycle Count')

# The wider the window of the moving average, the smoother original series becomes. 
# In our bicycle example, we can take weekly or monthly moving average, 
# smoothing the series into something more stable and therefore predictable:

daily_data$cnt_ma = ma(daily_data$clean_cnt, order=7) # using the clean count with no outliers
daily_data$cnt_ma30 = ma(daily_data$clean_cnt, order=28)


ggplot() +
  #geom_line(data = daily_data, aes(x = FECHA, y = clean_cnt, colour = "Counts")) +
  #geom_line(data = daily_data, aes(x = FECHA, y = cnt_ma,   colour = "Weekly Moving Average"))  +
  geom_line(data = daily_data, aes(x = FECHA, y = cnt_ma30, colour = "Monthly Moving Average"))  +
  ylab('Cash In')

################################
### Step 3: Decompose Your Data
################################

count_ma = ts(na.omit(daily_data$cnt_ma), frequency=28)
decomp = stl(count_ma, s.window="periodic")
deseasonal_cnt <- seasadj(decomp)
plot(decomp)
