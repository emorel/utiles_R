#debug(utils:::unpackPkgZip)
#install.packages("imputeTS")

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)


###########################
############################


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                     b.zona
                     ,b.circuito
                     --,b.id_pdv
                     ,sum(b.poblacion) as poblacion
                     ,sum(b.cant_clientes) as cant_clientes
                     ,count(distinct b.id_pdv) as cantidad_pdv
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                     ,sum(b.ventas) as ventas
                     --,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes = 201812
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     group by 
                     b.zona
                     ,b.circuito
                     --,b.id_pdv
                     --,b.mes
                     order by 1
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
str(df)
dbDisconnect(con)


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                     b.zona
                     --,b.circuito
                     --,b.id_pdv
                     ,sum(b.poblacion) as poblacion
                     ,sum(b.cant_clientes) as cant_clientes
                     ,count(distinct b.id_pdv) as cantidad_pdv
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                     ,sum(b.ventas) as ventas
                     --,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes = 201812
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     group by 
                     b.zona
                     --,b.circuito
                     --,b.id_pdv
                     --,b.mes
                     order by 1
                     
                     
                     
                     ")
my_data_bkp<- fetch(query)
toc()
my_data<-my_data_bkp
dbDisconnect(con)



#library(DMwR)
#tic()
#df <- knnImputation(select(df,-ZONA,-CIRCUITO),k=3)
#toc()
#anyNA(df)
#df$ZONA <- df_bkp$ZONA
#df$CIRCUITO <- df_bkp$CIRCUITO
#df$MES <- df_bkp$MES

df<-select (df,ZONA,CIRCUITO,POBLACION,CANT_CLIENTES,CANTIDAD_PDV,HS_SIN_SALDO,VENTAS)



options(scipen=999)
telecomModel <- lm(VENTAS ~  POBLACION+CANT_CLIENTES+CANTIDAD_PDV+HS_SIN_SALDO-1 ,data=select(df,-ZONA,-CIRCUITO))

summary(telecomModel)

library(caret)
library(car)
vif(telecomModel)


## generamos las formulas por segmento
######################
##### POR ID_PDV####
######################
#str(my_data)
data<-df

df_coef<-data.frame(ZONA="ZONA",CIRCUITO="CIRCUITO"
                    ,POBLACION=as.numeric(coefficients(telecomModel)[1])
                    ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                    ,CANTIDAD_PDV=as.numeric(coefficients(telecomModel)[3])
                    ,HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
)

df_coef$ZONA<-as.character(df_coef$ZONA)
df_coef$CIRCUITO<-as.character(df_coef$CIRCUITO)



df_coef <- df_coef[0,]


#str(df_coef)
tic()
for (i in sort(unique(df$ZONA))) {
  data<-subset(df,df$ZONA ==i)
  #print(head(data))
  #print(i)
  telecomModel <- lm(VENTAS ~  POBLACION+CANT_CLIENTES+CANTIDAD_PDV+HS_SIN_SALDO-1 ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_por_circuito/residuals_ventas_quiebre_circuito_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  #print(i)
  #print(coefficients(telecomModel))
  ZONA<-as.character(data[1,1])
  CIRCUITO<-as.character(data[1,2])
  #ZONA=as.character(data[1,2])
  #NOMBRE_DEALER=as.character(data[1,3])
  New<-data.frame(ZONA=ZONA,CIRCUITO=CIRCUITO
                  ,POBLACION=as.numeric(coefficients(telecomModel)[1])
                  ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                  ,CANTIDAD_PDV=as.numeric(coefficients(telecomModel)[3])
                  ,HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
  )  
  
  df_coef<-rbind(df_coef,New)
  
  #print(coefficients(telecomModel))
}
toc()



df_coef_totales<-merge(df_coef,my_data,by="ZONA",all.x=TRUE,no.dups = FALSE)

df_coef_totales<-na.omit(df_coef_totales)

colnames(df_coef_totales)<-c("ZONA","CIRCUITO","POBLACION_C","CANT_CLIENTES_C","CANT_PDV_C","HS_SIN_SALDO_C","POBLACION","CANT_CLIENTES","CANT_PDV","HS_SIN_SALDO","VENTAS")

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_GESTION_OPTIMOS", df_coef_totales, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
