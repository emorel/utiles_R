
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)
library(stats)
library(lsr)

con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                    select sum(sw.AMOUNT) as monto
                    ,sw.SUBSCRIBER_ID
                     from rpl_tigo_cash.subscriber_wallet sw
                     where sw.FECHA = date'2018-06-20'
                      having sum(sw.AMOUNT) >0
                      group by sw.SUBSCRIBER_ID
                     
                     ")
t <- fetch(query)
toc()
summary(t)

# 
# xs=quantile(t$MONTO,c(0/5,1/5,2/5,3/5,4/5,5/5))
# xs[1]=xs[1]-.00005
# t <- t %>% mutate(MONTO_f=cut(t$MONTO, breaks=xs, labels=c("A","B","C","D","E")))
# boxplot(t$MONTO~t$MONTO_f,col=3:5)
# summary(t)


options(scipen=999)
breaks<-20000
t$SEGMENT <- cut( t$MONTO, breaks = breaks, dig.lab=10,ordered_result = TRUE)
t$SEGMENT_ORD <- cut( t$MONTO, breaks = breaks, dig.lab=10,ordered_result = TRUE,labels = 1:breaks)
summary(t)
str(t)
summary(t$SEGMENT)

#boxplot(t$MONTO~t$SEGMENT,col=3:5)
length(unique(t$SUBSCRIBER_ID))

t1<-subset(t, t$SUBSCRIBER_ID %in% sample(t$SUBSCRIBER_ID,50000))

write.table(t1,file = "C:/Users/expeam/Documents/segment/2018/agosto/segmentacion_ptm/monto_billetera.csv",sep = ";",row.names = FALSE)
