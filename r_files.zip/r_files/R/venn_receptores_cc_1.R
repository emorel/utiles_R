

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
SELECT distinct t.document_number
FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
                     LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON (T.PK_CATEGORIA=C.PK_CATEGORIA)
                     WHERE T.FECHA BETWEEN DATE'2016-02-28'-60 AND DATE'2016-02-28'
                     AND T.SERVICE_ID = 2
                     AND T.RESULT = 0
                     AND T.TYPE_AUX=1
                     AND T.WALLET_TYPE_ID = 1
                     AND T.document_number is not null
                     and T.document_number <> '1'
                     
                     
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
select distinct b.document_number
from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between DATE'2016-02-28'-60 AND DATE'2016-02-28'
                     and b.servicio = 'Transferencia Receptores'
                     and b.document_number is not null
                     and b.document_number <> '1'
                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
select distinct b.document_number
from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between DATE'2016-02-28'-60 AND DATE'2016-02-28'
                     and b.servicio = 'Giros Nacionales Receptores'
                     and b.document_number is not null
                     and b.document_number <> '1'

                      ")
base3 <- fetch(query)
toc()


#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  #x = list(wallet_l,smart_l,shop_l,tm_app_l),
  x = list(base1,base2,base3),
  #category.names = c("WALLET","SMART","SHOP_APP","TM_APP"),
  category.names = c("DIRECT_CASHIN","RECEPTORES_P2P","RECEPTORES_GIRO_OTC"),
  filename = 'C:/Users/expeam/Documents/segment/2018/junio/receptores_cc/venn_diagramm_receptores_feb2016.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple','green'),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 

