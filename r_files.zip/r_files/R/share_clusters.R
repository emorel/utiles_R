dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 7'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)


tic()
query <- dbSendQuery(con,"
                     
                      select count(*)
                      ,p.fnncl_pd_nm
                     from EXPEAM.base_finan_7_10_daily p
                     join expeam.tmp_ci_app_ussd b
                     on (p.ar_key=b.document_number)
                     where p.fct_dt_d between date'2018-01-01' and date'2018-06-30'
                     and p.fnncl_pd_nm in ('300MB+15MIN+WAx7000GSx2D','400MB+30MIN+WAx10000GSx3D')
                     and p.FNNCL_PD_SUB_TP_NM = 'Tigo Money Paquetigos'
                     group by p.fnncl_pd_nm
                                     
                     
                     ")
share1 <- fetch(query)
toc()
head(share1$`COUNT(*)`)
