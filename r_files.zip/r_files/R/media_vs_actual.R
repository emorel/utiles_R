

library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(ROracle)
library(tictoc)
library(gridExtra)
library(grid)


con <- dbConnect(Oracle(), user="expeam", password="!diciembre2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select 
                     max(fecha_datos) as fecha_datos
                     ,TO_CHAR(max(fecha_datos),'YYYYMMDD') as fecha_f
                     ,median(monto) as monto
                     ,semanadia
                     ,'MONTO PROMEDIO' as tipo
                     from
                     (
                     SELECT to_char(p.fecha_datos,'yyyymmddwd') as fechasemanadia
                     ,to_char(p.fecha_datos,'wd') as semanadia
                     ,p.fecha_datos
                     ,sum(p.monto) as monto
                     ,sum(p.cant_trx) as cant_trx
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2017-01-01' and date'2018-12-31'
                     and p.servicio in ('Envio','Envio App')
                     group by
                     to_char(p.fecha_datos,'yyyymmddwd')
                     ,to_char(p.fecha_datos,'wd')
                     ,p.fecha_datos
                     )
                     group by semanadia
                     
                     
                     ")
df_bkp <- fetch(query)
toc()

dfa1<-df_bkp[c("FECHA_DATOS","MONTO","TIPO")]



f<-seq(as.Date("2018/12/11"), as.Date("2018/12/17"), "days")

dfa1<-subset(dfa1,as.character(FECHA_DATOS) %in% as.character(f))


fc<-as.character(f)

for (i in 1:7)
{
  tic()
  query <- dbSendQuery(con,"
                       
                       
                       SELECT p.fecha_datos
                       ,sum(p.monto) as monto
                       ,'MONTO ACTUAL' as tipo
                       from tigo_cash_rpt.product_tracking p
                       where p.fecha_datos = to_date(:1,'yyyy-mm-dd')
                       and p.servicio in ('Envio','Envio App')
                       group by
                       p.fecha_datos
                       
                       ",data=fc[i])
  
  df_bkp <- fetch(query)
  toc()
  dfa2<-df_bkp
  
  dfa1<-rbind(dfa1,dfa2)
  
  
}


ggplot(dfa1,aes(FECHA_DATOS, MONTO, fill=TIPO,alpha=TIPO))+
  geom_bar(stat = "identity",position ="identity")+
  #scale_x_date(breaks=pretty_breaks(n=56))+
  scale_colour_manual(values=c("blue","grey")) +
  scale_fill_manual(values=c("blue","grey")) +
  scale_alpha_manual(values=c(.3, .9))+
  xlab("FECHA")+ 
  ylab("MONTO (MMG)")+
  theme(axis.text.x = element_text(angle=0,size = 20),axis.text.y = element_text(angle=0,size = 20),legend.position="none",title = element_text(size = 20))+
  theme(plot.title = element_text(hjust=0.5),legend.text = element_text(size = 30))


#tiff('C:/Users/expeam/Documents/segment/2018/12-diciembre/analisis_hora_trx/promedio_dia_1.tiff', width = 55, height = 25, units = 'in', res = 100)
#do.call(grid.arrange,p)
#dev.off()


