

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                    select t.document_number
                    from expeam.tmp_ci_60d t
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     select t.document_number
                    from expeam.tmp_ci_ekyc t
                     
                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                  select t.document_number
                  from expeam.tmp_ci_billetera_activa t
                                 
                     
                     
                     ")
base3 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
                     select t.document_number
                     from expeam.tmp_wallet_ci t
                     
                     
                     
                     ")
base4 <- fetch(query)
toc()



#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER
base4<-base4$DOCUMENT_NUMBER


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base4,base2),
  category.names = c("BASE_WALLET","EKYC"),
  filename = 'C:/Users/expeam/Documents/segment/2018/julio/pedidos_regional/venn_diagramm_ekyc_wallet_n.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c( 'purple',"green"),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 

