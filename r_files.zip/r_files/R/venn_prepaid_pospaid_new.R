

#upload library
library(VennDiagram)
library(tictoc)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                     select distinct a.AR_SSCRBR_DD as document_number
                     FROM db_panza.sgm_stg_cstmr2 a
                     where a.FCT_DT = date'2018-05-31'
                     and a.CSTMR_BASE = 'Existing'
                     and a.BS_UN_NM = 'Mobile'
                     and a.BS_LN_NM = 'Prepaid'
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
                     
                     select a.AR_SSCRBR_DD as document_number
                     FROM db_panza.sgm_stg_cstmr2 a
                     where a.FCT_DT in ( date'2018-07-31',date'2018-08-31')
                     and a.CSTMR_BASE = 'Existing'
                     and a.BS_UN_NM = 'Mobile'
                     and a.BS_LN_NM = 'Postpaid'                     
                     
                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                    /*select s.MSISDN as document_number
                     from rpl_tigo_cash.subscriber s
                     where s.FECHA = date'2018-08-31'
                     and s.DELETED is null*/


                     select a.AR_SSCRBR_DD as document_number
                     FROM db_panza.sgm_stg_cstmr2 a
                     where a.FCT_DT = date'2018-08-31'
                     and a.CSTMR_BASE = 'Existing'
                     and a.BS_UN_NM = 'Mobile'
                     and a.BS_LN_NM = 'Postpaid'  
intersect

                      select b.nro_cuenta as document_number
                    from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2018-08-31' -60 and date'2018-08-31'

                     
/*select p.nro_cuenta as document_number
from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-08-31' -60 and date'2018-08-31'
                     and p.servicio = 'Cobro de facturas'*/
                     
                     ")
base3 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     

                     
                     select b.nro_cuenta as document_number
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2018-08-31' -60 and date'2018-08-31'

                     
                     ")
base4 <- fetch(query)
toc()

#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER
base3[is.na(base3)]<-"1"
base4<-base4$DOCUMENT_NUMBER
base4[is.na(base4)]<-"1"

#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base2,base3),
  category.names = c("POSPAGO","TIGO MONEY"),
  filename = 'C:/Users/expeam/Documents/segment/2018/06-junio/prepaid_pospaid/venn_diagramm_pos_tigomoney_60d_solo_pos_ago2018_percent.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple'),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  print.mode = 'percent'
  
)

toc() 

