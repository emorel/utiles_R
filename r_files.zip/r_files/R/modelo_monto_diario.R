debug(utils:::unpackPkgZip)
install.packages('gtable')
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)
library(readxl)
library(DescTools)
library(metafor)

library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
SELECT 
to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,f.DAY_OF_WK
                     ,f.DAY_OF_MO
                     ,f.DAY_OF_YR
                     ,f.WK_OF_MO
                     ,f.WK_OF_YR
                     ,f.MO_OF_YR
                     ,f.QTR
                     ,decode(f.DAY_OF_WK,6,2,1) as WRK_DAY_F
                     ,sum(b.monto) as monto
                     FROM tigo_Cash_rpt.Base_Cliente_Mfs_Daily b
                     left join dtl.dt_dim f
                     on (b.fecha_datos = f.DT)
                     where b.fecha_datos between date'2015-01-01' and date'2018-02-28'
                     --and f.DAY_OF_WK = 7
                     and b.service_id in (1)
                     --and b.tipo = 'from OTC'
                     group by 
                     b.fecha_datos
                     ,f.DAY_OF_WK
                     ,f.DAY_OF_MO
                     ,f.DAY_OF_YR
                     ,f.WK_OF_MO
                     ,f.WK_OF_YR
                     ,f.MO_OF_YR
                     ,f.QTR
                     ,f.WRK_DAY_F
                     order by 1

                     
                     ")
df_backup <- fetch(query)
toc()
df<-df_backup[-c(1)]

#base_estudio_lluvia <- read_excel("segment/2018/febrero/estudio_lluvia/base_estudio_lluvia_2016_2017_2018_ASUNCION.xlsx",col_types = c("numeric", "numeric"))
#df<-base_estudio_lluvia

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df<-scale(df)
df<-as.data.frame(df)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df$DAY_OF_WK<-log(df$DAY_OF_WK)
df$DAY_OF_MO<-log(df$DAY_OF_MO)
df$DAY_OF_YR<-log(df$DAY_OF_YR)
df$WK_OF_MO<-log(df$WK_OF_MO)
df$WK_OF_YR<-log(df$WK_OF_YR)
df$QTR<-log(df$QTR)
df$WRK_DAY_F<-log(df$WRK_DAY_F)
df$MONTO<-log(df$MONTO)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

##correr tres veces minimo

outlierKD(df, MONTO)
yes
df<-na.omit(df)


##########
## MODELO
##########


telecomModel <- lm(MONTO ~ . ,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100

telecomModel <- lm(MONTO ~  DAY_OF_WK+DAY_OF_YR+WK_OF_MO+WK_OF_YR+MO_OF_YR+QTR,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100


df<-df_backup[-c(1,3,7)]

(1-MAE(telecomModel))*100
(1-MAPE(telecomModel))*100 ##only with positives data
(1-MSE(telecomModel))*100
(1-RMSE(telecomModel))*100

as.formula(
  paste0("y ~ ", round(coefficients(telecomModel)[1],2), "", 
         paste(sprintf(" %+.2f*%s ", 
                       coefficients(telecomModel)[-1],  
                       names(coefficients(telecomModel)[-1])), 
               collapse="")
  )
)
