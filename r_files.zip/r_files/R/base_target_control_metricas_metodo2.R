library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")


###############################
###Regularidad por servicio####
###############################

FINMES = c(
  
  "2018-04-01","2018-05-01","2018-06-01"
  ,"2018-07-01","2018-08-01","2018-09-01"
)
##########################
##se toma el primer mes##
##########################
c<-data.frame(FINMES[1],FINMES[1],FINMES[1],FINMES[1],FINMES[1],FINMES[1])
print(c)
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select
                    sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) as ARPU
                     ,sum(f.MB_DATA_TRAFFIC) as data_consumption
                     ,MAX(((TRUNC(last_day(to_date(:1,'YYYY-MM-DD'))) - TO_DATE(at.AR_ACTVN_DT_KEY,'yyyymmdd')) / 365)) AS tenure
                     ,MAX(g.CTY_NM) AS DISTRITO
                     ,max(upper(pd.dvc_sub_tp_nm)) as device_subtype
                     ,max(TRUNC((TRUNC(last_day(to_date(:2,'YYYY-MM-DD'))) - i.BRTHDY_DT) / 365)) AS EDAD
                     ,f.FCT_DT
                     ,f.AR_SSCRBR_DD
                     ,1 as tipo--target
                     from smy.ar_monthly_base_fct f
                     left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                     LEFT JOIN dtl.ar_adtnl_trckng_fct a ON (a.AR_KEY = f.AR_KEY)
                     LEFT JOIN DTL.BTS_DIM BT ON bt.BTS_KEY = a.BTS_KEY
                     LEFT JOIN dtl.geo_dim g ON bt.GEO_KEY = g.GEO_KEY
                     left join dtl.pd_dvc_mdl_dim pd on pd.pd_dvc_mdl_key = f.pd_dvc_mdl_key
                     LEFT JOIN dtl.mv_ip_dim i ON i.IP_KEY = at.CSTMR_DD
                     WHERE at.FCT_DT = last_day(to_date(:3,'YYYY-MM-DD'))
                     and f.FCT_DT= at.FCT_DT
                     and f.FCT_DT=a.FCT_DT
                     and g.CTY_NM <> 'To Be Determined'
                     AND months_between(f.FCT_DT, i.BRTHDY_DT) / 12 BETWEEN 20 AND 80
                     and f.AR_SSCRBR_DD in
                     (
                     
                     select * from expeam.TMP_BASE_CLIENTE_TARGET
                     
                     )
                     GROUP BY f.AR_SSCRBR_DD,f.FCT_DT
                     having sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) >0
                     union
                     select
                     sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) as ARPU
                     ,sum(f.MB_DATA_TRAFFIC) as data_consumption
                     ,MAX(((TRUNC(last_day(to_date(:4,'YYYY-MM-DD'))) - TO_DATE(at.AR_ACTVN_DT_KEY,'yyyymmdd')) / 365)) AS tenure
                     ,MAX(g.CTY_NM) AS DISTRITO
                     ,max(upper(pd.dvc_sub_tp_nm)) as device_subtype
                     ,max(TRUNC((TRUNC(last_day(to_date(:5,'YYYY-MM-DD'))) - i.BRTHDY_DT) / 365)) AS EDAD
                     ,f.FCT_DT
                     ,f.AR_SSCRBR_DD
                     ,0 as tipo--potencial
                     from smy.ar_monthly_base_fct f
                     left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                     LEFT JOIN dtl.ar_adtnl_trckng_fct a ON (a.AR_KEY = f.AR_KEY)
                     LEFT JOIN DTL.BTS_DIM BT ON bt.BTS_KEY = a.BTS_KEY
                     LEFT JOIN dtl.geo_dim g ON bt.GEO_KEY = g.GEO_KEY
                     left join dtl.pd_dvc_mdl_dim pd on pd.pd_dvc_mdl_key = f.pd_dvc_mdl_key
                     LEFT JOIN dtl.mv_ip_dim i ON i.IP_KEY = at.CSTMR_DD
                     WHERE at.FCT_DT = last_day(to_date(:6,'YYYY-MM-DD'))
                     and f.FCT_DT= at.FCT_DT
                     and f.FCT_DT=a.FCT_DT
                     and g.CTY_NM <> 'To Be Determined'
                     AND months_between(f.FCT_DT, i.BRTHDY_DT) / 12 BETWEEN 20 AND 80
                     and f.AR_SSCRBR_DD in
                     (
                     
                     select * from expeam.TMP_BASE_CLIENTE_CONTROL
                     
                     )
                     GROUP BY f.AR_SSCRBR_DD,f.FCT_DT
                     having sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) >0                     
                     
                     ", data=c)
df_bkp <- fetch(query)
df<-df_bkp
toc()
##################################
##se toman los meses siguientes##
#################################

for (c in FINMES[-c(1)]) {
  d<-data.frame(c,c,c,c,c,c)
  print(c)
  tic()
  query <- dbSendQuery(con,"
                       
                       
                     select
                    sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) as ARPU
                       ,sum(f.MB_DATA_TRAFFIC) as data_consumption
                       ,MAX(((TRUNC(last_day(to_date(:1,'YYYY-MM-DD'))) - TO_DATE(at.AR_ACTVN_DT_KEY,'yyyymmdd')) / 365)) AS tenure
                       ,MAX(g.CTY_NM) AS DISTRITO
                       ,max(upper(pd.dvc_sub_tp_nm)) as device_subtype
                       ,max(TRUNC((TRUNC(last_day(to_date(:2,'YYYY-MM-DD'))) - i.BRTHDY_DT) / 365)) AS EDAD
                       ,f.FCT_DT
                       ,f.AR_SSCRBR_DD
                       ,1 as tipo--target
                       from smy.ar_monthly_base_fct f
                       left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                       LEFT JOIN dtl.ar_adtnl_trckng_fct a ON (a.AR_KEY = f.AR_KEY)
                       LEFT JOIN DTL.BTS_DIM BT ON bt.BTS_KEY = a.BTS_KEY
                       LEFT JOIN dtl.geo_dim g ON bt.GEO_KEY = g.GEO_KEY
                       left join dtl.pd_dvc_mdl_dim pd on pd.pd_dvc_mdl_key = f.pd_dvc_mdl_key
                       LEFT JOIN dtl.mv_ip_dim i ON i.IP_KEY = at.CSTMR_DD
                       WHERE at.FCT_DT = last_day(to_date(:3,'YYYY-MM-DD'))
                       and f.FCT_DT= at.FCT_DT
                       and f.FCT_DT=a.FCT_DT
                       and g.CTY_NM <> 'To Be Determined'
                       AND months_between(f.FCT_DT, i.BRTHDY_DT) / 12 BETWEEN 20 AND 80
                       and f.AR_SSCRBR_DD in
                       (
                       
                       select * from expeam.TMP_BASE_CLIENTE_TARGET
                       
                       )
                       GROUP BY f.AR_SSCRBR_DD,f.FCT_DT
                       having sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) >0
                       union
                       select
                       sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) as ARPU
                       ,sum(f.MB_DATA_TRAFFIC) as data_consumption
                       ,MAX(((TRUNC(last_day(to_date(:4,'YYYY-MM-DD'))) - TO_DATE(at.AR_ACTVN_DT_KEY,'yyyymmdd')) / 365)) AS tenure
                       ,MAX(g.CTY_NM) AS DISTRITO
                       ,max(upper(pd.dvc_sub_tp_nm)) as device_subtype
                       ,max(TRUNC((TRUNC(last_day(to_date(:5,'YYYY-MM-DD'))) - i.BRTHDY_DT) / 365)) AS EDAD
                       ,f.FCT_DT
                       ,f.AR_SSCRBR_DD
                       ,0 as tipo--potencial
                       from smy.ar_monthly_base_fct f
                       left join dtl.ar_trckng_fct at on (at.AR_KEY = f.AR_KEY)
                       LEFT JOIN dtl.ar_adtnl_trckng_fct a ON (a.AR_KEY = f.AR_KEY)
                       LEFT JOIN DTL.BTS_DIM BT ON bt.BTS_KEY = a.BTS_KEY
                       LEFT JOIN dtl.geo_dim g ON bt.GEO_KEY = g.GEO_KEY
                       left join dtl.pd_dvc_mdl_dim pd on pd.pd_dvc_mdl_key = f.pd_dvc_mdl_key
                       LEFT JOIN dtl.mv_ip_dim i ON i.IP_KEY = at.CSTMR_DD
                       WHERE at.FCT_DT = last_day(to_date(:6,'YYYY-MM-DD'))
                       and f.FCT_DT= at.FCT_DT
                       and f.FCT_DT=a.FCT_DT
                       and g.CTY_NM <> 'To Be Determined'
                       AND months_between(f.FCT_DT, i.BRTHDY_DT) / 12 BETWEEN 20 AND 80
                       and f.AR_SSCRBR_DD in
                       (
                       
                       select * from expeam.TMP_BASE_CLIENTE_CONTROL
                       
                       )
                       GROUP BY f.AR_SSCRBR_DD,f.FCT_DT
                       having sum(f.REV_COMMUNICATION+f.REV_INFORMATION+f.REV_SOLUTION+f.REV_ENTERTAIMENT) >0                     
                       
                       
                       
                       
                       ", data=d)
  df_bkp <- fetch(query)
  df1<-df_bkp
  
  
  df<-rbind(df,df1)
  
  toc()
}

dfbkp<-df
############################
df$TIPO<-as.factor(df$TIPO)
df$DISTRITO<-as.factor(df$DISTRITO)
df$DEVICE_SUBTYPE<-as.factor(df$DEVICE_SUBTYPE)
###############
####BRACKETS###
###############
options(scipen=999)
breaks<-3
df$ARPU_B<- cut( df$ARPU, breaks = breaks, dig.lab=0,labels = c('BAJO','MEDIO','ALTO'),ordered_result = FALSE)
df$DATA_CONSUMPTION_B<- cut( df$DATA_CONSUMPTION, breaks = breaks, dig.lab=0,ordered_result = FALSE)
df$TENURE_B<- cut( df$TENURE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
df$EDAD_B<- cut( df$EDAD, breaks = breaks, dig.lab=0,labels = c('JOVEN','ADULTO','MAYOR'),ordered_result = FALSE)
#################


str(df)

minsert<-df

rs <- dbSendQuery(con, "truncate table expeam.TMP_BASE_CLIENTE_TARGET", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.TMP_BASE_CLIENTE_TARGET values(:1)", data=minsert)

dbCommit(con)
