debug(utils:::unpackPkgZip)
install.packages('gtable')


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
              select b.nro_cuenta
              ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
              ,b.monto
              from tigo_cash_rpt.base_cliente_mfs_daily b
              where b.fecha_datos between date'2016-01-01' and date'2018-02-28'
              and (b.service_id = 98 or b.servicio = 'Pago Mercad.' and b.tipo = 'from CARD')

                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
set.seed(123)
colnames(df) <- c("cust","date","sales")
str(df)
length(unique(df$cust))

dfCBS <- elog2cbs(df, T.cal = "2017-11-01")
str(dfCBS)
head(dfCBS, 5)

op <- par(mfrow = c(1, 2))
(k.wheat <- estimateRegularity(df, method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.mle <- estimateRegularity(df, method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)

##visualizar por cluster
plotTimingPatterns(subset(dfkl, cluster==1), n = 50, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
op <- par(mfrow = c(1, 2))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.mle <- estimateRegularity(subset(dfkl, cluster==6), method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)

estimateRegularity(subset(dfkl, cluster==1), method = "wheat")
estimateRegularity(subset(dfkl, cluster==2), method = "wheat")
estimateRegularity(subset(dfkl, cluster==3), method = "wheat")
estimateRegularity(subset(dfkl, cluster==4), method = "wheat")
estimateRegularity(subset(dfkl, cluster==5), method = "wheat")
estimateRegularity(subset(dfkl, cluster==6), method = "wheat")

####################
##Pareto/GGG MODEL###
#####################

# estimte Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 200,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)
# show estimates for first few customers
head(dfCBS[, c("x", "t.x", "x.star",
                    "xstar.pggg", "pactive.pggg", "palive.pggg")])
# report median cohort-level parameter estimates
round(apply(as.matrix(pggg.draws$level_2), 2, median), 3)

# report mean over median individual-level parameter estimates

median.est <- sapply(pggg.draws$level_1, function(draw) {
  apply(as.matrix(draw), 2, median)
})
round(apply(median.est, 1, mean), 3)

# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(dfCBS$x.star)),
      `Pareto/GGG` = round(sum(dfCBS$xstar.pggg)),
      `MBG/CNBD-k` = round(sum(dfCBS$xstar.mbgcnbd)),
      `Pareto/NBD (HB)` = round(sum(dfCBS$xstar.pnbd.hb)))


# error on customer level
mae <- function(act, est) {
  stopifnot(length(act)==length(est))
  sum(abs(act-est)) / sum(act)
}
mae.pggg <- mae(dfCBS$x.star, dfCBS$xstar.pggg)
mae.mbgcnbd <- mae(dfCBS$x.star, dfCBS$xstar.mbgcnbd)
#mae.pnbd.hb <- mae(dfCBS$x.star, dfCBS$xstar.pnbd.hb)

rbind(`Pareto/GGG` = c(`MAE` = round(mae.pggg, 3))
      ,`MBG/CNBD-k` = c(`MAE` = round(mae.mbgcnbd, 3))
      #,`Pareto/NBD (HB)` = c(`MAE` = round(mae.pnbd.hb, 3))
)

lift <- 1 - mae.pggg / mae.mbgcnbd
cat("Lift in MAE:", round(100*lift, 1), "%")


############
##K-MEANS###
############

dfk<-dfCBS
##excluimos la fecha y el nro_cuenta
dfksc<-scale(dfCBS[-c(1,6)])

fit <- kmeans(dfksc, 6, iter.max=3000)


table(fit$cluster)



barplot(table(fit$cluster), col="maroon")

pca <- prcomp(dfksc)
pca_dat <- mutate(fortify(pca), col=fit$cluster)

ggplot(pca_dat) +
  geom_point(aes(x=PC1, y=PC2, fill=factor(col)), size=3, col="#7f7f7f", shape=21) +
  scale_fill_viridis(name="Cluster", discrete=TRUE) + theme_bw(base_family="Helvetica")

dfk$cluster<-as.factor(fit$cluster)
##agregar cluster as df
dfkl<-merge(x = df, y = dfk[c(1,14)], by = "cust", all.x = TRUE)



p1<-ggplot(data = dfk, mapping = aes(x = cluster, y = sales)) +
  geom_boxplot()
p2<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
  geom_boxplot()
p3<-ggplot(data = dfk, mapping = aes(x = cluster, y = x)) +
  geom_boxplot()
p4<-ggplot(data = dfk, mapping = aes(x = cluster, y = t.x)) +
  geom_boxplot()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)



  #facet_wrap(~cluster,nrow = 1)

