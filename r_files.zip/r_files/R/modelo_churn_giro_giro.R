
library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)

con <- dbConnect(Oracle(), user="expeam", password="!agosto2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-06-01' and date'2018-07-31'
                     --and b.servicio = 'Carga de dinero'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
df<-subset(df, df$NRO_CUENTA %in% sample(df$NRO_CUENTA,10000))

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-06-01")
#dfk<-dfCBS

## Timing Patterns

#plotTimingPatterns(subset(df, cust %in% c('0961803029','0961860375','0971272790')), n = 150, T.cal = "2018-06-01",headers = c("Past", "Future"), title = "")

# # estimate Pareto/GGG
# tic()
# pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 100,chains = 1) # ~2mins on 2015 MacBook Pro
# toc()
# # generate draws for holdout period
# pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# # conditional expectations
# dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# # P(active)
# dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# # P(alive)
# dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)


str(dfCBS)
dfCBS<-dfCBS[-c(6,8)]
dfCBS$churn<-ifelse(dfCBS$x.star==0,1,0)
table(dfCBS$churn)


########
##CARGA#
########


tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-06-01' and date'2018-07-31'
                     and b.servicio = 'Carga de dinero'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     
                     
                     ")
df_carga <- fetch(query)
toc()

##filtramos los clientes obtenidos anteriormente
df_carga<-subset(df_carga,NRO_CUENTA %in% df$cust)


length(unique(df_carga$NRO_CUENTA))

df_carga$FECHA_DATOS <- as.Date(df_carga$FECHA_DATOS,  "%Y-%m-%d")

colnames(df_carga) <- c("cust","date","sales")
dfCBS_carga <- elog2cbs(df_carga,units = 'day' ,T.cal = "2018-06-01")


str(dfCBS_carga)
dfCBS_carga<-dfCBS_carga[-c(6,8)]
dfCBS_carga$churn_carga<-ifelse(dfCBS_carga$x.star==0,1,0)
table(dfCBS_carga$churn_carga)

dfCBSc<-merge(x = dfCBS, y = dfCBS_carga, by = "cust")


########
##GIRO#
########



tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-06-01' and date'2018-07-31'
                     and b.servicio = 'Giros Nacionales'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     
                     
                     ")
df_giro <- fetch(query)
toc()

##filtramos los clientes obtenidos anteriormente
df_giro<-subset(df_giro,NRO_CUENTA %in% df$cust)


length(unique(df_giro$NRO_CUENTA))

df_giro$FECHA_DATOS <- as.Date(df_giro$FECHA_DATOS,  "%Y-%m-%d")

colnames(df_giro) <- c("cust","date","sales")
dfCBS_giro <- elog2cbs(df_giro,units = 'day' ,T.cal = "2018-06-01")


str(dfCBS_giro)
dfCBS_giro<-dfCBS_giro[-c(6,8)]
dfCBS_giro$churn_giro<-ifelse(dfCBS_giro$x.star==0,1,0)
table(dfCBS_giro$churn_giro)

dfCBSg<-merge(x = dfCBSc, y = dfCBS_giro, by = "cust")



########
##TRANSFERENCIA#
########



tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-06-01' and date'2018-07-31'
                     and b.servicio = 'Transferencia'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     
                     
                     ")
df_transf <- fetch(query)
toc()

##filtramos los clientes obtenidos anteriormente
df_giro<-subset(df_giro,NRO_CUENTA %in% df$cust)


length(unique(df_giro$NRO_CUENTA))

df_giro$FECHA_DATOS <- as.Date(df_giro$FECHA_DATOS,  "%Y-%m-%d")

colnames(df_giro) <- c("cust","date","sales")
dfCBS_giro <- elog2cbs(df_giro,units = 'day' ,T.cal = "2018-06-01")


str(dfCBS_giro)
dfCBS_giro<-dfCBS_giro[-c(6,8)]
dfCBS_giro$churn_giro<-ifelse(dfCBS_giro$x.star==0,1,0)
table(dfCBS_giro$churn_giro)

dfCBSg<-merge(x = dfCBSc, y = dfCBS_giro, by = "cust")


