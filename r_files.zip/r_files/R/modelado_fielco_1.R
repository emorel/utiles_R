library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(dplyr)
con<-dbConnect(Oracle(),user="expeam",password="!febrero2018",dbname="DWH")
query<-dbSendQuery(con, "
  
                    select 
                   *
                   from  expeam.tmp_base_modelo_fielco_1
")
result <- fetch(query)

query<-dbSendQuery(con, "
  
                    select 
                   *
                   from  TIGO_CASH_RPT.V_BASEMICROCREDFIELCO_1003
")
result <- fetch(query)


t<-result
str(t)
t1<-select(t,c(ANTIGUEDAD_MESES
               ,EDAD
               ,REVENUE_PROM_4M
               ,MOROSO
               ))
t1<-na.omit(t1)
t1$MOROSO<-ifelse(t1$MOROSO=="SI",1,0)
str(t1)

t1$MOROSO <- as.factor(t1$MOROSO)
# t1$ANTIGUEDAD_MESES<-log(t1$ANTIGUEDAD_MESES)
# t1$EDAD<-log(t1$EDAD)
# t1$REVENUE_PROM_4M<-log(t1$REVENUE_PROM_4M)
# t1$RECARGA_PROM_4M<-log(t1$RECARGA_PROM_4M)
# str(t1)
##para prueba
library(readxl)
prueba_base_fielco <- read_excel("prueba_base_fielco.xlsx")
prueba_base_fielco<-as.data.frame(prueba_base_fielco)
df<-prueba_base_fielco
df$MOROSO <- as.factor(df$MOROSO)     
#GENERAR MODELO
df <- t1
set.seed(123)
sample <- sample.split(df$MOROSO,SplitRatio=0.70)
trainData <- subset(df,sample==TRUE)
testData <- subset(df,sample==FALSE)
telecomModel <- lm(MOROSO ~ EDAD+ANTIGUEDAD_MESES+REVENUE_PROM_4M,data=trainData)
#telecomModel <- glm(MOROSO ~ .,family=binomial(link="logit"),data=trainData)
print(summary(telecomModel))
test.predictions <- predict(telecomModel,newdata=testData,type="response")
fitted.results <- ifelse(test.predictions > 0.5,1,0)
testData$CHURN <- as.character(testData$MOROSO)
testData$CHURN[testData$CHURN=="NO"] <- "0"
testData$CHURN[testData$CHURN=="SI"] <- "1"
misClasificationError <- mean(fitted.results!=testData$CHURN)
print(misClasificationError)
accuracyRate <- 1-misClasificationError
print(accuracyRate)

cm<-table(testData$CHURN,test.predictions > 0.5)
Accuracy <- print((cm[2,2]+cm[1,1])/sum(cm) * 100)
Sensitivity<-print(cm[2,2]/(cm[2,2]+cm[1,2])*100)
Specificity<-print(cm[1,1]/(cm[1,1]+cm[2,1])*100)


#save(telecomModel,file = "factura_churn_model.rda")
#load("tv_churn_model.rda")

#GENERAR BASE
#t1<-select(t,c(ANTIGUEDAD_MESES,EDAD,REVENUE_PROM_4M))
#df <- t1
test.predictions <- predict(telecomModel,newdata=select(t,c(ANTIGUEDAD_MESES,EDAD,REVENUE_PROM_4M)),type="response")
t$MOROSO <- ifelse(test.predictions > 0.05,1,0)
#results <- cbind(fitted.results,df)
#str(df)
#df <- as.data.frame(df)
table(t$MOROSO)
base_fielco_min_moroso<-subset(t,MOROSO == 0 & REVENUE_PROM_4M>=100000)
table(base_fielco_min_moroso$MOROSO)
write.table(base_fielco_min_moroso$CLIENTE_MSISDN,"fielco_microcreditos_no_morosos.csv",row.names = FALSE,col.names = FALSE)


###############################################
#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)


# outlierKD(t1, ANTIGUEDAD_MESES)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, EDAD)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, REVENUE_PROM_4M)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, RECARGA_PROM_4M)
# yes
# t1<-na.omit(t1)
# 


#tomamos una muestra aleatoria

# t1<-subset(t1,AR_KEY %in% (sample(t1$AR_KEY,1700)))
# summary(t1)


t1<-select(t1,c(ANTIGUEDAD_MESES,EDAD,REVENUE_PROM_4M,RECARGA_PROM_4M,MOROSO))

t1<-escalc(measure = "RR",ai=ANTIGUEDAD_MESES,bi=EDAD,ci=REVENUE_PROM_4M,di=RECARGA_PROM_4M,data=t1)


str(t1)
rma.glmulti <- function(formula, data, ...)
  rma(formula, vi, data=data, method="ML", ...)

tic()
res <- glmulti(MOROSO ~ ANTIGUEDAD_MESES + EDAD + REVENUE_PROM_4M + RECARGA_PROM_4M, data=t1,level=1, fitfunction=rma.glmulti, crit="aicc", confsetsize=128)
toc()

#print(res)
plot(res)
tmp <- weightable(res)
#print(tmp)
tmp <- tmp[tmp$aicc <= min(tmp$aicc) + 2,]

tmp

plot(res,type = "s")

