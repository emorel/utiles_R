debug(utils:::unpackPkgZip)
remotes::install_github("erblast/oetteR")

debug(utils:::unpackPkgZip)
install.packages("pipelearner")

debug(utils:::unpackPkgZip)
devtools::install_github("drsimonj/pipelearner")

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)


###########################
############################


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
              select
              b.zona
              ,b.circuito
              --,b.id_pdv
              ,sum(b.poblacion) as poblacion
              ,sum(b.cant_clientes) as cant_clientes
              ,count(distinct b.id_pdv) as cantidad_pdv
              --,sum(b.ventas) as ventas
              ,sum(b.hs_sin_saldo) as hs_sin_saldo
              --,b.mes
              from expeam.base_distrib_kpi_mapeo b
              left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
              where b.mes = 201812
              and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
              and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
              group by 
              b.zona
              ,b.circuito
              --,b.id_pdv
              --,b.mes
              order by 1
                                   
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
str(df)
dbDisconnect(con)


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select
                      b.zona
                      --,b.circuito
                     --,b.id_pdv
                    ,sum(b.poblacion) as poblacion
                      ,sum(b.cant_clientes) as cant_clientes
                     ,count(distinct b.id_pdv) as cantidad_pdv
                     --,sum(b.ventas) as ventas
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                     --,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes = 201812
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     group by 
                      b.zona
                      --,b.circuito
                     --,b.id_pdv
                     order by 1
                     
                     
                     ")
my_data_bkp<- fetch(query)
toc()
my_data<-my_data_bkp
dbDisconnect(con)



#library(DMwR)
#tic()
#df <- knnImputation(select(df,-ZONA,-CIRCUITO),k=3)
#toc()
#anyNA(df)
#df$ZONA <- df_bkp$ZONA
#df$CIRCUITO <- df_bkp$CIRCUITO
#df$MES <- df_bkp$MES

df<-select (df,ZONA,CIRCUITO,POBLACION,CANT_CLIENTES,CANTIDAD_PDV,HS_SIN_SALDO)



options(scipen=999)
telecomModel <- lm(HS_SIN_SALDO ~  POBLACION+CANT_CLIENTES+CANTIDAD_PDV-1 ,data=select(df,-ZONA,-CIRCUITO))

summary(telecomModel)

library(caret)
library(car)
vif(telecomModel)


## generamos las formulas por segmento
######################
##### POR ID_PDV####
######################
#str(my_data)
data<-df

df_coef<-data.frame(ZONA="ZONA",CIRCUITO="CIRCUITO"
                    ,POBLACION=as.numeric(coefficients(telecomModel)[1])
                    ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                    ,CANTIDAD_PDV=as.numeric(coefficients(telecomModel)[3])
)

df_coef$ZONA<-as.character(df_coef$ZONA)
df_coef$CIRCUITO<-as.character(df_coef$CIRCUITO)


df_coef <- df_coef[0,]


#str(df_coef)
tic()
for (i in sort(unique(df$ZONA))) {
  data<-subset(df,df$ZONA ==i)
  #print(head(data))
  #print(i)
  telecomModel <- lm(HS_SIN_SALDO ~  POBLACION+CANT_CLIENTES+CANTIDAD_PDV-1 ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_por_circuito/residuals_ventas_quiebre_circuito_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  #print(i)
  #print(coefficients(telecomModel))
  ZONA<-as.character(data[1,1])
  CIRCUITO<-as.character(data[1,2])
  #ZONA=as.character(data[1,2])
  #NOMBRE_DEALER=as.character(data[1,3])
  New<-data.frame(ZONA=ZONA,CIRCUITO=CIRCUITO
                  ,POBLACION=as.numeric(coefficients(telecomModel)[1])
                  ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[2])
                  ,CANTIDAD_PDV=as.numeric(coefficients(telecomModel)[3])
  )  
  
  df_coef<-rbind(df_coef,New)
  
  #print(coefficients(telecomModel))
}
toc()



df_coef_totales<-merge(df_coef,my_data,by="ZONA",all.x=TRUE,no.dups = FALSE)

df_coef_totales<-na.omit(df_coef_totales)

colnames(df_coef_totales)<-c("ZONA","CIRCUITO","POBLACION_C","CANT_CLIENTES_C","CANT_PDV_C","POBLACION","CANT_CLIENTES","CANT_PDV","HS_SIN_SALDO")

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_CAPILARIDAD_OPTIMOS", df_coef_totales, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

##########################################
###########cut por circuito###############
##########################################


#########################################
#############ARPU_CLIENTE_C#############
##########################################

#data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZK000087')
breaks<-c(-Inf,quantile(data1$ARPU_CLIENTE_C,c(0,1/3,2/3,1), na.rm=T),Inf)
breaks = breaks + seq_along(breaks) * .Machine$double.eps
#breaks[1]=breaks[1]-10000000
#breaks[4]=breaks[4]+10000000
mylabels<-c("1.-MENOS","2.-IGUAL","3.-MAS")
#breaks<-data.frame(classIntervals(data1$ARPU_CLIENTE_C,n=breaks)[2])[,1]
data1$ARPU_CLIENTE_SGM<- cut( data1$ARPU_CLIENTE_C, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data1$ARPU_CLIENTE_SGM)

data1<-NA

tic()
for (i in sort(unique(df_coef_totales$CIRCUITO))) {
  data2<-subset(df_coef_totales,df_coef_totales$CIRCUITO ==i)
  #print(i)
  breaks<-quantile(data2$ARPU_CLIENTE_C,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-MENOS","2.-IGUAL","3.-MAS")
  data2$ARPU_CLIENTE_SGM<- cut( data2$ARPU_CLIENTE_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data1<-rbind(data1,data2)
}
toc()

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_PDV_CLIENTE_SGM", data1, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

###################################
#########HS_SIN_SALDO_C#########
###############################

#data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data3<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
breaks<-quantile(data3$HS_SIN_SALDO_C,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-10000000
breaks[4]=breaks[4]+10000000
mylabels<-c("1.-MAS","2.-IGUAL","3.-MENOS")
#breaks<-data.frame(classIntervals(data3$CANT_CLIENTES_C,n=breaks)[2])[,1]
data3$HS_SIN_SALDO_SGM<- cut( data3$HS_SIN_SALDO_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data3$HS_SIN_SALDO_SGM)

data3<-NA

tic()
for (i in sort(unique(df_coef_totales$CIRCUITO))) {
  data2<-subset(df_coef_totales,df_coef_totales$CIRCUITO ==i)
  breaks<-quantile(data2$HS_SIN_SALDO_C,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-MAS","2.-IGUAL","3.-MENOS")
  data2$HS_SIN_SALDO_SGM<- cut( data2$HS_SIN_SALDO_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data3<-rbind(data3,data2)
}
toc()

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_PDV_QUIEBRE_SGM", data3, overwrite = TRUE, append = FALSE)
dbDisconnect(con)






####################################################
####BRAKETS - CUT - break - quantiles - cuantiles###
####################################################

df_coef_sgm<-df_coef
df_coef_sgm<-df_coef_totales
options(scipen=999)

breaks<-5

mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")

#df_coef_sgm$cant_clientes_sgm<- cut( df_coef_sgm$CANT_CLIENTES_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
#table(df_coef_sgm$cant_clientes_sgm)

#df_coef_sgm$HS_SIN_SALDO_sgm<- cut( df_coef_sgm$HS_SIN_SALDO_C, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
#table(df_coef_sgm$HS_SIN_SALDO_sgm)

breaks<-data.frame(classIntervals(df_coef_sgm$CANT_CLIENTES,n=5)[2])[,1]
df_coef_sgm$CANT_CLIENTES_SGM<- cut( df_coef_sgm$CANT_CLIENTES, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df_coef_sgm$CANT_CLIENTES_SGM)

breaks<-data.frame(classIntervals(df_coef_sgm$HS_SIN_SALDO,n=5)[2])[,1]
df_coef_sgm$HS_SIN_SALDO_SGM<- cut( df_coef_sgm$HS_SIN_SALDO, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(df_coef_sgm$HS_SIN_SALDO_SGM)

#CUT POR QUANTILES - PRETTY PRINT

mylabels<-c("1.-MUY BAJO","2.-BAJO","3.-MEDIO","4.-ALTO","5.-MUY ALTO")
df_coef_sgm$cant_clientes_sgm<-cut(df_coef_sgm$CANT_CLIENTES_C,breaks=data.frame(classIntervals(df_coef_sgm$CANT_CLIENTES,n=5)[2])[,1],include.lowest=T,dig.lab=8,labels = mylabels)
table(df_coef_sgm$cant_clientes_sgm)
table(df_coef_sgm$CANT_CLIENTES_BKT)

df_coef_sgm$hs_sin_saldo_sgm<-cut(df_coef_sgm$HS_SIN_SALDO,breaks=data.frame(classIntervals(df_coef_sgm$HS_SIN_SALDO,n=5)[2])[,1],include.lowest=T,dig.lab=8,labels = mylabels)
table(df_coef_sgm$hs_sin_saldo_sgm)
table(df_coef_sgm$HS_SIN_SALDO_BKT)

#colnames(df_coef_sgm)<-c("ID_PDV","CANT_CLIENTES_C","HS_SIN_SALDO_C","CANT_CLIENTES_BKT","HS_SIN_SALDO_BKT")
con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_PDV_CLIENTE_QUIEBRE_SGM", df_coef_sgm, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

