debug(utils:::unpackPkgZip)
install.packages("imputeTS")

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)


############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select 
                      t.ciudad
                     ,t.zona
                     ,t.nombre_dealer 
                     ,t.mes
                     ,count(distinct t.id_pdv) as cant_pdv
                     
                     ,sum(t.horas_sin_saldo2) as hs_sin_saldo
                     ,sum(t.horas_sin_saldo2)/13*31*count(distinct t.id_pdv) as quiebre
                     ,sum(t.ventas) Ventas
                     ,sum(t.compras) compras
                     ,sum(t.cant_veces_sin_saldo) as cant_veces_sin_saldo
                    ,sum(p.cant_clientes) as cant_clientes_epin
                     from expeam.v_boc_epin_indirecta t
                     left join expeam.tmp_cant_clietes_pdv p on t.id_pdv = p.id_pdv and t.mes = p.mes
                     --where t.mes in (201801,201802,201803,201804,201805,201806,201807,201808,201809,201810,201811,201812)
                      where t.mes in (201812)
                     --and t.ciudad = '14 DE MAYO'
                     group by
                     t.ciudad
                     ,t.zona
                     ,t.nombre_dealer
                     ,t.mes
                     
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
my_data <- df
str(df)
dbDisconnect(con)

my_data <- na.omit(df)
my_data <- na.omit(df,cols=CIUDAD)
str(my_data)



options(scipen=999)



## generamos las formulas por segmento


#######################
##### POR CIUDAD######
######################

df_coef<-data.frame(CIUDAD="CIUDAD",ZONA="ZONA",NOMBRE_DEALER="NOMBRE_DEALER"
                    ,INTERCEPT=as.numeric(coefficients(telecomModel)[1]),CANT_PDV=as.numeric(coefficients(telecomModel)[2])
                    ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[3]),HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
                    ,COMPRAS=as.numeric(coefficients(telecomModel)[5])  )

df_coef$CIUDAD<-as.character(df_coef$CIUDAD)
df_coef$ZONA<-as.character(df_coef$ZONA)
df_coef$NOMBRE_DEALER<-as.character(df_coef$NOMBRE_DEALER)

df_coef<-df_coef[-c(1),]


#str(df_coef)

for (i in sort(unique(my_data$CIUDAD))) {
  data<-subset(my_data,CIUDAD ==i)
  #print(head(data))
  #print(i)
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO+COMPRAS ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_intervalos_confianza/residuals_ventas_quiebre_dealer_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  CIUDAD<-as.character(data[1,1])
  ZONA=as.character(data[1,2])
  NOMBRE_DEALER=as.character(data[1,3])
  New<-data.frame(CIUDAD=CIUDAD,ZONA=ZONA,NOMBRE_DEALER=NOMBRE_DEALER
             ,INTERCEPT=as.numeric(coefficients(telecomModel)[1]),CANT_PDV=as.numeric(coefficients(telecomModel)[2])
             ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[3]),HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
             ,COMPRAS=as.numeric(coefficients(telecomModel)[5])  )
  
  
  df_coef<-rbind(df_coef,New)

  #print(coefficients(telecomModel))
}




df_coef_totales<-merge(df_coef,my_data,by="CIUDAD",all.x=TRUE,no.dups = FALSE)

dbWriteTable(con,"TMP_QUIEBRE_COEF_TOTAL", df_coef_totales, rownames=FALSE, overwrite = TRUE, append = FALSE)

