debug(utils:::unpackPkgZip)
install.packages('Amelia')


library(TraMineR)
library(data.table)
library(dplyr)
library(bayesm)
library(NMF)
library("cluster")
library(WeightedCluster)
library(tictoc)
library("wesanderson")
library(ROracle)
library(viridis)
library(RColorBrewer)
library(gtools)
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     select * 
                      from expeam.tmp_base_ci_co_sts  t
                     where t.cant_base1 >0
                     
                     
                     ")
dfa1 <- fetch(query)
toc()
dfa<-dfa1
dfa<-dfa1[c(1,14,15,16,17,18)]

#dfa<-subset(dfa, dfa$DOCUMENT_NUMBER %in% sample(dfa$DOCUMENT_NUMBER,5000))
#dfa<-dcast(dfa,DOCUMENT_NUMBER ~ FECHA_DATOS,value.var = 'MONTO')
## Conteos
# dfa$CANT_NULL<-rowSums(is.na(dfa))
# 
# 
# dfa$CANT_CONV<-ifelse(dfa$`201710` == 'RETIRO_CC.',1,0)+
#   ifelse(dfa$`201711` == 'RETIRO_CC.',1,0)+
#   ifelse(dfa$`201712` == 'RETIRO_CC.',1,0)
# 





length(unique(dfa$DOCUMENT_NUMBER))

# dfa <- subset(dfa,CANT_CONV>0 & CANT_OTC >1)
# sample(dfa$DOCUMENT_NUMBER,5000)
# 
# length(unique(dfa$NRO_CUENTA))

str(dfa)
##insercion en base de datos
#base.insertar <- unique(dfa$DOCUMENT_NUMBER)
#rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
#rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
#dbCommit(con)
dfa[is.na(dfa)]<-'NO_ACTIVITY'

## para ordernar variables CHR numericas
mvad.scode<-seqstatl(dfa[-c(1,19)], var=NULL, format='STS')
mvad.scode<-mixedsort(mvad.scode)
mvad.scode

###
##PALETA DE COLORES
n <- length(mvad.scode)
paleta<-viridis_pal(option = "D")(n)  # n = number of colors seeked
pie(rep(1,n), col=paleta)

## otra manera
#qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
#col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
#pie(rep(1,n), col=sample(col_vector, n))
########
##generacion de graficos 
apc<-ncol(dfa)-1
#dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE ,right = "DEL",left = "DEL",gaps="DEL")
dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE,alphabet = mvad.scode, states = mvad.scode, labels = mvad.scode)

#SEQIPLOT
##
tiff('C:/Users/expeam/Documents/segment/2018/junio/bono/seqIplot_clientes_bono_billpay_p2p_68813_part.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, xtstep = 1,sortv="from.start",cex.legend=3,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - BONO - BILLPAY - N= 68.813")
dev.off()
##
#SEQDPLOT
##
tiff('C:/Users/expeam/Documents/segment/2018/junio/bono/seqdplot_clientes_bono_billpay_p2p_68813.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA,cex.legend=3,cex.main=4,cex.axis = 3,main="Share - BONO - BILLPAY - P2P N= 68.813")
dev.off()
##



##armado de clusters ## full matrix para reducir la matriz de distancias.. (utilizar with.missing para mostrar actividad)
dfa.om <- seqdist(dfa.seq, method = "OM", indel = 1, sm = "TRATE",with.missing = TRUE,full.matrix=FALSE)
tic()
clusterward <- agnes(dfa.om, diss = TRUE, method = "ward")
toc()
dfa.cl4 <- cutree(clusterward, k = 5)
cl4.lab <- factor(dfa.cl4, labels = paste("Cluster", 1:5))
###Extraer un cluster especifico
dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 2'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
dbCommit(con)
##
#SEQIPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/junio/bono/seqIplot_clientes_bono_billpay_6270_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, group = cl4.lab, xtstep = 1,sortv="from.start",cex.legend=8,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - BONO - BILLPAY - N= 6.270")
dev.off()
##
#SEQDPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/junio/bono/seqdplot_clientes_bono_billpay_6270_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA, group = cl4.lab,cex.legend=5,cex.main=4,cex.axis = 3,main="Share - BONO - BILLPAY - N= 6.270")
dev.off()
##

#LEGENDS
#tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_entrega_3487_c.tiff', width = 5, height = 10, units = 'in', res = 200)
#seqlegend(dfa.seq)
#dev.off()
