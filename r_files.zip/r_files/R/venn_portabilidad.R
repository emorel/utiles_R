

#upload library
library(VennDiagram)
library(tictoc)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!marzo2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                    SELECT i.IP_CD as DOCUMENT_NUMBER
                    from dtl.ar_trckng_fct a
                     left join dtl.prtblty_tp_dim p
                     on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                     LEFT JOIN dtl.mv_ip_dim i
                     ON (i.IP_KEY = a.CSTMR_DD)
                     where a.FCT_DT = trunc(sysdate-2)
                     and p.PRTBLTY_TP_NM = 'Ported OUT'
                     and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                     and i.IP_CD is not null
                    and i.IP_CD <> '1'
                     
                     
                     ")
portados <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
select  document_number
from
                     (
                     SELECT i.IP_CD as document_number
                     from dtl.ar_trckng_fct a
                     left join dtl.prtblty_tp_dim p
                     on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                     LEFT JOIN dtl.mv_ip_dim i
                     ON (i.IP_KEY = a.CSTMR_DD)
                     where a.FCT_DT = trunc(sysdate-2)
                     and p.PRTBLTY_TP_NM = 'Ported OUT'
                     and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                     
                     intersect
                     
                     select s.DOCUMENT_NUMBER
                     from rpl_tigo_cash.h_subscriber s
                     where s.FECHA = date'2017-11-30'
                     and s.DELETED is null
                      and s.DOCUMENT_NUMBER <> '1'
                      and s.DOCUMENT_NUMBER is not null
                     
                     )
                     
                     
                     ")
base1 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                      select document_number
                      from
                      (
                        SELECT i.IP_CD as document_number
                        from dtl.ar_trckng_fct a
                        left join dtl.prtblty_tp_dim p
                        on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                        LEFT JOIN dtl.mv_ip_dim i
                        ON (i.IP_KEY = a.CSTMR_DD)
                        where a.FCT_DT = trunc(sysdate-2)
                        and p.PRTBLTY_TP_NM = 'Ported OUT'
                        and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                        
                        intersect
                        
                        select s.DOCUMENT_NUMBER
                        from rpl_tigo_cash.h_subscriber s
                        where s.FECHA = date'2017-12-31'
                        and s.DELETED is null
                     and s.DOCUMENT_NUMBER <> '1'
                      and s.DOCUMENT_NUMBER is not null
)
                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
select  document_number
from
                     (
                     SELECT i.IP_CD as document_number
                     from dtl.ar_trckng_fct a
                     left join dtl.prtblty_tp_dim p
                     on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                     LEFT JOIN dtl.mv_ip_dim i
                     ON (i.IP_KEY = a.CSTMR_DD)
                     where a.FCT_DT = trunc(sysdate-2)
                     and p.PRTBLTY_TP_NM = 'Ported OUT'
                     and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                     
                     intersect
                     
                     select s.DOCUMENT_NUMBER
                     from rpl_tigo_cash.h_subscriber s
                     where s.FECHA = date'2018-01-31' 
                     and s.DELETED is null
                     and s.DOCUMENT_NUMBER <> '1'
                      and s.DOCUMENT_NUMBER is not null
                     
                     )
                     
                     ")
base3 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                     select  document_number
                     from
                     (
                     SELECT i.IP_CD as document_number
                     from dtl.ar_trckng_fct a
                     left join dtl.prtblty_tp_dim p
                     on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                     LEFT JOIN dtl.mv_ip_dim i
                     ON (i.IP_KEY = a.CSTMR_DD)
                     where a.FCT_DT = trunc(sysdate-2)
                     and p.PRTBLTY_TP_NM = 'Ported OUT'
                     and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                     
                     intersect
                     
                     select s.DOCUMENT_NUMBER
                     from rpl_tigo_cash.h_subscriber s
                     where s.FECHA = date'2018-02-28'      
                     and s.DELETED is null
                     and s.DOCUMENT_NUMBER <> '1'
                      and s.DOCUMENT_NUMBER is not null
                     
                     )
                     
                     ")
base4 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
                     select  document_number
                     from
                     (
                     SELECT i.IP_CD as document_number
                     from dtl.ar_trckng_fct a
                     left join dtl.prtblty_tp_dim p
                     on (a.PRTBLTY_TP_KEY=p.PRTBLTY_TP_KEY)
                     LEFT JOIN dtl.mv_ip_dim i
                     ON (i.IP_KEY = a.CSTMR_DD)
                     where a.FCT_DT = trunc(sysdate-2)
                     and p.PRTBLTY_TP_NM = 'Ported OUT'
                     and a.PRTBLTY_DT_KEY between 20171201 and 20171231
                     
                     intersect
                     
                     select s.DOCUMENT_NUMBER
                     from rpl_tigo_cash.h_subscriber s
                     where s.FECHA = date'2018-03-31'      
                     and s.DELETED is null
                     and s.DOCUMENT_NUMBER <> '1'
                     and s.DOCUMENT_NUMBER is not null
                     
                     )
                     
                     ")
base5 <- fetch(query)
toc()




#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
#portados<-portados$DOCUMENT_NUMBER
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER
base4<-base4$DOCUMENT_NUMBER
base5<-base5$DOCUMENT_NUMBER

#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  #x = list(wallet_l,smart_l,shop_l,tm_app_l),
  #x = list(base1,base4,base2,base3),
  #category.names = c("DIC17","MAR18","ENE18","FEB18"),
  x = list(base1,base2,base3),
  category.names = c("DIC17","ENE18","FEB18"),
  filename = 'C:/Users/expeam/Documents/segment/2018/abril/portabilidad/venn_diagramm_3m_percent.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple','blue'),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  print.mode = 'percent'
  
)

toc() 

