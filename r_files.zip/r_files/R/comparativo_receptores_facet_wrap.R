library(ROracle)
library(dplyr)
library(ggplot2)
library(reshape2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)

drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH")

query <- dbSendQuery(con,"
                     
                      select 
                      to_char(a.fecha_datos,'YYYY-MM-DD') as fecha
                     ,a.cantidad
                     ,a.categoria
                     from
                     (
                     select v.fecha_datos
                     ,v.cantidad
                     ,'RECEPTORES DE GIROS OTC' as categoria
                     from expeam.res_base_mfs_dai_cat_ci_60 v
                     where v.categoria in ('Giros Nacionales Receptores_6')
                     and v.fecha_datos between date'2016-01-01' and date'2018-05-31'
                     ) a
                     where a.fecha_datos = last_day(a.fecha_datos)
                     union all
                     select to_char(v.fecha_datos,'YYYY-MM-DD') as fecha
                     ,v.cantidad
                     ,'RECEPTORES DE P2P' as categoria
                     from expeam.res_base_mfs_dai_cat_ci_60 v
                     where v.categoria in ('Transferencia Receptores_7')
                     and v.fecha_datos between date'2016-01-01' and date'2018-05-31'
                     union all
                     select 
                     to_char(a.fecha_datos,'YYYY-MM-DD') as fecha
                     ,a.cantidad
                     ,a.categoria
                     from
                     (
                     select v.fecha_datos
                     ,v.cantidad
                     ,'RECEPTORES DE DIRECT CASHIN' as categoria
                     from expeam.res_base_mfs_dai_cat_ci_60 v
                     where v.categoria in ('Direct Cash In_8')
                     and v.fecha_datos between date'2016-01-01' and date'2018-05-31'
                     ) a
                     where a.fecha_datos = last_day(a.fecha_datos)
                     order by 3,1

                     ")


result <- fetch(query)
t <- result

t$FECHA <- as.Date(t$FECHA, format = "%Y-%m-%d")

tiff('C:/Users/expeam/Documents/segment/2018/junio/receptores_cc/comparativo_receptores_mayo2018.tiff', width = 25, height = 25, units = 'in', res = 300)
ggplot(t, aes(x=FECHA,y=CANTIDAD )) +
  ggtitle("RECEPTORES 60 DIAS")+
  geom_line()	+	
  scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  facet_wrap(~CATEGORIA, scales = 'free_y', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=30),plot.title = element_text(hjust = 0.5))
  #geom_text(aes(label=TIPO_DIA,color="Feriados"),size=10)
dev.off()
