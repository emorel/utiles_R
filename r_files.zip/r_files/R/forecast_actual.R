

library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(ROracle)
library(tictoc)
library(gridExtra)
library(grid)
library(scales)


con <- dbConnect(Oracle(), user="expeam", password="!diciembre2018", dbname="DWH/dwh_olap")


##################################
###GENERAMOS LOS DATOS ###########
#################################

dfinsert<-1

rs <- dbSendQuery(con, "DROP TABLE expeam.PRODUCT_TRACKING_REV_diario PURGE", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "CREATE TABLE expeam.PRODUCT_TRACKING_REV_diario compress AS SELECT * FROM expeam.v_product_tracking_rev_mensual", data=dfinsert)

dbCommit(con)




tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      SELECT 
                      p.fecha_datos
                     ,sum(p.monto)/1000000 as monto
                     ,'ACTUAL' as tipo
                     FROM expeam.product_tracking_rev_diario p 
                     WHERE p.fecha_datos between date'2018-12-01' and date'2018-12-31'
                     group by 
                     p.fecha_datos
                     union all
                     select t.fecha
                     ,sum(t.fcst_s_bptp)/1000000 as fcst_s_bptp
                     ,'FORECAST' as tipo
                     from PRODUCT_DAILY_BDGT_FCST_V4 t
                     WHERE t.fecha between date'2018-12-01' and date'2018-12-31'
                     group by  t.fecha
                     order by 3,1
                     
                     ")
df_bkp <- fetch(query)
toc()
dfa1<-df_bkp

str(dfa1)

dfa1$FECHA_DATOS<-as.Date(dfa1$FECHA_DATOS)

tiff('C:/Users/expeam/Documents/segment/2018/12-diciembre/forecast_actual/forecast_vs_actual.tiff', width = 55, height = 25, units = 'in', res = 100)
ggplot(dfa1,aes(FECHA_DATOS, MONTO, fill=TIPO,alpha=TIPO))+
  geom_bar(stat = "identity",position ="identity")+
  scale_x_date(breaks=pretty_breaks(n=30))+
  scale_colour_manual(values=c("blue","lightgray")) +
  scale_fill_manual(values=c("blue","lightgray")) +
  scale_alpha_manual(values=c(.9, .7))+
  xlab("FECHA")+ 
  ylab("MONTO (MMG)")+
  theme(axis.text.x = element_text(angle=90,size = 30),axis.text.y = element_text(angle=0,size = 50),legend.position="right",title = element_text(size = 50))+
  #ggtitle(paste(format(f[i],format="%a %m/%d/%y")))+
  theme(plot.title = element_text(hjust=0.5),legend.text = element_text(size = 50),legend.title=element_blank())
dev.off()


#tiff('C:/Users/expeam/Documents/segment/2018/12-diciembre/analisis_hora_trx/promedio_dia_1.tiff', width = 55, height = 25, units = 'in', res = 100)
#do.call(grid.arrange,p)
#dev.off()


