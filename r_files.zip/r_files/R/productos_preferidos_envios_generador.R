
con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")


n<- c("receptor_envio","minicarga","cobro_factura","retiro_dinero")
#l<-2:ncol(dfCBSl)
i<-1
#i=211
l<-as.vector(dfCBSl[i,-c(1)])
m<-c(dfCBSl[i,1],n[order(l, decreasing=TRUE)])
i=i+1
tic()
while (i<=nrow(dfCBSl)) {
  l<-as.vector(dfCBSl[i,-c(1)])
  m<-rbind(m,c(dfCBSl[i,1],n[order(l, decreasing=TRUE)]))
  print((i/197724)*100)
  i=i+1
}
toc()
m<-as.data.frame(m)
minsert<-m[c(1,2,3,4,5)]
rs <- dbSendQuery(con, "truncate table expeam.BASE_CLIENTE_PRODUCTO_PREF", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.BASE_CLIENTE_PRODUCTO_PREF values(:1,:2,:3,:4,:5,null,null,null)", data=minsert)

dbCommit(con)
