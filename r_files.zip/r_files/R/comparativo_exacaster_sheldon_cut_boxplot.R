

library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")


###############
####CONTROL###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select t.ar_sscrbr_dd,t.p,b.engagement_segment
                      from EXPEAM.T_ANTICHURN_10_FEB_19 t
                     join expeam.base_exacaster_antichurn b on t.ar_sscrbr_dd = '0'||b.sub_msisdn
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_control<-df_bkp
#df_control<-subset(df_control,df_control$AR_SSCRBR_DD %in%(sample(df_control$AR_SSCRBR_DD,size = 50000)))

length(unique(df_control$AR_SSCRBR_DD))
df_tg<-df_control
###############
####BRACKETS###
###############
options(scipen=999)
breaks<-3
df_tg$P_sgm<- cut( df_tg$P, breaks = breaks,dig.lab=4,ordered_result = FALSE)

base.insertar <-df_tg
rs <- dbSendQuery(con, "truncate table expeam.TMP_ANTICH_EXACASTER_SHELDON")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.TMP_ANTICH_EXACASTER_SHELDON values(:1,:2,:3,:4)", data=base.insertar)
dbCommit(con)

tiff('C:/Users/expeam/Documents/BI/2019/02-febrero/antichurn_/comparativo_exacaster.tiff', width = 35, height = 55, units = 'in', res = 300)
boxplot(P ~ ENGAGEMENT_SEGMENT, data = df_tg, xlab = "SEGMENTOS EXACASTER",
        ylab = "P.ALIVE", main = "DISTRIBUCION")

dev.off()

