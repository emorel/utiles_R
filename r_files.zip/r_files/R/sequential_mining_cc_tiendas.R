debug(utils:::unpackPkgZip)
install.packages('xts')


library(TraMineR)
library(data.table)
library(dplyr)
library(bayesm)
library(NMF)
library("cluster")
library(WeightedCluster)
library(tictoc)
library("wesanderson")
library(ROracle)
library(viridis)
library(RColorBrewer)
con <- dbConnect(Oracle(), user="expeam", password="!enero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"

SELECT * 
FROM expeam.tmp_base_cc_tiendas_sts b
--join expeam.tmp_ci_app_ussd t
--on (b.document_number=t.document_number)
where CANT_ENTREGA > 0
and CANT_RETIRO_CC = 0
and CANT_RETIRO_OTC = 0


                     
                     
                     ")
dfa <- fetch(query)


## Conteos
dfa$CANT_NULL<-rowSums(is.na(dfa))

dfa$CANT_CONV<-ifelse(dfa$`201710` == 'RETIRO_CC.',1,0)+
               ifelse(dfa$`201711` == 'RETIRO_CC.',1,0)+
               ifelse(dfa$`201712` == 'RETIRO_CC.',1,0)+
               ifelse(dfa$`201801` == 'RETIRO_CC.',1,0)  

dfa$CC_BEFORE<-ifelse(dfa$`201609` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201610` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201611` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201612` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201701` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201702` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201703` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201704` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201705` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201706` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201707` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201708` == 'RETIRO_CC.',1,0)+
  ifelse(dfa$`201709` == 'RETIRO_CC.',1,0)

dfa$CANT_OTC<-ifelse(dfa$`201609` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201610` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201611` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201612` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201701` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201702` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201703` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201704` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201705` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201706` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201707` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201708` == 'RETIRO_OTC.',1,0)+
              ifelse(dfa$`201709` == 'RETIRO_OTC.',1,0)




length(unique(dfa$DOCUMENT_NUMBER))

dfa <- subset(dfa,CC_BEFORE>0 )
length(unique(dfa$DOCUMENT_NUMBER))

summary(dfa)
##insercion en base de datos
#base.insertar <- unique(dfa$DOCUMENT_NUMBER)
#rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
#rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
#dbCommit(con)
###
##PALETA DE COLORES

n <- 1
paleta<-viridis_pal(option = "D")(n)  # n = number of colors seeked
pie(rep(1,n), col=paleta)
## otra manera
#qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
#col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
#pie(rep(1,n), col=sample(col_vector, n))
########
##generacion de graficos 
apc<-ncol(dfa)-7
#dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE ,right = "DEL",left = "DEL",gaps="DEL")
dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE)

#SEQIPLOT
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_retiro_otc_entrega_1312.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, xtstep = 1,sortv="from.start",cex.legend=7,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - CC en tiendas - Retiro OTC vs Retiro CC (NO TENIAN CC, NO USARON CC) - N= 1312")
dev.off()
##
#SEQDPLOT
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqdplot_clientes_cc_tiendas_retiro_otc_entrega_5961.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA,cex.legend=5,cex.main=4,cex.axis = 3,main="Share - CC en tiendas - Retiro OTC vs Retiro CC - N=  5.961")
dev.off()
##



##armado de clusters ## full matrix para reducir la matriz de distancias.. (utilizar with.missing para mostrar actividad)
dfa.om <- seqdist(dfa.seq, method = "OM", indel = 1, sm = "TRATE",with.missing = TRUE,full.matrix=FALSE)
tic()
clusterward <- agnes(dfa.om, diss = TRUE, method = "ward")
toc()
dfa.cl4 <- cutree(clusterward, k = 5)
cl4.lab <- factor(dfa.cl4, labels = paste("Cluster", 1:5))
###Extraer un cluster especifico
dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 2'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
dbCommit(con)
##
#SEQIPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_retiro_cc_537_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, group = cl4.lab, xtstep = 1,sortv="from.start",cex.legend=8,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - Retiro OTC vs Retiro CC - N= 537")
dev.off()
##
#SEQDPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqdplot_clientes_cc_tiendas_retiro_cc_vs_otc_5961_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA, group = cl4.lab,cex.legend=5,cex.main=4,cex.axis = 3,main="Share - CC en tiendas - Retiro OTC vs Retiro CC - N=  5.961")
dev.off()
##

#LEGENDS
#tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_entrega_3487_c.tiff', width = 5, height = 10, units = 'in', res = 200)
#seqlegend(dfa.seq)
#dev.off()
