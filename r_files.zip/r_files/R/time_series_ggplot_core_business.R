
library('ggplot2')
library('forecast')
library('tseries')
library(tidyr)
library(dplyr)
library(tictoc)
library(ROracle)
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH")
tic()
query <- dbSendQuery(con,"
                     
                    SELECT 
                      TO_CHAR(p.fecha_datos, 'YYYY-MM-DD') as fecha
                     ,case when p.servicio in ('Giros Nacionales','Carga de dinero') then 'Carga de dinero'
                     else 'Retiro de dinero' end as servicio
                     ,sum(p.monto) as monto
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos BETWEEN DATE'2016-01-01' AND DATE'2018-06-30'
                     and p.servicio in ('Giros Nacionales','Retiro de dinero','Carga de dinero')
                     group by TO_CHAR(p.fecha_datos, 'YYYY-MM-DD'),case when p.servicio in ('Giros Nacionales','Carga de dinero') then 'Carga de dinero'
                     else 'Retiro de dinero' end
                     order by 2,1
                     
                     ")


result <- fetch(query)
toc()
df <- result
df$FECHA<-as.Date(df$FECHA)
df$SERVICIO<-as.factor(df$SERVICIO)
str(df)

count_ts = ts(df[, c('MONTO')])

df$clean_cnt = tsclean(count_ts)
df$cnt_ma30 = ma(df$MONTO, order=28)




ggplot(df, aes(x = FECHA, y = cnt_ma30)) + 
  geom_line(aes(color = SERVICIO), size = 1) +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) +
  theme_minimal()

ggplot(df, aes(x = FECHA, y = MONTO)) + 
  geom_area(aes(color = SERVICIO, fill = SERVICIO), 
            alpha = 0.2, position = position_dodge(0.5)) +
  scale_color_manual(values = c("#00AFBB", "#E7B800")) +
  scale_fill_manual(values = c("#00AFBB", "#E7B800"))
