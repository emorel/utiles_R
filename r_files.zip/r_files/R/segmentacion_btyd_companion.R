
library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)

con <- dbConnect(Oracle(), user="expeam", password="!agosto2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2016-01-01' and date'2017-12-31'
                     /*AND ((b.servicio = 'Pago Mercad.' and b.tipo = 'from CARD')
                     OR (b.servicio = 'Retiro de dinero con PIN incl' and b.tipo = 'from ATM'))*/
                      --AND (b.servicio = 'Retiro de dinero con PIN incl' and b.tipo = 'from ATM')
                      and b.servicio = 'Minicarga'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
df<-subset(df, df$NRO_CUENTA %in% sample(df$NRO_CUENTA,50000))

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-10-01")
dfk<-dfCBS

dfksc<-scale(dfCBS[-c(1,6,8)])



fit <- kmeans(dfksc, 6, iter.max=3000)



dfk$cluster<-as.factor(fit$cluster)
dfkl<-merge(x = df, y = dfk[c(1,11)], by = "cust", all.x = TRUE)


## Timing Patterns
op <- par(mfrow = c(2, 3))
p1<-plotTimingPatterns(subset(dfkl, cluster==1), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
p2<-plotTimingPatterns(subset(dfkl, cluster==2), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
p3<-plotTimingPatterns(subset(dfkl, cluster==3), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
p4<-plotTimingPatterns(subset(dfkl, cluster==4), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
p5<-plotTimingPatterns(subset(dfkl, cluster==5), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
p6<-plotTimingPatterns(subset(dfkl, cluster==6), n = 150, T.cal = "2017-10-01",headers = c("Past", "Future"), title = "")
par(op)

###  BOX Plot Parametros

p1<-ggplot(data = dfk, mapping = aes(x = cluster, y = sales)) +
  geom_boxplot()
p2<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
  geom_boxplot()
p3<-ggplot(data = dfk, mapping = aes(x = cluster, y = x)) +
  geom_boxplot()
p4<-ggplot(data = dfk, mapping = aes(x = cluster, y = t.x)) +
  geom_boxplot()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)


## Regularity
op <- par(mfrow = c(2, 3))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==1), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==2), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==3), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==4), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==5), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
par(op)

###cada cuantos dias transaccionan


(nbd.EstimateParameters(subset(dfk,cluster==1))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==1))[1])
(nbd.EstimateParameters(subset(dfk,cluster==2))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==2))[1])
(nbd.EstimateParameters(subset(dfk,cluster==3))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==3))[1])
(nbd.EstimateParameters(subset(dfk,cluster==4))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==4))[1])
(nbd.EstimateParameters(subset(dfk,cluster==5))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==5))[1])
(nbd.EstimateParameters(subset(dfk,cluster==6))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==6))[1])





##Generamos un vector con los mejores clusters

cluster<-unique(fit$cluster)
clust<-NULL
for (i in cluster) {
  if ((k.wheat <- estimateRegularity(subset(dfkl, cluster==i), method = "wheat", title = "Wheat & Morrison")) >1) {
    clust<-c(clust,i)
  }
}

table(fit$cluster)

dfinsert<-subset(dfk[,c("cust","cluster")],cluster %in% clust)

rs <- dbSendQuery(con, "truncate table expeam.base_para_bulk", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.base_para_bulk values(:1,:2)", data=dfinsert)

dbCommit(con)




query <- dbSendQuery(con,"
                     
                     
                    select count(distinct b.nro_cuenta) as cant_clientes
                      --,sum(b.cant) as monto
                      --,sum(b.monto)/1000000 as monto
                      ,sum(b.monto)/sum(b.cant) as monto
                     ,'cluster '||e.clust as \"CLUSTER\"
                     ,to_char(b.fecha_datos,'YYYYMM') as fecha
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.base_para_bulk e
                     on (b.nro_cuenta= e.document_number)
                     where b.fecha_datos between date'2016-01-01' and date'2018-07-31'
                     /*AND ((b.servicio = 'Pago Mercad.' and b.tipo = 'from CARD')
                     OR (b.servicio = 'Retiro de dinero con PIN incl' and b.tipo = 'from ATM'))*/
                     -- AND (b.servicio = 'Retiro de dinero con PIN incl' and b.tipo = 'from ATM')
                    and b.servicio = 'Minicarga'
                     AND b.nro_cuenta not in
                     (select f.nro_linea from expeam.funcionarios f)
                     group by e.clust
                     ,to_char(b.fecha_datos,'YYYYMM')

                     ")


result <- fetch(query)
t <- result
str(t)
#t$FECHA <- as.Date(t$FECHA, format = "%Y%m")

#tiff('C:/Users/expeam/Documents/segment/2018/junio/analisis_semana_revenue/comparativo_selftopup_ticket_mayo2018_m.tiff', width = 45, height = 35, units = 'in', res = 300)
ggplot(t, aes(x=FECHA,y=MONTO/1000)) +
  ggtitle("PERFORMANCE POR CLUSTERS")+
  geom_bar(stat="identity")+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=13),plot.title = element_text(hjust = 0.5))
#geom_text(aes(label=TIPO_DIA,color="Feriados"),size=10)
#dev.off()

