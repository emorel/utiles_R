
library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(dplyr)
library(scales)
library(ggplot2)
library(reshape2)
library(data.table)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")



tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select 
                     m.ar_sscrbr_dd
                     ,m.data_lmt
                     ,m.mb_data_traffic
                     ,m.reportado
                     ,to_char(m.fecha,'YYYY-MM-DD') as fecha
                     from expeam.tmp_base_pospago_mb_consumo m
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)

df<-df_control
str(df)

df$FECHA<-as.Date(fasttime::fastPOSIXct(format(df$FECHA)))


str(df)
tail(df)


df<-na.omit(df)

options(scipen=999)
breaks<-5000
df$DATA_LMT_BRACKET<- cut( df$DATA_LMT, breaks = breaks,dig.lab=5,ordered_result = TRUE )

#unique(df$DATA_LMT_BRACKET)

df_sum_brk<-select(df,MB_DATA_TRAFFIC,DATA_LMT_BRACKET,FECHA) %>%
  group_by (DATA_LMT_BRACKET,FECHA) %>%
  summarize(MB_DATA_TRAFFIC_SUM=median(MB_DATA_TRAFFIC))

write.table(df_sum_brk,"C:/Users/expeam/Documents/BI/2019/02-febrero/pospago_brackets_consumo/graficos/plan_bracket_traffic_tabla_panter.csv",sep=";",row.names = FALSE)

tiff('C:/Users/expeam/Documents/BI/2019/02-febrero/pospago_brackets_consumo/graficos/plan_bracket_traffic_tabla_panter.tiff', width = 75, height = 55, units = 'in', res = 200)

ggplot(df_sum_brk,aes(x=FECHA,y=MB_DATA_TRAFFIC_SUM))+
  #geom_line(color="blue",size=1)+
  scale_x_date(breaks = pretty_breaks(n=25))+
  facet_wrap(~DATA_LMT_BRACKET,scales = "free_y",nrow=breaks,ncol=1)+
  theme(axis.text.x = element_text(angle = 45))+
  geom_smooth(span=0.5,method='loess',size=0.5)+
  #geom_point(size=1,color="blue")+
  theme(text=element_text(size=32))
dev.off()

