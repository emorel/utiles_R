
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)
library(readxl)
library(DescTools)

library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
with
monto_retiro as
(
select 
to_char(b.fecha_datos,'YYYYMM') as mes
,sum(b.cant)*2500 as revenue_retiro
,sum(b.cant) as cant_retiro
from tigo_cash_rpt.base_cliente_mfs_daily b
where b.fecha_datos between date'2016-01-01' and date'2018-02-28'
and (/*b.service_id = 5 and b.tipo ='from CARD' or*/ b.service_id = 98)
and b.nro_cuenta not in (select f.nro_linea from expeam.funcionarios f)
group by to_char(b.fecha_datos,'YYYYMM')
)
,monto_compra as
(
select 
to_char(b.fecha_datos,'YYYYMM') as mes
,sum(b.monto)*.01 as revenue_compra
,sum(b.cant) as cant_compra
from tigo_cash_rpt.base_cliente_mfs_daily b
where b.fecha_datos between date'2016-01-01' and date'2018-02-28'
and (b.service_id = 5 and b.tipo ='from CARD'/* or b.service_id = 98*/)
and b.nro_cuenta not in (select f.nro_linea from expeam.funcionarios f)
group by to_char(b.fecha_datos,'YYYYMM')
)

select 
monto_retiro.mes 
,monto_retiro.revenue_retiro
,monto_retiro.cant_retiro
,monto_compra.revenue_compra
,monto_compra.cant_compra
from monto_retiro
join monto_compra
on (monto_retiro.mes=monto_compra.mes) 
order by 1
                     ")
df_backup <- fetch(query)
toc()

df<-df_backup
str(df)

df<-select (df,c(REVENUE))
df$BASE_COMPRA<-as.integer(as.character(base_30d$COMPRA))
df$BASE_RETIRO<-as.integer(as.character(base_30d$RETIRO))

write.table(df,"base_cc.csv",sep = ";")


df<-as.data.frame(df)
#base_estudio_lluvia <- read_excel("segment/2018/febrero/estudio_lluvia/base_estudio_lluvia_2016_2017_2018_ASUNCION.xlsx",col_types = c("numeric", "numeric"))
#df<-base_estudio_lluvia

plot(df)
chart.Correlation(df[-c(1)], histogram=TRUE, pch=19)

df<-scale(df)
df<-as.data.frame(df)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df$REVENUE<-log(df$REVENUE)
df$CANTIDAD<-log(df$CANTIDAD)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

str(df)
##correr tres veces minimo

outlierKD(df, REVENUE)
yes
df<-na.omit(df)
outlierKD(df, CANTIDAD)
yes
df<-na.omit(df)

##########
## MODELO
##########


telecomModel <- lm((REVENUE_RETIRO+REVENUE_COMPRA) ~ CANT_RETIRO+CANT_COMPRA+BASE_RETIRO+BASE_COMPRA,data=df)
print(summary(telecomModel))


(1-MAE(telecomModel))*100
#(1-MAPE(telecomModel))*100
(1-MSE(telecomModel))*100
(1-RMSE(telecomModel))*100

as.formula(
  paste0("y ~ ", round(coefficients(telecomModel)[1],2), "", 
         paste(sprintf(" %+.2f*%s ", 
                       coefficients(telecomModel)[-1],  
                       names(coefficients(telecomModel)[-1])), 
               collapse="")
  )
)