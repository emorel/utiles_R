library(dplyr)
library(ggplot2)

par(mfrow=c(2,2)) 

plot(select(t,c(edad_rango,MOROSO)))
plot(select(t,c(antiguedad_mes_rango,MOROSO)))
plot(select(t,c(revenue_rango,MOROSO)))
plot(select(t,c(recarga_rango,MOROSO)))

ggplot(data = t) +
  geom_histogram(mapping = aes(x = REVENUE_PROM_4M/1000), binwidth = 10)

ggplot(data = t, mapping = aes(x = REVENUE_PROM_4M/1000, colour = MOROSO)) +
  geom_freqpoly(binwidth = 10)

ggplot(data = t, mapping = aes(x = REVENUE_PROM_4M/1000)) + 
  geom_freqpoly(mapping = aes(colour = MOROSO), binwidth = 10)

ggplot(data = t, mapping = aes(x = MOROSO, y = REVENUE_PROM_4M/1000)) +
  geom_boxplot()

ggplot(data = t, mapping = aes(x = MOROSO, y = RECARGA_PROM_4M/1000)) +
  geom_boxplot()

ggplot(data = t, mapping = aes(x = MOROSO, y = EDAD)) +
  geom_boxplot()

ggplot(data = t, mapping = aes(x = MOROSO, y = ANTIGUEDAD_MESES)) +
  geom_boxplot()


t$category<-as.factor(t$category)

ggplot(data = subset(t,MOROSO)) +
  geom_histogram(mapping = aes(x = RECARGA_PROM_4M/1000), binwidth = 100)

ggplot(data = t) +
  geom_count(mapping = aes(x = RECARGA_PROM_4M/1000, y = MOROSO))

t %>% 
  count(MOROSO, RECARGA_PROM_4M/1000) %>%  
  ggplot(mapping = aes(x = MOROSO, y = RECARGA_PROM_4M/1000)) +
  geom_tile(mapping = aes(fill = n))


xs=quantile(t$size,c(0,1/3,2/3,1))
xs[1]=xs[1]-.00005
t <- t %>% mutate(size_f=cut(t$size, breaks=xs, labels=c("low","middle","high")))
boxplot(t$size~t$size_f,col=3:5)

t <-select(t,-category_f)

