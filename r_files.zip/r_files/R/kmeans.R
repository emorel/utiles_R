

library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(sampling)
library(SamplingStrata)
library(splitstackshape)
library(classInt)

##########
###OUTLIERS###
#########

## FUNCION ELIMINAR OUTLIERS
outlierKD <- function(dt, var) {
  var_name <- eval(substitute(var),eval(dt))
  na1 <- sum(is.na(var_name))
  m1 <- mean(var_name, na.rm = T)
  par(mfrow=c(2, 2), oma=c(0,0,3,0))
  #boxplot(var_name, main="With outliers")
  #hist(var_name, main="With outliers", xlab=NA, ylab=NA)
  outlier <- boxplot.stats(var_name)$out
  mo <- mean(outlier)
  var_name <- ifelse(var_name %in% outlier, NA, var_name)
  #boxplot(var_name, main="Without outliers")
  #hist(var_name, main="Without outliers", xlab=NA, ylab=NA)
  #title("Outlier Check", outer=TRUE)
  na2 <- sum(is.na(var_name))
  cat("Outliers identified:", na2 - na1, "n")
  cat("Propotion (%) of outliers:", round((na2 - na1) / sum(!is.na(var_name))*100, 1), "n")
  cat("Mean of the outliers:", round(mo, 2), "n")
  m2 <- mean(var_name, na.rm = T)
  cat("Mean without removing outliers:", round(m1, 2), "n")
  cat("Mean if we remove outliers:", round(m2, 2), "n")
  #response <- readline(prompt="Do you want to remove outliers and to replace with NA? [yes/no]: ")
  #if(response == "y" | response == "yes"){
  dt[as.character(substitute(var))] <- invisible(var_name)
  assign(as.character(as.list(match.call())$dt), dt, envir = .GlobalEnv)
  cat("Outliers successfully removed", "n")
  return(invisible(dt))
  #} else{
  #     cat("Nothing changed", "n")
  #     return(invisible(var_name))
  #}
}


###############
####TARGET###
###############
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select t.nro_cuenta
                     ,sum(t.revenue_mfs)/6 as revenue_mfs
                     ,sum(t.monto)/6 as monto_mfs
                     ,sum(t.arpu_mobile)/6 as arpu_mobile  
                     from TMP_BASE_MFS_BAJA_MET t
                     --where t.fct_dt = date'2018-12-31'
                     group by t.nro_cuenta
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
dbDisconnect(con)
df<-df_bkp

summary(df)

df$REVENUE_MFS<-ifelse(df$REVENUE_MFS<0,0,df$REVENUE_MFS)
df$MONTO_MFS<-ifelse(df$MONTO_MFS<0,0,df$MONTO_MFS)
df$ARPU_MOBILE<-ifelse(df$ARPU_MOBILE<0,0,df$ARPU_MOBILE)

summary(df)

###eliminamos outliers
outlierKD(df, REVENUE_MFS)
outlierKD(df, MONTO_MFS)
outlierKD(df, ARPU_MOBILE)
###################
df<-na.omit(df)
##################


boxplot(df$REVENUE_MFS,main="REVENUE MFS")
boxplot(df$MONTO_MFS,main="MONTO MFS")
boxplot(df$ARPU_MOBILE,main="ARPU MOBILE")

#KMEANS
##saber cuantos clusters
mydata<-df[,-c(1)]
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

fit <- kmeans(mydata, 8) # 5 cluster solution
# get cluster means 
aggregate(mydata,by=list(fit$cluster),FUN=mean)
aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$CLUSTER_NRO <- fit$cluster

base.insertar<-df
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_BASE_MFS_BAJA_MET_CL", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

