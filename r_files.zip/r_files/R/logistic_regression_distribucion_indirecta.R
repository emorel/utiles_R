
#debug(utils:::unpackPkgZip)
#install.packages("oddsratio")

#debug(utils:::unpackPkgZip)
#install.packages("ggplot2")
##############logistic regression kpi indirecta distribucion
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)
library(classInt)
library(car)

library(tidyverse)
library(caret)



############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
with
base_epin_antes as
                     (
                     select 
                     t.zona
                     ,t.circuito
                     ,sum(t.cant_clientes) as cant_clientes
                     ,sum(t.cant_pdv) as cant_pdv
                     ,sum(t.hs_sin_saldo) as quiebre
                     ,sum(t.ventas) as ventas
                     from BASE_DISTRIB_CLUSTER t
                     where t.mes = 201302
                     group by 
                     t.zona
                     ,t.circuito
                     )
                     ,base_epin_despues as
                     (
                     select 
                     t.zona
                     ,t.circuito
                     ,sum(t.cant_clientes) as cant_clientes
                     ,sum(t.cant_pdv) as cant_pdv
                     ,sum(t.hs_sin_saldo) as quiebre
                     ,sum(t.ventas) as ventas
                     from BASE_DISTRIB_CLUSTER t
                     where t.mes = 201902
                     group by 
                     t.zona
                     ,t.circuito
                     )
                     select 
                     a.zona
                     ,a.circuito
                      ,d.cant_clientes-a.cant_clientes as VAR_CLIENTE
                     ,d.cant_pdv-a.cant_pdv as VAR_PDV
                     ,d.quiebre-a.quiebre as VAR_QUIEBRE
                     --,d.ventas-a.ventas as ventas
                     ,case when d.ventas-a.ventas < 0 then 1
                     else 0 end as tipo1
                     from base_epin_antes a
                     join base_epin_despues d on a.CIRCUITO = d.CIRCUITO
                    --where a.zona = 'ALTO PARAN�'
                    --where a.zona = 'AMAMBAY'
                    --where a.zona = 'ASUNCI�N'
                    --where a.zona = 'CAAGUAZ�'
                    --where a.zona = 'CANINDEY�'
                    --where a.zona = 'CIUDAD DEL ESTE'
                    --where a.zona = 'CONCEPCI�N + CHACO'
                    --where a.zona = 'CORDILLERA'
                    --where a.zona = 'GRAN ASUNCI�N'
                    --where a.zona = 'GUAIR� + CAAZAP�'
                    --where a.zona = 'ITAP�A'
                    --where a.zona = 'PARAGUARI'
                    --where a.zona = 'SAN PEDRO'
                    --where a.zona = '�EEMBUCU + MISIONES'

                     order by 1,2
                     
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)
df<-na.omit(df)

inputData<-df[,c(1,2,3,4,5,6)]

##########
##Check Class bias
table(inputData$TIPO1)
############################################################
#######correcting ratio of 1 and 0 in trainingData##########
############################################################
input_ones <- inputData[which(inputData$TIPO1 == 1), ]  # all 1's
input_zeros <- inputData[which(inputData$TIPO1 == 0), ]  # all 0's
set.seed(100)  # for repeatability of samples
#input_ones_training_rows <- sample(1:nrow(input_ones), 0.7*nrow(input_ones))  # 1's for training
#input_zeros_training_rows <- sample(1:nrow(input_zeros), 0.7*nrow(input_ones))  # 0's for training. Pick as many 0's as 1's
### cambio cuando los unos son mas que los ceros
input_ones_training_rows <- sample(1:nrow(input_ones), 0.7*nrow(input_ones))  # 1's for training
input_zeros_training_rows <- sample(1:nrow(input_ones), 0.7*nrow(input_zeros))  # 0's for training. Pick as many 0's as 1's

training_ones <- input_ones[input_ones_training_rows, ]  
training_zeros <- input_zeros[input_zeros_training_rows, ]
trainingData <- rbind(training_ones, training_zeros)  # row bind the 1's and 0's 

# Create Test Data
test_ones <- input_ones[-input_ones_training_rows, ]
test_zeros <- input_zeros[-input_zeros_training_rows, ]
testData <- rbind(test_ones, test_zeros)  # row bind the 1's and 0's 
##Check Class bias again
table(trainingData$TIPO1)
table(testData$TIPO1)
#########################################
###Create WOE for categorical variables (optional)
####a.k.a. dummy variables or numerical to categorical variables
####################################

# for(factor_var in factor_vars){
#   inputData[[factor_var]] <- WOE(X=inputData[, factor_var], Y=inputData$ABOVE50K)
# }
# head(inputData)

###################################################
#########Compute Information Values###################
#################

# library(smbinning)
# # segregate continuous and factor variables
# factor_vars <- c ("WORKCLASS", "EDUCATION", "MARITALSTATUS", "OCCUPATION", "RELATIONSHIP", "RACE", "SEX", "NATIVECOUNTRY")
# continuous_vars <- c("AGE", "FNLWGT","EDUCATIONNUM", "HOURSPERWEEK", "CAPITALGAIN", "CAPITALLOSS")
# 
# iv_df <- data.frame(VARS=c(factor_vars, continuous_vars), IV=numeric(14))  # init for IV results
# 
# # compute IV for categoricals
# for(factor_var in factor_vars){
#   smb <- smbinning.factor(trainingData, y="ABOVE50K", x=factor_var)  # WOE table
#   if(class(smb) != "character"){ # heck if some error occured
#     iv_df[iv_df$VARS == factor_var, "IV"] <- smb$iv
#   }
# }
# 
# # compute IV for continuous vars
# for(continuous_var in continuous_vars){
#   smb <- smbinning(trainingData, y="ABOVE50K", x=continuous_var)  # WOE table
#   if(class(smb) != "character"){  # any error while calculating scores.
#     iv_df[iv_df$VARS == continuous_var, "IV"] <- smb$iv
#   }
# }
# 
# iv_df <- iv_df[order(-iv_df$IV), ]  # sort
# iv_df

############################################################
#########Build Logit Models and Predict##########################
##########################################################

logitMod <- glm(TIPO1 ~ VAR_CLIENTE + VAR_PDV + VAR_QUIEBRE, data=trainingData, family=binomial(link="logit"))

predicted <- plogis(predict(logitMod, testData))  # predicted scores
# or
predicted <- predict(logitMod, testData, type="response")  # predicted scores

##########Decide on optimal prediction probability cutoff for the model

library(InformationValue)
optCutOff <- optimalCutoff(testData$TIPO1, predicted)[1] 
#=> 0.71

####Model Diagnostics

summary(logitMod)
##### cheking multicollinearity (have VIF well below 4.)
library(car)
vif(logitMod)

###Misclassification Error , the smaller the better
misClassError(testData$TIPO1, predicted, threshold = optCutOff)
##ROC: Receiver Operating Characteristics Curve , the bigger the better
plotROC(testData$TIPO1, predicted)
####CONCORDANCE
Concordance(testData$TIPO1, predicted)

## Sensitivity
sensitivity(testData$TIPO1, predicted, threshold = optCutOff)

## Specificity
specificity(testData$TIPO1, predicted, threshold = optCutOff)
## Confusion matrix
# The columns are actuals, while rows are predicteds.
#     0	1
# 0	TN	FN
# 1	FP	TP

confusionMatrix(testData$TIPO1, predicted, threshold = optCutOff)


summary(logitMod)
coefficients(logitMod)

library(oddsratio)
or_glm(data = trainingData, model = logitMod,incr = list(VAR_CLIENTE = -150, VAR_PDV = 0,VAR_QUIEBRE=0))
