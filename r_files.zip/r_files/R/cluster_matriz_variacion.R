#debug(utils:::unpackPkgZip)
#install.packages("xlsx")

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)
library(classInt)

library(tidyverse)
library(caret)



############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      with
                      base_epin_antes as
                     (
                     SELECT C.NAME AS CIRCUITO
                     ,COUNT(DISTINCT T.Clientcode) AS CANT_PDV
                     ,sum(distinct p.cant_clientes) as cant_clientes
                     ,sum(T.horas_sin_saldo) AS hs_sin_saldo
                     --,SUM(T.ventas) AS ventas
                     FROM RPT_DISTRIBUCION.SEGMENTACION_PDV T
                     LEFT JOIN rpl_dms2.tbl_pos_circuits PC  ON PC.POS = T.Clientcode
                     LEFT JOIN rpl_dms2.tbl_circuits C  ON C.ID = PC.CIRCUIT
                     left join expeam.clientes_pdv_2018 p on T.Clientcode = p.id_pdv and T.mes = p.mes
                     WHERE T.MES = 201412
                     GROUP BY C.NAME
                     )
                     ,base_epin_despues as
                     (
                     select 
                     t.circuito
                     ,count(distinct t.id_pdv) as cant_pdv
                     ,sum(p.cant_clientes) as cant_clientes
                     ,sum(t.horas_sin_saldo2) as hs_sin_saldo
                     --,sum(t.horas_sin_saldo2)/(13*31*count(distinct t.id_pdv)) as quiebre
                     --,sum(t.ventas) ventas
                     --,sum(t.compras) compras
                     from expeam.v_boc_epin_indirecta t
                     left join expeam.clientes_pdv_2018 p on t.id_pdv = p.id_pdv and t.mes = p.mes
                     where t.mes = 201802
                     group by t.circuito
                     )
                     select a.circuito
                    ,d.cant_pdv-a.cant_pdv as cant_pdv
                    ,d.cant_clientes-a.cant_clientes as cant_clientes
                    ,d.hs_sin_saldo-a.hs_sin_saldo as hs_sin_saldo
                     from base_epin_antes a
                     left join base_epin_despues d on a.CIRCUITO = d.CIRCUITO
                     order by 1
                     
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)


summary(df)

#df$REVENUE_MFS<-ifelse(df$REVENUE_MFS<0,0,df$REVENUE_MFS)
#df$MONTO_MFS<-ifelse(df$MONTO_MFS<0,0,df$MONTO_MFS)
#df$ARPU_MOBILE<-ifelse(df$ARPU_MOBILE<0,0,df$ARPU_MOBILE)

#summary(df)

###eliminamos outliers
#outlierKD(df, REVENUE_MFS)
#outlierKD(df, MONTO_MFS)
#outlierKD(df, ARPU_MOBILE)
###################
df<-na.omit(df)
##################


boxplot(df$CANT_CLIENTES,main="CANT_CLIENTES")
boxplot(df$HS_SIN_SALDO,main="HS_SIN_SALDO")
boxplot(df$CANT_PDV,main="CANT_PDV")

#KMEANS
##saber cuantos clusters
##################################
mydata<-select(df,CANT_CLIENTES)
##################################
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

fit <- kmeans(mydata, 3) # 5 cluster solution
# get cluster means 
abs(aggregate(mydata,by=list(fit$cluster),FUN=median))
#aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$CLUSTER_CANT_CLIENTES <- fit$cluster
df$CANT_CLIENTES_GROUP<-ifelse(df$CLUSTER_CANT_CLIENTES==1,"=",ifelse(df$CLUSTER_CANT_CLIENTES==2,"-","+"))
###############################
mydata<-select(df,HS_SIN_SALDO)
###############################
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

fit <- kmeans(mydata, 3) # 5 cluster solution
#####################################
abs(aggregate(mydata,by=list(fit$cluster),FUN=median))
#aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$CLUSTER_HS_SIN_SALDO <- fit$cluster
df$HS_SIN_SALDO_GROUP<-ifelse(df$CLUSTER_HS_SIN_SALDO==1,"=",ifelse(df$CLUSTER_HS_SIN_SALDO==2,"-","+"))
##########################


###############################
mydata<-select(df,CANT_PDV)
###############################
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

fit <- kmeans(mydata, 3) # 5 cluster solution
#####################################
abs(aggregate(mydata,by=list(fit$cluster),FUN=median))
#aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$CLUSTER_CANT_PDV <- fit$cluster
df$CANT_PDV_GROUP<-ifelse(df$CLUSTER_CANT_PDV==1,"=",ifelse(df$CLUSTER_CANT_PDV==2,"-","+"))

##########################
str(df)
colnames(df)<-c("CLUSTER_CANT_GROUP","CANT_PDV_GROUP")
base.insertar<-df
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_BASE_CLUSTERS_CIRCUITO", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)


