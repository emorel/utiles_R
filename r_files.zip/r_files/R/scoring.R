
library(ROracle)
library(tictoc)
library(BTYDplus)


con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      SELECT 
                      r.ar_sscrbr_dd
                     , to_char(r.fct_dt,'YYYY-MM-DD') as fecha_datos
                     , r.monto
                     FROM expeam.recarga_transac r
                     WHERE fct_dt between add_months(trunc(sysdate-1),-3) and trunc(sysdate-1)                     
                     
                     ")
df <- fetch(query)
toc()
#df<-df_bkp



#df<-subset(df, df$NRO_CUENTA %in% sample(df$AR_SSCRBR_DD,1000))

length(unique(df$AR_SSCRBR_DD))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
#df<-subset(df,cust %in%(sample(df$cust,size = 1000)))
tic()
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2019-04-01")
toc()


####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 100,burnin=100,thin=20,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
tic()
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
toc()
# conditional expectations
tic()
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
toc()
# P(active)
tic()
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
toc()
# P(alive)
tic()
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)
toc()

base.insertar<-dfCBS
con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
Sys.setenv(TZ = "GMT")
Sys.setenv(ORA_SDTZ = "GMT")
tic()
dbWriteTable(con,"TMP_ANTICHURN_20190408", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
toc()
dbDisconnect(con)



boxplot(dfCBS$litt,main="litt")
boxplot(dfCBS$pactive.pggg,main="pactive.pggg")
boxplot(dfCBS$palive.pggg,main="palive.pggg")


rbind(`Actuals` = c(`Holdout` = sum(dfCBS$x.star)),
      `Pareto/GGG` = round(sum(dfCBS$xstar.pggg)))