# loading libraries
library(googleVis)
library(dplyr)
library(reshape2)



con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                      SELECT b.nro_cuenta
                    ,to_char(b.fecha_datos,'yyyymm') as mes
                     ,regexp_replace(
                      listagg(
                       b.service_id , ',') within group (order by b.fecha_datos)  -- sorted
                      ,'([^,]+)(,\\1)*(,|$)', '\\1\\3') as  cart
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-11-01' and date'2018-02-28'
                     and b.servicio in ('Carga de dinero','Giros Nacionales','Transferencia','Retiro de dinero')
                     group by b.nro_cuenta
                     ,to_char(b.fecha_datos,'yyyymm')
                     
                     
                     
                     ")
df <- fetch(query)
toc()
orders<-df
head(df)

orders <- dcast(orders, NRO_CUENTA ~ MES, value.var='CART', fun.aggregate = NULL)

orders<-na.omit(orders)
orders<-subset(orders,NRO_CUENTA %in% sample(orders$NRO_CUENTA,20))

orders <- orders[-c(1)]

orders.plot <- data.frame()

for (i in 2:ncol(orders)) {
  
  ord.cache <- orders %>%
    group_by(orders[ , i-1], orders[ , i]) %>%
    summarise(n=n()) %>%
    ungroup()
  
  colnames(ord.cache)[1:2] <- c('from', 'to')
  
  # adding tags to carts
  ord.cache$from <- paste(ord.cache$from, '(', i-1, ')', sep='')
  ord.cache$to <- paste(ord.cache$to, '(', i, ')', sep='')
  
  orders.plot <- rbind(orders.plot, ord.cache)
  
}


plot(gvisSankey(orders.plot, from='from', to='to', weight='n',
                options=list(height=900, width=1800, sankey="{link:{color:{fill:'lightblue'}}}")))
