debug(utils:::unpackPkgZip)
install.packages('MatchIt')


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                    
                    /*select p.nro_cuenta as document_number
                    ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_datos
                    ,p.monto
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2017-01-01' and date'2018-05-31'
                     and p.nro_cuenta in
                     (
                         select p.nro_cuenta
                         from tigo_cash_rpt.product_tracking p
                         where p.fecha_datos between date'2017-01-01' and date'2018-05-31'
                         AND p.categoria = 'Bill Payments' 
                         and p.subcategoria = 'MENU Payments'
                         minus
                         SELECT b.nro_cuenta
                         from expeam.tmp_base_bono_fecha_pospago b
                     )
                    and p.nro_cuenta in
                    (
                     
                     select p.nro_cuenta
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2017-01-01' and date'2018-05-31'
                     having count(distinct to_char(p.fecha_datos,'YYYYMM')) > 5
                     group by p.nro_cuenta
                    )*/
                  

                  select *
                  from expeam.tmp_base_con_bono 
                  union all
                  select *
                  from expeam.tmp_base_sin_bono   
                     
                    
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$DOCUMENT_NUMBER))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
set.seed(123)
colnames(df) <- c("cust","date","sales")
#colnames(df_func) <- c("cust","name")
df<-subset(df,cust %in%(sample(df$cust,size = 4000)))
str(df)
length(unique(df$cust))

#dfCBS <- elog2cbs(df, T.cal = "2017-11-01")
#str(dfCBS)
#head(dfCBS, 5)

####en dias
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-01-01")
length(unique(dfCBS$cust))
length(dfCBS$cust)

#(nbd.EstimateParameters(subset(dfCBS,cust %in% c('0961336760')))[2]/
#    nbd.EstimateParameters(subset(dfCBS,cust %in% c('0983454819','0981662000','0984925900','0985108181','0981800993','0985484017','0981900773','0981922513','0981989591','0981404466') ))[1])



#op <- par(mfrow = c(1, 2))
#(k.wheat <- estimateRegularity(df, method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
#(k.mle <- estimateRegularity(df, method = "mle",plot = TRUE, title = "Maximum Likelihood"))
#par(op)

#plotTimingPatterns(df, n = 10, T.cal = "2018-01-01",headers = c("Past", "Future"), title = "")
#plotTimingPatterns(subset(dfkl,cluster==5), n = 10, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
plotTimingPatterns(subset(df,cust %in% c('0981265362')), n = 10, T.cal = "2018-01-01",headers = c("Past", "Future"), title = "")

####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 200,chains = 2) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)
# show estimates for first few customers
head(dfCBS[, c("x", "t.x", "x.star",
               "xstar.pggg", "pactive.pggg", "palive.pggg")])
# report median cohort-level parameter estimates
round(apply(as.matrix(pggg.draws$level_2), 2, median), 3)

# report mean over median individual-level parameter estimates

median.est <- sapply(pggg.draws$level_1, function(draw) {
  apply(as.matrix(draw), 2, median)
})
round(apply(median.est, 1, mean), 3)

# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(dfCBS$x.star)),
      `Pareto/GGG` = round(sum(dfCBS$xstar.pggg)),
      `MBG/CNBD-k` = round(sum(dfCBS$xstar.mbgcnbd)),
      `Pareto/NBD (HB)` = round(sum(dfCBS$xstar.pnbd.hb)))


# error on customer level
mae <- function(act, est) {
  stopifnot(length(act)==length(est))
  sum(abs(act-est)) / sum(act)
}
mae.pggg <- mae(dfCBS$x.star, dfCBS$xstar.pggg)
#mae.mbgcnbd <- mae(dfCBS$x.star, dfCBS$xstar.mbgcnbd)
#mae.pnbd.hb <- mae(dfCBS$x.star, dfCBS$xstar.pnbd.hb)

rbind(`Pareto/GGG` = c(`MAE` = round(mae.pggg, 3))
      #      ,`MBG/CNBD-k` = c(`MAE` = round(mae.mbgcnbd, 3))
      #,`Pareto/NBD (HB)` = c(`MAE` = round(mae.pnbd.hb, 3))
)

#lift <- 1 - mae.pggg / mae.mbgcnbd
#cat("Lift in MAE:", round(100*lift, 1), "%")

######## agregamos parametro de intertransaction time per customer

tic()
df_param=matrix(nrow = 35000,ncol = 2)
w=1
for (c in dfCBS$cust) {
  df_param[w,1]=c
  df_param[w,2]=round(nbd.EstimateParameters(subset(dfCBS,cust == c))[2]/
                        nbd.EstimateParameters(subset(dfCBS,cust == c))[1],2)
  w=w+1
  
  
}
toc()
str(df_param)

colnames(df_param) <- c("cust","param")
df_param<-na.omit(df_param)
dfCBS<-merge(x = dfCBS, y = df_param, by = "cust", all.x = TRUE)
dfCBS$param<-as.numeric(as.character(dfCBS$param))
options(scipen = 9999)
str(dfCBS)


###########################
#Propensity Score Matching#
########RMatchit###########
###########################
dfCBS_2<-dfCBS
dfCBS_2$treat<-0

dfCBS_t<-rbind(dfCBS_1,dfCBS_2)
dfCBS_t$treat<-as.factor(dfCBS_t$treat)

str(dfCBS_t)
m.out<- matchit(treat~x+t.x+litt+sales+T.cal+x.star+sales.star+xstar.pggg+param
                ,data=dfCBS_t,method = "nearest",ratio=1)
summary(m.out)
plot(m.out,type = "jitter")
plot(m.out,type = "hist")

dfCBS_matched<-match.data(m.out)
str(dfCBS_matched)
write.table(dfCBS_matched,"bono_tc.csv",sep = ";",row.names = FALSE,)
############
##K-MEANS###
############

#dfk<-dfCBS[-c(1,6)]
##excluimos la fecha y el nro_cuenta
#dfksc<-scale(dfk[-c(6)])


fit <- kmeans(scale(dfCBS[-c(1,6,8)]), 6, iter.max=3000)


table(fit$cluster)



barplot(table(fit$cluster), col="maroon")

pca <- prcomp(scale(dfCBS[-c(1,6,8)]))
pca_dat <- mutate(fortify(pca), col=fit$cluster)

ggplot(pca_dat) +
  geom_point(aes(x=PC1, y=PC2, fill=factor(col)), size=3, col="#7f7f7f", shape=21) +
  scale_fill_viridis(name="Cluster", discrete=TRUE) + theme_bw(base_family="Helvetica")

dfCBS$cluster<-as.factor(fit$cluster)
str(dfCBS)

##agregar cluster as df
dfkl<-merge(x = df, y = dfCBS[c(1,15)], by = "cust", all.x = TRUE)

###########################
##visualizar por cluster###
###########################

## Timing Patterns
op <- par(mfrow = c(2, 3))
p1<-plotTimingPatterns(subset(dfkl, cluster==1), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
p2<-plotTimingPatterns(subset(dfkl, cluster==2), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
p3<-plotTimingPatterns(subset(dfkl, cluster==3), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
p4<-plotTimingPatterns(subset(dfkl, cluster==4), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
p5<-plotTimingPatterns(subset(dfkl, cluster==5), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
p6<-plotTimingPatterns(subset(dfkl, cluster==6), n = 100, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")
par(op)

## Regularity
op <- par(mfrow = c(2, 3))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==1), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==2), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==3), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==4), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==5), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
#(k.mle <- estimateRegularity(subset(dfkl, cluster==6), method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)


###  BOX Plot Parametros

p1<-ggplot(data = dfCBS, mapping = aes(x = cluster, y = sales)) +
  geom_boxplot()
p2<-ggplot(data = dfCBS, mapping = aes(x = cluster, y = sales.star)) +
  geom_boxplot()
p3<-ggplot(data = dfCBS, mapping = aes(x = cluster, y = x)) +
  geom_boxplot()
p4<-ggplot(data = dfCBS, mapping = aes(x = cluster, y = t.x)) +
  geom_boxplot()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)

summary(subset(dfCBS,cluster==1))
summary(subset(dfCBS,cluster==2))
summary(subset(dfCBS,cluster==3))
summary(subset(dfCBS,cluster==4))
summary(subset(dfCBS,cluster==5))
summary(subset(dfCBS,cluster==6))

#facet_wrap(~cluster,nrow = 1)

