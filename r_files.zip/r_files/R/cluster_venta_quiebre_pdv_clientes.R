
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)
library(classInt)

library(tidyverse)
library(cluster)
library(factoextra)
library(caret)



############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     

                    select 
                     m.circuito
                     ,sum(m.ventas) as ventas
                    ,sum(m.hs_sin_saldo) as hs_sin_saldo
                    ,count(distinct m.id_pdv) as cant_pdv
                    ,sum(m.cant_clientes) as cant_clientes
                     from expeam.base_distrib_kpi_mapeo m
                     group by 
                     m.circuito
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
dbDisconnect(con)
##########################

df<-df_bkp

#df<-base_circuito_variacion
summary(df)

#df$REVENUE_MFS<-ifelse(df$REVENUE_MFS<0,0,df$REVENUE_MFS)
#df$MONTO_MFS<-ifelse(df$MONTO_MFS<0,0,df$MONTO_MFS)
#df$ARPU_MOBILE<-ifelse(df$ARPU_MOBILE<0,0,df$ARPU_MOBILE)

#summary(df)

###eliminamos outliers
#outlierKD(df, REVENUE_MFS)
#outlierKD(df, MONTO_MFS)
#outlierKD(df, ARPU_MOBILE)
###################
df<-na.omit(df)
##################


boxplot(df$VENTAS,main="VENTAS")
boxplot(df$HS_SIN_SALDO,main="HS_SIN_SALDO")
boxplot(df$CANT_PDV,main="CANT_PDV")
boxplot(df$CANT_CLIENTES,main="CANT_CLIENTES")

#KMEANS
##saber cuantos clusters
##################################
mydata<-select(df,VENTAS,HS_SIN_SALDO,CANT_PDV,CANT_CLIENTES)
mydata<-scale(mydata)
##################################
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
                                     centers=i)$withinss)
plot(1:15, wss, type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")

fit <- kmeans(mydata, 6) # 5 cluster solution
fviz_cluster(fit,data=mydata)
# get cluster means 
aggregate(mydata,by=list(fit$cluster),FUN=median)
aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$GRUPO_CIRCUITO_VENTA <- fit$cluster


#df$CANT_CLIENTES_GROUP<-ifelse(df$CLUSTER_CANT_CLIENTES==1,"=",ifelse(df$CLUSTER_CANT_CLIENTES==2,"-","+"))

##########################
#write.table(df,"C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/kpi/base_circuito_variacion_cluster.csv",row.names = FALSE,sep = ";")
 #str(df)
 #colnames(df)<-c("GRUPO_CIRCUITO_VENTA","CANT_PDV_GROUP")
 base.insertar<-select (df,CIRCUITO,GRUPO_CIRCUITO_VENTA)
 con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
 dbWriteTable(con,"TMP_GRUPO_CIRCUITO_VENTA", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
 dbDisconnect(con)


