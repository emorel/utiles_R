debug(utils:::unpackPkgZip)
install.packages('TraMineRextras')


library(TraMineR)
library(TraMineRextras)
library(data.table)
library(dplyr)
library(bayesm)
library(NMF)
library("cluster")
library(WeightedCluster)
library(tictoc)
library("wesanderson")
library(ROracle)
library(viridis)
library(RColorBrewer)
library(gtools)
con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     select * 
                     from expeam.tmp_base_ci_co_sts  t
                     --where t.cant_base1>0 
                     --and t.cant_base2>0
                     
                     
                     ")
dfa1 <- fetch(query)

toc()
dfa<-dfa1[-c(31,32)]


##eliminamos la secuencias anteriores a la deseada
for (i in 1:nrow(dfa)){
  
  for (j in 1:ncol(dfa[1,])){
    if (!is.na(dfa[i,j]) && (dfa[i,j]=="COMPRA." || dfa[i,j]=="RETIRO.")){
      posc<-j-1
      break
    }
  }
  
  for (k in 2:posc){
    if (2>posc ){ 
      break
    }else{
      dfa[i,k]=NA
    }
  } 
  
}

str(dfa)

dfa1$DOCUMENT_NUMBER<-as.integer(dfa1$DOCUMENT_NUMBER)
dfa1<-na.omit(dfa1)
dfa1$FECHA_DATOS<-as.integer(dfa1$FECHA_DATOS)


dfa<-subset(dfa, dfa$DOCUMENT_NUMBER %in% sample(dfa$DOCUMENT_NUMBER,50000))
#dfa<-dcast(dfa,DOCUMENT_NUMBER ~ FECHA_DATOS,value.var = 'MONTO')
## Conteos
dfa$CANT_NULL<-rowSums(is.na(dfa))

##MARCADO CHURN
nrow<-nrow(dfa)
ncol<-ncol(dfa[1,])
tic()
for (i in 1:nrow){
  
  for (j in ncol:1){
    #print(paste(i,';',j))
    if (is.na(dfa[i,j])){
      dfa[i,j]<-"CHURN"
    }else{
      break
    }
  }
  
}
toc()


dfa$CANT_OTC<-ifelse(dfa$`201609` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201610` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201611` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201612` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201701` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201702` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201703` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201704` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201705` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201706` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201707` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201708` == 'RETIRO_OTC.',1,0)+
  ifelse(dfa$`201709` == 'RETIRO_OTC.',1,0)
ifelse(is.na(dfa$`201510`),1,0)

length(unique(dfa$DOCUMENT_NUMBER))

dfa <- subset(dfa,CANT_CONV>0 & CANT_OTC >1)
sample(dfa$DOCUMENT_NUMBER,5000)



length(unique(dfa$DOCUMENT_NUMBER))

summary(dfa)
str(dfa)
##insercion en base de datos
#base.insertar <- unique(dfa$DOCUMENT_NUMBER)
#rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
#rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
#dbCommit(con)


## para ordernar variables CHR numericas
mvad.scode<-seqstatl(dfa[-c(1)], var=NULL, format='STS')
mvad.scode<-mixedsort(mvad.scode)
mvad.scode

###
##PALETA DE COLORES
n <- length(mvad.scode)
paleta<-viridis_pal(option = "D")(n)  # n = number of colors seeked
pie(rep(1,n), col=paleta)

## otra manera
#qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
#col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
#pie(rep(1,n), col=sample(col_vector, n))
########
##generacion de graficos 
apc<-ncol(dfa)
#dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE ,right = "DEL",left = "DEL",gaps="DEL")
dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE,alphabet = mvad.scode, states = mvad.scode, labels = mvad.scode)

#SEQIPLOT
##
tic()
tiff('C:/Users/expeam/Documents/segment/2018/marzo/ussd_app/seqIplot_clientes_ussd_app_901238.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, xtstep = 1,sortv="from.start",cex.legend=7,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - USSD - APP - N= 901.238")
dev.off()
toc()
##
#SEQDPLOT
##
tiff('C:/Users/expeam/Documents/segment/2018/marzo/ussd_app/seqdplot_clientes_ussd_app_901238.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA,cex.legend=5,cex.main=4,cex.axis = 3,main="Share - USSD - APP  - N= 901.238")
dev.off()
##



##armado de clusters ## full matrix para reducir la matriz de distancias.. (utilizar with.missing para mostrar actividad)
dfa.om <- seqdist(dfa.seq, method = "OM", indel = 1, sm = "TRATE",with.missing = TRUE,full.matrix=FALSE)
tic()
clusterward <- agnes(dfa.om, diss = TRUE, method = "ward")
toc()
dfa.cl4 <- cutree(clusterward, k = 5)
cl4.lab <- factor(dfa.cl4, labels = paste("Cluster", 1:5))
###Extraer un cluster especifico
dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 2'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
dbCommit(con)
##
#SEQIPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_retiro_cc_537_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, group = cl4.lab, xtstep = 1,sortv="from.start",cex.legend=8,cex.main=3,cex.axis = 2,main="Cronograma de Clientes - Retiro OTC vs Retiro CC - N= 537")
dev.off()
##
#SEQDPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqdplot_clientes_cc_tiendas_retiro_cc_vs_otc_5961_c.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA, group = cl4.lab,cex.legend=5,cex.main=4,cex.axis = 3,main="Share - CC en tiendas - Retiro OTC vs Retiro CC - N=  5.961")
dev.off()
##

#LEGENDS
#tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_entrega_3487_c.tiff', width = 5, height = 10, units = 'in', res = 200)
#seqlegend(dfa.seq)
#dev.off()
