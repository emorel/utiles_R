library(ROracle)
library(dplyr)

con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")

m<-c("2016-01-01","2016-02-01","2016-03-01","2016-04-01","2016-05-01","2016-06-01"
     ,"2016-07-01","2016-08-01","2016-09-01","2016-10-01","2016-11-01","2016-12-01"
     ,"2017-01-01","2017-02-01","2017-03-01","2017-04-01","2017-05-01","2017-06-01"
     ,"2017-07-01","2017-08-01","2017-09-01","2017-10-01","2017-11-01","2017-12-01"
     ,"2018-01-01","2018-02-01","2018-03-01","2018-04-01","2018-05-01","2018-06-01"
     ,"2018-07-01","2018-08-01")

#m<-c("2018-01-01","2018-02-01","2018-03-01","2018-04-01","2018-05-01","2018-06-01"
#     ,"2018-07-01","2018-08-01")
m.mat <- matrix(, nrow = 35, ncol = 3)
i=1
for (MONTH in m)
{
  
  
  
      FECHA_DATOS <- data.frame(FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH))
      
      query <- dbSendQuery(con,"
                          


                          select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.AR_KEY) as arpu
                          ,count(distinct ar.AR_KEY) as cant_clientes
                          ,ar.FCT_DT
                          from smy.ar_monthly_base_fct ar
                          where
                           ar.AR_SSCRBR_DD in 
                          (
                                select b.nro_cuenta
                                from expeam.tmp_base_envio_recep_16_18 b
                                where b.fecha_datos between to_date(:1,'YYYY-MM-DD') and last_day(to_date(:2,'YYYY-MM-DD'))
                                
                          
                          )
                          and ar.FCT_DT = last_day(to_date(:3,'YYYY-MM-DD'))
                          and ar.PAYMENT = 'PRE'
                          group by ar.FCT_DT



                           ",data=FECHA_DATOS)
      
      df <- fetch(query)
  
      m.mat[i,1]=df$FCT_DT
      m.mat[i,2]=df$ARPU
      m.mat[i,3]=df$CANT_CLIENTES
      print(df$FCT_DT)
      
}


