library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(readxl)
library(DescTools)

# 
# con<-dbConnect(Oracle(),user="expeam",password="!junio2018",dbname="DWH")
# query<-dbSendQuery(con, "
#                    
#                    select 
#                    b.cant_ptm
#                    ,b.circuito
#                    ,b.cantidad_num as cant_cliente
#                    from  expeam.base_ptm_circ_ci_60d_mensual b
#                    ")
# result <- fetch(query)
# t1<-result



t<-as.data.frame(prueba)
str(t)

#t<-as.data.frame(log(t[-c(1)]))

# 
# t$CANT_PTM<-log(t$CANT_PTM)
# t$CANT_CLIENTES<-log(t$CANT_CLIENTES)
# t$CANT_CLIENTE<-log(t$CANT_CLIENTES)


#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)

chart.Correlation(t, histogram=TRUE, pch=19)
chart.Correlation(t[-c(1)], histogram=TRUE, pch=19)


linearMod<-lm(reve~Min+Precip ,data = t)
print(linearMod)
# as.formula(
#   paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
#          paste(sprintf(" %+.2f*%s ", 
#                        coefficients(linearMod)[-1],  
#                        names(coefficients(linearMod)[-1])), 
#                collapse="")
#   )
# )
summary(linearMod)

  
(1-MAPE(linearMod))*100






