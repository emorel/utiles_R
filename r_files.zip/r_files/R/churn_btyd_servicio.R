#debug(utils:::unpackPkgZip)
#install.packages('Rmpi')


library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)

con <- dbConnect(Oracle(), user="expeam", password="!enero2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select t.nro_cuenta
                      ,t.fecha_datos
                     ,t.monto
                      from expeam.tmp_total_2018 t
                      where t.fecha_datos between '2018-05-01' and '2018-12-31'
                      and t.servicio = 'Retiro de dinero'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
dbDisconnect(con)
df<-df_bkp

df<-subset(df, df$NRO_CUENTA %in% sample(unique(df$NRO_CUENTA),10000))



length(unique(df$NRO_CUENTA))

df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-11-01")

dfCBSbk<-dfCBS


options(scipen=999)
breaks<-10
dfCBS$litt.sgmt <- cut( dfCBS$litt, breaks = breaks, dig.lab=2,ordered_result = TRUE)
names(dfCBS)
ggplot(dfCBS, aes(x=litt.sgmt,y=x)) +
  ggtitle("Segmentos de")+
  geom_bar( aes(x=litt.sgmt,y=x),stat="identity")+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))

####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 100,burnin=100,thin=20,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)

table(dfCBS$pactive.pggg)
table(dfCBS$palive.pggg)

options(scipen=999)
breaks<-6
dfCBS$pactive.pggg.sgmt <- cut( dfCBS$pactive.pggg, breaks = breaks, dig.lab=2,ordered_result = TRUE)

options(scipen=999)
breaks<-6
dfCBS$palive.pggg.sgmt <- cut( dfCBS$palive.pggg, breaks = breaks, dig.lab=2,ordered_result = TRUE)


ggplot(dfCBS, aes(x=pactive.pggg.sgmt,y=sales)) +
  ggtitle("Segmentos de PTM")+
  geom_bar( aes(x=pactive.pggg.sgmt,y=sales),stat="identity")+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))

ggplot(dfCBS, aes(x=litt.sgmt)) +
  ggtitle("Segmentos de PTM")+
  geom_bar(aes(y = (..count..)/sum(..count..)*100) )+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  #geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))



ggplot(dfCBS, aes(x=pactive.pggg.sgmt)) +
  ggtitle("Segmentos de PTM")+
  geom_bar(aes(y = (..count..)/sum(..count..)*100))+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  #geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))


ggplot(dfCBS, aes(x=palive.pggg.sgmt)) +
  ggtitle("Segmentos de PTM")+
  geom_bar(aes(y = (..count..)/sum(..count..)*100))+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  #geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))



write.table(dfCBS,file = "C:/Users/expeam/Documents/segment/2018/12-diciembre/churn/envio_btyd_ene_abril_2018.csv",sep = ";",row.names = FALSE)
