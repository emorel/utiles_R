


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")

###############
####TARGET###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                      select
                      distinct 
                     ar_key
                     ,MAX(payment) as payment
                     ,MAX(cty_nm) as cty_nm
                     ,MAX(dvc_type) as dvc_type
                     ,MAX(tecnologia) as tecnologia
                     ,MAX(sitio) as sitio
                     ,MEDIAN(antiguedad_meses) as  antiguedad_meses
                     ,MEDIAN(mb_free) as mb_free
                     ,MEDIAN(mb_billed) as mb_billed
                     ,MEDIAN(avg_recharge) as avg_recharge
                     ,MEDIAN(mou) as mou
                     ,MEDIAN(arpu) as arpu
                     ,MEDIAN(data_rev) as data_rev
                     ,MEDIAN(voice_rev) as voice_rev
                     from expeam.TMP_BASE_KPI_TARGET_PRE t
                     where t.fct_dt in (last_day(date'2018-09-01'),last_day(date'2018-10-01'))
                     group by ar_key
                     order by 1
                     
                     
                     
                     ")
df_bkp_target <- fetch(query)
toc()
df_target<-df_bkp_target

df_target<-subset(df_target,df_target$AR_KEY %in%(sample(df_target$AR_KEY,size = 2000)))

length(unique(df_target$AR_KEY))

###############
####CONTROL###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select
                      distinct 
                     ar_key
                     ,MAX(payment) as payment
                     ,MAX(cty_nm) as cty_nm
                     ,MAX(dvc_type) as dvc_type
                     ,MAX(tecnologia) as tecnologia
                     ,MAX(sitio) as sitio
                     ,MEDIAN(antiguedad_meses) as  antiguedad_meses
                     ,MEDIAN(mb_free) as mb_free
                     ,MEDIAN(mb_billed) as mb_billed
                     ,MEDIAN(avg_recharge) as avg_recharge
                     ,MEDIAN(mou) as mou
                     ,MEDIAN(arpu) as arpu
                     ,MEDIAN(data_rev) as data_rev
                     ,MEDIAN(voice_rev) as voice_rev
                     from expeam.TMP_BASE_KPI_CONTROL_PRE t
                     where t.fct_dt in (last_day(date'2018-09-01'),last_day(date'2018-10-01'))
                     group by ar_key
                     order by 1
                                          
                     
                     
                     
                     ")
df_bkp_control <- fetch(query)
toc()
df_control<-df_bkp_control

df_control<-subset(df_control,df_control$AR_KEY %in%(sample(df_control$AR_KEY,size = 6000)))

length(unique(df_control$AR_KEY))

df_target$TIPO<-1
df_control$TIPO<-0
####################
##EN UNA SOLA TABLA 
###################

##union de las tablas
df_tg<-rbind(df_target,df_control)
#df_tg<-df_tg[,-which(names(df_tg) == "SITIO")] 
#str(df_tg)


#######################
####TRANSFORMACIONES###
#######################

#table(df_tg$ARPU_B)

df_tg<-mutate_if(df_tg,is.character,as.factor)


df_tg$TIPO<-as.factor(df_tg$TIPO)
#df_tg$REGION<-as.factor(df_tg$REGION)
#df_tg$DEVICE_TYPE<-as.factor(df_tg$DEVICE_TYPE)
#table(df_tg$TENURE_B)
#table(df_tg$DATA_CONSUMPTION_B)
#table(df_tg$EDAD_B)
#str(df_tg)
#df_tg<-na.omit(df_tg)
df_tg <- filter(df_tg, ANTIGUEDAD_MESES > 0, MB_FREE > 0, MB_BILLED > 0
                , AVG_RECHARGE  > 0, MOU > 0, ARPU > 0, DATA_REV > 0, VOICE_REV  > 0
)

str(df_tg)
summary(df_tg)

###############
####BRACKETS###
###############
options(scipen=999)
#breaks<-50
#df_tg$EDAD_SGM<- cut( df_tg$EDAD, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-20
df_tg$ANTIGUEDAD_MESES_SGM<- cut( df_tg$ANTIGUEDAD_MESES, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-10
df_tg$MB_FREE_SGM<- cut( df_tg$MB_FREE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-10
df_tg$MB_BILLED_SGM<- cut( df_tg$MB_BILLED, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-10
df_tg$AVG_RECHARGE_SGM<- cut( df_tg$AVG_RECHARGE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-10
df_tg$MOU_SGM<- cut( df_tg$MOU, breaks = breaks, dig.lab=0,ordered_result = FALSE)
##ARPU
breaks<-30
df_tg$ARPU_SGM<- cut( df_tg$ARPU, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-30
df_tg$DATA_REV_SGM<- cut( df_tg$DATA_REV, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-10
df_tg$VOICE_REV_SGM<- cut( df_tg$VOICE_REV, breaks = breaks, dig.lab=0,ordered_result = FALSE)

###########################
#Propensity Score Matching#
########RMatchit###########
###########################




# tic()
# m.out<- matchit(TIPO~DATA_CONSUMPTION+REGION+ARPU+TENURE+DEVICE_SUBTYPE
#                 ,data=df_tg,method = "nearest",ratio=3)
# toc()

#remove(df_bkp)
#remove(df_control)
#remove(df_target)


#fit <- glm(TIPO~MB_FREE_SGM+MB_BILLED_SGM+AVG_RECHARGE+MOU_SGM+ARPU_SGM+DATA_REV_SGM+VOICE_REV_SGM+CTY_NM+DVC_TYPE+TECNOLOGIA+EDAD_SGM,data=df_tg,family=binomial(link = "logit"))

options(max.print=20)
#summary(fit)
##excluimos columnas que no se incluyen en el modelo
data<-df_tg[,-which(names(df_tg) == "SITIO")]
data<-na.omit(data)

length(unique(data$AR_KEY))

##se entrena el modelo
tic()
m.out<- matchit(TIPO~MB_BILLED_SGM+AVG_RECHARGE_SGM,data=data,method = "nearest",exact = c("CTY_NM","DVC_TYPE","TECNOLOGIA","ARPU_SGM","DATA_REV_SGM"),ratio=1)
toc()

summary(m.out)
#plot(m.out,type = "jitter")
#plot(m.out,type = "hist")

df_matched<-match.data(m.out)

#str(df_matched)
#summary(df_matched)


mean(subset(df_matched,TIPO==1)$ARPU)-
  mean(subset(df_matched,TIPO==0)$ARPU)

mean(subset(df_matched,TIPO==1)$DATA_REV)-
  mean(subset(df_matched,TIPO==0)$DATA_REV)

#df_tg_matched<-merge(df_tg,df_matched[,c("AR_KEY","distance","weights")], by = "AR_KEY", all.x = TRUE,no.dups = TRUE)
##al hacer el merge se invierten las primeras dos columnas

# 
# a<-summary(m.out)
# a<-summary(df_matched)
# 
#  kable(a$nn, digits = 2, align = 'c', 
#        caption = 'Table 2: Sample sizes')

# kable(a$sum.matched[c(1,2,4)], digits = 2, align = 'c', 
#       caption = 'Table 3: Summary of balance for matched data')
# 
# a %>%
#   kable() %>%
#   kable_styling()

write.table(df_matched,file = "C:/Users/expeam/Documents/BI/2019/02-febrero/Sitios_700Mhz/nuevo_analisis/target_control_matched_sep_18.csv",sep = ";",row.names = FALSE)
####################
###ARP Incremental##
###################
#str(df_tg_matched)
#Sys.setenv(TZ = "GMT")
#Sys.setenv(ORA_SDTZ = "GMT")
#dbWriteTable(con, "ORACLE_DB_TABLE", base.insertar, overwrite = F, append = T, row.names = F)


base.insertar <-df_matched[,c("AR_KEY","TIPO","distance")]
str(base.insertar)
rs <- dbSendQuery(con, "truncate table expeam.TMP_BASE_MATCHED_PRE")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.TMP_BASE_MATCHED_PRE values(:1,:2,:3)", data=base.insertar)
dbCommit(con)



base.insertar <-(subset(df_matched,TIPO == 0))$AR_SSCRBR_DD
rs <- dbSendQuery(con, "truncate table expeam.tmp_control1")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_control1 values(:1)", data=base.insertar)
dbCommit(con)
