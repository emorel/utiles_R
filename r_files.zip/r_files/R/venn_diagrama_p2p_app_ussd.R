

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!marzo2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"


                     
                     
			select distinct b.nro_cuenta
			from tigo_cash_rpt.base_cliente_mfs_daily b
			where b.fecha_datos between date'2018-03-01' and date'2018-03-31'
			and b.servicio = 'Transferencia'


                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"



      select   ('0' ||  SUBSTR(REGEXP_SUBSTR(bm.msisdn, '^[0-9]+'), 4, 9)) as nro_cuenta
      from cdr.juvo_active_users_py bm
                     where bm.SHOP_REGISTRATION_DATE IS NOT NULL
                     and trunc(bm.PROCESS_DATE)   >= date'2018-03-01'
                     and trunc(bm.SHOP_LAST_LOGIN) >= date'2018-03-01'

                     and trunc(bm.PROCESS_DATE)   <= date'2018-03-31'
                     and trunc(bm.SHOP_LAST_LOGIN) <= date'2018-03-31'

                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     

                     
 select ('0' ||  SUBSTR(REGEXP_SUBSTR(bm.msisdn, '^[0-9]+'), 4, 9)) as nro_cuenta --app tigo money
      from cdr.juvo_active_users_py bm
                     where bm.MFS_REGISTRATION_DATE IS NOT NULL
                     and trunc(bm.PROCESS_DATE)   >= date'2018-03-01'
                     and trunc(bm.MFS_LAST_LOGIN) >= date'2018-03-01'       
                     and trunc(bm.PROCESS_DATE)   <= date'2018-03-31'
                     and trunc(bm.MFS_LAST_LOGIN) <= date'2018-03-31'

                     
                     ")
base3 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                      select a.AR_SSCRBR_DD as nro_cuenta
                      FROM db_panza.sgm_stg_cstmr2 a           
                     where a.FCT_DT = date'2018-03-31'
                     and a.DVC_TYPE = 'Smartphone'


                     ")
base4 <- fetch(query)
toc()



#Generando vectores de char
base1<-base1$NRO_CUENTA
base2<-base2$NRO_CUENTA
base3<-base3$NRO_CUENTA
base4<-base4$NRO_CUENTA


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  #x = list(wallet_l,smart_l,shop_l,tm_app_l),
  x = list(base1,base2,base3),
  #category.names = c("WALLET","SMART","SHOP_APP","TM_APP"),
  category.names = c("P2P_USSD","SHOPP_APP","TM_APP"),
  filename = 'C:/Users/expeam/Documents/segment/2018/marzo/p2p_ussd_app_acciones/venn_diagramm_p2pussd_app_marzo.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow','green','blue'),
  cex = 0.5,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.5,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 

