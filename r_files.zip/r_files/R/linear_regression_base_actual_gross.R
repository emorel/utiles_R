library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(readxl)
library(DescTools)


con<-dbConnect(Oracle(),user="expeam",password="!agosto2018",dbname="DWH")
query<-dbSendQuery(con, "

                     with
                    begining as
                   (
                   select  to_char(v.fechadatos_dat,'YYYY-MM-DD') as fecha_datos
                   ,v.indicator_chr
                   ,sum(v.cantidad_num) as cantidad_num
                   from expeam.res_base_mfs_dai_ci_60 v
                   where v.indicator_chr = 'Begining Day'
                   --and v.fechadatos_dat >= date'2016-01-01'
                   group by to_char(v.fechadatos_dat,'YYYY-MM-DD')
                   ,v.indicator_chr
                   )
                   ,gross as
                   (
                   select  to_char(v.fechadatos_dat,'YYYY-MM-DD') as fecha_datos
                   ,v.indicator_chr
                   ,sum(v.cantidad_num) as cantidad_num
                   from expeam.res_base_mfs_dai_ci_60 v
                   where v.indicator_chr = 'Gross Connections'
                   --and v.fechadatos_dat >= date'2016-01-01'
                   group by to_char(v.fechadatos_dat,'YYYY-MM-DD')
                   ,v.indicator_chr
                   )
                   ,disco as
                   (
                   select  to_char(v.fechadatos_dat,'YYYY-MM-DD') as fecha_datos
                   ,v.indicator_chr
                   ,sum(v.cantidad_num) as cantidad_num
                   from expeam.res_base_mfs_dai_ci_60 v
                   where v.indicator_chr = 'Disconnections'
                   --and v.fechadatos_dat >= date'2016-01-01'
                   group by to_char(v.fechadatos_dat,'YYYY-MM-DD')
                   ,v.indicator_chr
                   )
                   ,reco as
                   (
                   select  to_char(v.fechadatos_dat,'YYYY-MM-DD') as fecha_datos
                   ,v.indicator_chr
                   ,sum(v.cantidad_num) as cantidad_num
                   from expeam.res_base_mfs_dai_ci_60 v
                   where v.indicator_chr = 'Reconnections'
                   --and v.fechadatos_dat >= date'2016-01-01'
                   group by to_char(v.fechadatos_dat,'YYYY-MM-DD')
                   ,v.indicator_chr
                   
                   )
                   
                   SELECT 
                   begining.fecha_datos
                   ,begining.cantidad_num as begin
                   ,gross.cantidad_num as gros
                   ,disco.cantidad_num as disco
                   ,reco.cantidad_num as reco
                   from begining
                   join gross
                   on (begining.fecha_datos=gross.fecha_datos)
                   join disco
                   on (begining.fecha_datos=disco.fecha_datos)
                   join reco
                   on (begining.fecha_datos=reco.fecha_datos)
                   order by 1


                   ")
result <- fetch(query)
t<-result


t$FECHA_DATOS<-as.Date(t$FECHA_DATOS)
str(t)


chart.Correlation(t[-c(1)], histogram=TRUE, pch=19)



linearMod<-lm(DISCO~BEGIN ,data = t)
print(linearMod)
# as.formula(
#   paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
#          paste(sprintf(" %+.2f*%s ", 
#                        coefficients(linearMod)[-1],  
#                        names(coefficients(linearMod)[-1])), 
#                collapse="")
#   )
# )
summary(linearMod)

  
(1-MAPE(linearMod))*100






