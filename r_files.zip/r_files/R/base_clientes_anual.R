library(ROracle)
library(dplyr)
library(tictoc)

con <- dbConnect(Oracle(), user="expeam", password="!noviembre2018", dbname="DWH/dwh_olap")

m.mat <- matrix(, nrow = 21, ncol = 3)
i=1
for (MONTH in c(
  "2012-12-31"
  ,"2013-12-31"
  ,"2014-12-31"
  ,"2015-12-31"
  ,"2016-12-31"
  ,"2017-12-31"
  ,"2018-10-31"
))
{
  
  
  FECHA_DATOS <- data.frame(MONTH,MONTH)
  
  
  tic()  
  query <- dbSendQuery(con,"
                       


                        SELECT 
                        to_char(p.fecha_datos,'YYYY') as anho
                       --,count(distinct p.nro_cuenta) as cant_clientes
                       ,sum(p.cant_trx) as trx
                        ,sum(monto) as monto
                        FROM tigo_cash_rpt.product_tracking p
                        WHERE p.fecha_datos BETWEEN trunc(to_date(:1,'YYYY-MM-DD'),'YYYY') AND (to_date(:2,'YYYY-MM-DD'))
--P2P TOTAL
and p.categoria in ('Remittances','Receptores','Cash In','Cash Out')
--P2P WALLET
--and p.categoria in ('Remittances','Receptores')
--and p.subcategoria in ('Pick up','Receive Money','P2P Remittances','P2P Envio','APP P2P Remittances','APP P2P Envio','Receptores')
--P2P_OTC
--and p.categoria in ('Remittances','Receptores','Cash In','Cash Out')
--and p.subcategoria in ('OTC Remittances','Receptores','Cash In','Cash Out')
                       
                       GROUP BY to_char(p.fecha_datos,'YYYY')



                       
                       ",data=FECHA_DATOS)
  
  df <- fetch(query)
  
  m.mat[i,1]=df$ANHO
  m.mat[i,2]=df$TRX
  m.mat[i,3]=df$MONTO

  print(m.mat)
  
  i=i+1
  toc()
  
}

df_mat<-as.data.frame(m.mat)
print(df_mat)
