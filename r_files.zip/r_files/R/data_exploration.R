
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select p.nro_cuenta
                     ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,p.monto
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-04-01' and date'2018-06-30'
                     --AND p.categoria = 'Bill Payments' 
                     --and p.subcategoria = 'MENU Payments'
                     and p.servicio in ('Paquetigo','Paquetigos por 2000','Paquetigos por 3000')
                     
                     ")
t <- fetch(query)
toc()

summary(t)

bins <- c(0,500,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000,6500,7000,7500,8000,8500,9000,9500,10000)
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45))+
  ylab(label="PORCENTAJE")+
  xlab(label="MONTO_CARGA")

bins <- c(0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000,15000,16000,17000,18000,19000,20000,21000,22000,23000,24000,25000,26000,27000,28000,29000,30000)
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45))+
  ylab(label="PORCENTAJE")+
  xlab(label="MONTO_CARGA")




bins <- c(0,10,20,30,40,50,60,70,80,90,100)
ggplot(t,aes(x=EDAD,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="EDAD")

bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)
ggplot(t,aes(x=ANTIGUEDAD_CLIENTE,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  ylab(label="PORCENTAJE")+
  xlab(label="ANTIGUEDAD_CLIENTE")


ggplot(t, aes(x=MONTO)) +
  theme_bw() +
  scale_x_continuous(breaks = pretty(t$MONTO/1000, n = 10)) +
  geom_histogram(alpha=0.6, binwidth=50) +
  ggtitle("Distribucion por TOTAL_CARGA")+
  theme(axis.text.x = element_text(angle=45))


basedate <- as.POSIXct(t$DIA,origin ="1582-10-14", tz = "GMT")
#tiff('C:/Users/edgar/Documents/analisis_envio/comparativo_var_envio_abandono_1.tiff', width = 35, height = 15, units = 'in', res = 300)
ggplot(t, aes(x=DIA,y=DATA )) +
  ggtitle("CORE Vs Envio")+
  geom_line()	+	
  scale_x_datetime(minor_breaks = basedate,breaks=pretty_breaks(n=30)) +
  facet_wrap(~TYPE+BASE, scales = 'free_y', ncol = 2)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=1)+geom_point(size=1/9)+theme(text = element_text(size=10),plot.title = element_text(hjust = 0.5))
#dev.off()