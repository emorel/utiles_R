library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
con<-dbConnect(Oracle(),user="expeam",password="!febrero2018",dbname="DWH")
query<-dbSendQuery(con, "
  
                    with
                    pt as
                   (
                   SELECT sum(p.monto) as monto
                   ,sum(p.monto)/sum(p.cant_trx) as ticket_trx
                   ,sum(p.cant_trx) as cant_trx
                   ,p.fecha_datos as fecha
                   FROM tigo_cash_rpt.product_tracking p
                   WHERE p.fecha_datos BETWEEN date'2016-01-01' AND date'2018-01-31'
                   and p.categoria = 'Merchant Payments'
                   group by p.fecha_datos
                   )
                   ,base as
                   (
                   SELECT v.cantidad
                   ,v.fecha_datos as fecha
                   from expeam.res_base_mfs_dai_cat_ci_60 v
                   where v.fecha_datos BETWEEN date'2016-01-01'-60 AND date'2018-01-31'
                   AND v.categoria = 'Merchant Payments'
                   AND v.disconnects_indicator = 'Begining Day'
                   )
                   select pt.monto/base.cantidad as ticket_cliente
                   ,base.cantidad as cant_cliente
                   ,pt.cant_trx
                   ,pt.ticket_trx
                   ,pt.monto
                   from pt
                   join base on
                   (pt.fecha=base.fecha)
")
result <- fetch(query)
t<-result
str(t)
t1<-select(t,c(TICKET_CLIENTE,CANT_CLIENTE,CANT_TRX,TICKET_TRX,MONTO))
t1<-na.omit(t1)
#t1$MOROSO<-ifelse(t1$MOROSO=="SI",1,0)
str(t1)
summary(t1)

t1$TICKET_CLIENTE<-log(t1$TICKET_CLIENTE)
t1$CANT_CLIENTE<-log(t1$CANT_CLIENTE)
t1$CANT_TRX<-log(t1$CANT_TRX)
t1$TICKET_TRX<-log(t1$TICKET_TRX)
t1$MONTO<-log(t1$MONTO)
str(t1)


#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)


# outlierKD(t1, ANTIGUEDAD_MESES)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, EDAD)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, REVENUE_PROM_4M)
# yes
# t1<-na.omit(t1)
# outlierKD(t1, RECARGA_PROM_4M)
# yes
# t1<-na.omit(t1)
# 


#tomamos una muestra aleatoria

# t1<-subset(t1,AR_KEY %in% (sample(t1$AR_KEY,1700)))
# summary(t1)


t1<-select(t1,c(TICKET_CLIENTE,CANT_CLIENTE,CANT_TRX,TICKET_TRX,MONTO))

t1<-escalc(measure = "RR",ai=TICKET_CLIENTE,bi=CANT_CLIENTE,ci=CANT_TRX,di=TICKET_TRX,data=t1)


str(t1)
rma.glmulti <- function(formula, data, ...)
  rma(formula, vi, data=data, method="ML", ...)

tic()
res <- glmulti(MONTO ~ TICKET_CLIENTE + CANT_CLIENTE + CANT_TRX + TICKET_TRX, data=t1,level=1, fitfunction=rma.glmulti, crit="aicc", confsetsize=128)
toc()

#print(res)
plot(res)
tmp <- weightable(res)
#print(tmp)
tmp <- tmp[tmp$aicc <= min(tmp$aicc) + 2,]
tmp

plot(res,type = "s")

