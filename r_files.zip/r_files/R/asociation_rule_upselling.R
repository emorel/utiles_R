library(ROracle)
library("arules")
library(DescTools)
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")



query <- dbSendQuery(con, "
  
/*
select  
t.ar_sscrbr_dd as nro_cuenta
,t.fnncl_pd_nm as servicio
from expeam.base_finan_7_10 t
where t.fct_dt in (last_day(date'2018-05-01'),last_day(date'2018-06-01'))
and (t.fnncl_pd_nm like '%MB%1500%'
or t.fnncl_pd_nm like '%MB%2000%'
or t.fnncl_pd_nm like '%MB%3000%'
or t.fnncl_pd_nm like '%MB%5000%'
or t.fnncl_pd_nm like '%MB%7000%'
or t.fnncl_pd_nm like '%MB%10000%'
)
*/


select b.ar_key as nro_cuenta
,b.fnncl_pd_nm as servicio
from expeam.base_finan_7_10_daily b
where b.fct_dt = date'2018-02-28'
and b.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'
and (b.fnncl_pd_nm like '%MB%7000%' or b.fnncl_pd_nm like '%MB%10000%')

                     
                     ")
result <- fetch(query)
t <- result


i <- split(t$SERVICIO, t$NRO_CUENTA)
txn <- as(i, "transactions")
length(unique(t$NRO_CUENTA))

lhs1<-unique(subset(t,SERVICIO %like any% c("%7000%"))$SERVICIO)
rhs1<-unique(subset(t,SERVICIO %like any% c( "%10000%"))$SERVICIO)
basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.0002, conf = 0.02),appearance = list(lhs = lhs1,rhs = rhs1))
inspect(head(basket_rules,n=20,by="lift"))
basket_rules <- apriori(txn, parameter = list(maxlen=2,supp = 0.002, conf = 0.006),appearance = list(lhs=c("350MB+20MIN+WAx10000GSx5D"),rhs=c("400MB+30MIN+WAx10000GSx3D")))


basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.02, conf = 0.06),appearance = list(lhs=c("Minicarga"),default="rhs"))

basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.001, conf = 0.8),appearance = list(rhs=c("REVENUE MUY BAJO"),lhs=c("LLUVIA TORRENCIAL"),default="none"))
itemFrequencyPlot(txn, topN = 40)
inspect(basket_rules)
inspect(head(basket_rules,n=20,by="lift"))


