library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")
##############################
######Envio Receptores#######
#############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.tmp_base_rec_envio_mini_2017 p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2017-01-01' and date'2017-12-31'
                     and b.servicio in  ('Envio Receptores','Envio App Receptores')
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-09-01")
dfCBSl<-dfCBS[c(1,4)]
colnames(dfCBSl) <- c("cust","receptor_envio")

###################
#####MINICARGA######
####################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.tmp_base_rec_envio_mini_2017 p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2017-01-01' and date'2017-12-31'
                     and b.servicio in ('Minicarga','Minicarga por sms')
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-09-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3)]
colnames(dfCBSl) <- c("cust","receptor_envio","minicarga")

dfCBSl[is.na(dfCBSl)]<-0

##############################
#####COBRO DE FACTURAS########
##############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.tmp_base_rec_envio_mini_2017 p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2017-01-01' and date'2017-12-31'
                     and b.servicio = 'Cobro de facturas'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-09-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4)]
colnames(dfCBSl) <- c("cust","receptor_envio","minicarga","cobro_factura")

dfCBSl[is.na(dfCBSl)]<-0



############################
#####Retiro de dinero#######
############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.tmp_base_rec_envio_mini_2017 p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2017-01-01' and date'2017-12-31'
                     and b.servicio in ('Retiro de dinero','Retiro de dinero con PIN incl')
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-09-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5)]
colnames(dfCBSl) <- c("cust","receptor_envio","minicarga","cobro_factura","retiro_dinero")

dfCBSl[is.na(dfCBSl)]<-0


