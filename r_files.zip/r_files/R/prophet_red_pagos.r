library(prophet)
library(dplyr)
library(bsts)
library(lubridate)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"


select
count(a.TRANSACCION_ID) as monto
--,sum(monto) as monto
--,to_char(t.FECHAPAGO_DAT,'YYYY-MM') as mes
,to_char(a.FECHAPAGO_DAT,'YYYY-MM-DD') as fecha
--,to_char(t.FECHAPAGO_DAT,'HH24') as hora

from 
(
    select 
    t.TRANSACCION_ID
    ,t.FECHAPAGO_DAT
    ,t.MONTOSINCOMISION_NUM as monto
    from rpl_redpagos.transaccion_mbc t
    union all
    select
    t.TRANSACCION_ID
    ,t.FECHAPAGO_DAT
    ,t.MONTOSINCOMISION_NUM as monto
    from rpl_redpagos.transaccion_prmc t
    union all
    select
    t.TRANSACCION_ID
    ,t.FECHAPAGO_DAT
    ,t.MONTOSINCOMISION_NUM as monto
    from rpl_redpagos.transaccion_tgpg t
) a
where to_char(a.FECHAPAGO_DAT,'YYYY-MM-DD') >= '2016-04-01'
group by to_char(a.FECHAPAGO_DAT,'YYYY-MM-DD')
order by 2


")


result <- fetch(query)


df <- result

df$FECHA <- as.Date(df$FECHA, format = "%Y-%m-%d")

#outlierKD(df, MONTO)
#yes
#df<-na.omit(df)

#outlierKD(df, MONTO)
#yes
#df<-na.omit(df)


colnames(df)<-c("y","ds")

library(dplyr)
playoffs <- data_frame(
  holiday = 'feriados',
  ds = as.Date(c('2016-01-01', '2016-02-29','2016-03-24', '2016-03-25', '2016-05-01','2016-05-14','2016-05-15','2016-06-12','2016-08-15','2016-10-03','2016-12-08','2016-12-25',
                 '2017-01-01', '2017-02-27','2017-04-13', '2017-04-14','2017-05-01','2017-05-14','2017-05-15','2017-06-12','2017-08-14','2017-10-02','2017-12-08','2017-12-25',
                 '2018-01-01', '2018-02-26','2018-03-24', '2018-03-25', '2018-05-01','2018-05-14','2018-05-15','2018-06-11','2018-08-15','2018-10-03','2018-12-08','2018-12-25')),
  lower_window = 0,
  upper_window = 1
)
holidays <- bind_rows(playoffs)
#m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality = TRUE, holidays = holidays,seasonality.prior.scale = 200)
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality = TRUE)
#m <- prophet(df,seasonality.prior.scale = 20,changepoint.prior.scale = 0.001)
#m <- prophet()
#m <- add_seasonality(  m, name='weekly', period=7, fourier.order=3, prior.scale=150)



#Daily
future <- make_future_dataframe(m, periods = 60)
tail(future)
#Monthly
#future <- make_future_dataframe(m, periods = 12, freq = 'month')
#tail(future)


##OUTLIERS
# outliers <- (as.Date(df$ds) > as.Date('2015-01-01')
#             & as.Date(df$ds) < as.Date('2016-01-31'))



#df$y[outliers] = NA
#m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE)
#m <- prophet(df)



forecast <- predict(m, future)
tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

prophet_plot_components(m, forecast)
plot(m, forecast)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
##definimos las fechas para el subset
#sf <- c(as.Date('2017-04-01', format = "%Y-%m-%d"),as.Date('2017-04-08', format = "%Y-%m-%d"))
#i <- as.Date('2017-04-15', format = "%Y-%m-%d")
#while (i<=Sys.Date()+28){
#	sf <- append(sf,i)
#	i<-i+7
#}
#solo seleccionamos las fechas del reporte del comite
##cada 7 dias
#subset(forecast[c("ds","yhat")],forecast$ds %in% sf)
#write.csv(subset(forecast[c("ds","yhat")],forecast$ds %in% sf),"forecast_merchant_payment.csv")

df_month<-forecast %>% group_by(month=floor_date(ds,'month')) %>%  summarize(amount=sum(yhat))


# df_month<-data.frame(
# "FECHA"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,as.character(as.Date(forecast$ds, format = "%Y-%m-%d")),NA)
# ,"DATO"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,forecast$yhat,NA)
# )
# df_month<-na.omit(df_month)
# df_month<-as.data.frame(df_month)

#write.csv(df_month,"forecast_1.csv",row.names=FALSE)
write.table(df_month,file="forecast_1.csv",sep=";",row.names = FALSE)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
#write.csv(forecast[c("ds","yhat")],"forecast_1.csv")

