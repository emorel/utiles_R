# Anti-churn
# References:
# http://brucehardie.com/papers/018/fader_et_al_mksc_05.pdf
# http://brucehardie.com/notes/004/bgnbd_spreadsheet_note.pdf
# https://cran.r-project.org/web/packages/BTYD/vignettes/BTYD-walkthrough.pdf

# Execute the following 2 lines to install the BTYD package
# debug(utils:::unpackPkgZip)
# install.packages('BTYD')

library(hypergeo)
library(BTYD)
library(ROracle)
library(tictoc)

# Clear console, equivalent to Ctrl + l
cat("\014")

# Set working directory
setwd('C:\\Users\\expeam\\Documents\\BI\\2019\\02-febrero\\antichurn\\proceso')

# IMPLEMENTACION DEL MODELO ANTI-CHURN PREPAGO
#########################################################################

# if(FALSE) {
#   
#   # Load libraries
#   library(DBI)
#   library(ROracle)
#   
#   # tns data can be read from file like this: tns = read.csv("panza_tns.csv")
#   
#   # Establish connection to the database
#   con <- dbConnect(ROracle::Oracle(),
#                    dbname = "PANZA", 
#                    host = "replicator.telecel.net.py", 
#                    port = 1521, 
#                    user = "tcljml", 
#                    password =.rs.askForPassword("Enter password:"))
#   
#   # Check if db connection works with: 
#   dbReadTable(con, 'DUAL')
#   
#   recargas <- dbReadTable(con, "T_RECARGA_TRANSAC")
#   
#   dbDisconnect(con)
#   remove(con)
# }

con <- dbConnect(Oracle(), user="expeam", password="!junio2019", dbname="DWH/dwh_olap")
recargas <- dbReadTable(con, "T_RECARGA_TRANSAC")

# Se crean matrices para entrenar el modelo
elog <- recargas[,c('AR_KEY','FCT_DT','AMOUNT')]
colnames(elog) <- c('cust', 'date', 'sales')
elog$date <- as.Date(elog$date)

elog <- dc.MergeTransactionsOnSameDate(elog)

#end.of.cal.period <- as.Date("2019-05-15") # Ultimo dia de recarga antes de prediccion
end.of.cal.period <- as.Date(format(Sys.Date()-1,"%Y/%m/%d")) # Ultimo dia de recarga antes de prediccion (ayer)

elog.cal <- elog[which(elog$date <= end.of.cal.period), ]

split.data <- dc.SplitUpElogForRepeatTrans(elog.cal)
clean.elog <- split.data$repeat.trans.elog

freq.cbt <- dc.CreateFreqCBT(clean.elog)
reach.cbt <- dc.CreateReachCBT(clean.elog)
spend.cbt <- dc.CreateSpendCBT(clean.elog , is.avg.spend = FALSE)

tot.cbt <- dc.CreateFreqCBT(elog)
cal.cbt <- dc.MergeCustomers(tot.cbt, freq.cbt)

birth.periods <- split.data$cust.data$birth.per 
last.dates <- split.data$cust.data$last.date
cal.cbs.dates <- data.frame(birth.periods, last.dates, end.of.cal.period)
cal.cbs <- dc.BuildCBSFromCBTAndDates(cal.cbt, cal.cbs.dates, per = "week")

# Se optimiza el modelo encontrando los parametros de las distribuciones BG/NBD
params <- bgnbd.EstimateParameters(cal.cbs)
LL <- bgnbd.cbs.LL(params, cal.cbs)

p.matrix <- c(params, LL)
for(i in 1:2) {
  params <- bgnbd.EstimateParameters(cal.cbs, params)
  LL <- bgnbd.cbs.LL(params, cal.cbs)
  p.matrix.row <- c(params, LL)
  p.matrix <- rbind(p.matrix, p.matrix.row)
}
colnames(p.matrix) <- c("r", "alpha", "a", "b", "LL")
rownames(p.matrix) <- 1:3
p.matrix

# Graficos
#bgnbd.PlotTransactionRateHeterogeneity(params)
#bgnbd.PlotDropoutRateHeterogeneity(params)


###########################################################################
# Ir al scoring_script_panza.sql para traer la base completa a scorear

# Scoring
###############################################################################


tic()
query <- dbSendQuery(con,"
                     
                     
SELECT * FROM expeam.t_Recarga_Transac_3_Meses t /*where t.t_i >0*/
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
cal.cbs.base<-df_bkp


#cal.cbs.base <- dbReadTable(con, "T_RECARGA_TRANSAC_3_MESES") # base a scorear

p.alives.base <- bgnbd.PAlive(params, cal.cbs.base[,"X"], cal.cbs.base[,"T_X"], cal.cbs.base[,"T_I"])

# T.star = 1 semana posterior a la calibracion (por ej. 1-abril a 30-junio)
expected.transactions.base <- bgnbd.ConditionalExpectedTransactions(params, T.star = 1, cal.cbs.base[,"X"], cal.cbs.base[,"T_X"], cal.cbs.base[,"T_I"])

cal.cbs.base <- cbind(cal.cbs.base, p.alives.base, expected.transactions.base)
colnames(cal.cbs.base) <- c('AR_KEY', 'AR_SSCRBR_DD', 'X', 'T_X', 'T_I', 'P', 'EXPECTED_TRANSACTIONS')
# 
# #conectar a DWH para escribir los resultados
# if(FALSE) {
#   
#   con2 <- dbConnect(ROracle::Oracle(),
#                     dbname = "DWH", 
#                     host = "dwh4m.telecel.net.py", 
#                     port = 1521, 
#                     user = "tcljml", 
#                     password =.rs.askForPassword("Enter password:"))
#   
#   # Check if db connection works with: 
#   dbReadTable(con2, 'DUAL')
#   
#   dbDisconnect(con2)
#   remove(con2)
# }

# Tirar resultados en PANZA y DWH
dbWriteTable(con,"T_ANTICHURN_09_JUN_19", cal.cbs.base, rownames=FALSE, overwrite = TRUE, append = FALSE)

# Ir al scoring_script_dwh.sql
