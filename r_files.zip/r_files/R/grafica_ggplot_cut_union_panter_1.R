
library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(dplyr)
library(scales)
library(ggplot2)
library(reshape2)
library(data.table)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")



tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select *
                     from expeam.tmp_base_pospago_mb_consumo m
                     where m.fecha between date'2017-01-01' and date'2017-02-31'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_control<-df_bkp
dbDisconnect(con)

#object.size(base_b)

#base_b<-fread("C:/Users/expeam/Documents/BI/2019/02-febrero/pospago_brackets_consumo/base_pospago_consumo.csv",sep = ";")
#base_b<-as.data.frame(base_b)
#head(base_b)
#str(base_b)


length(unique(df_control$AR_SSCRBR_DD))
head(df_control)

options(scipen=999)
breaks<-200
df_control$DATA_LMT_BRACKET<- cut( df_control$DATA_LMT, breaks = breaks,dig.lab=0,ordered_result = FALSE)
head(df_control)




dfbracket_group<-df_control[c(2,3,4,5,7)] %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  summarise (n = n()) %>%
  mutate(freq = n / sum(n)*100) %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  summarise(avg_traffic = sum(MB_DATA_TRAFFIC))

dfbracket_group<-df_control %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  mutate(CUENTAS = n()) %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  mutate(TOTAL_DATA_TRAFFIC = sum(MB_DATA_TRAFFIC)) %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  mutate(AVG_DATA_TRAFFIC = TOTAL_DATA_TRAFFIC/CUENTAS)

dfbracket_group<-df_control %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  summarise(n())

dfbracket_group<-df_control %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  mutate(TOTAL_DATA_TRAFFIC = sum(MB_DATA_TRAFFIC))

dfbracket_group<-df_control %>%
  group_by(DATA_LMT_BRACKET,FECHA) %>%
  mutate(avg_data_traffic = total_data_traffic/cuentas)

str(dfbracket_group)
tail(dfbracket_group)

dfbracket_group$FECHA<-as.Date(dfbracket_group$FECHA,'YYYY-MM-DD')
str(dfbracket_group)

ggplot(dfbracket_group,aes(x=FECHA,y=AVG_DATA_TRAFFIC))+
  #geom_line(color="steelblue",size=2)+
  scale_x_date(breaks = pretty_breaks(n=10))+
  facet_wrap(~DATA_LMT_BRACKET,scales="free_y",ncol=10,nrow=1)+
  theme(axis.text.x = element_text(angle = 45))+
  geom_smooth(span=0.3,method='loess',size=1.5)+
  geom_point(size=1,color="blue")+
  theme(text=element_text(size=20))

base_avg_scale <- scale(base_avg)

base_avg_scale<-mutate_if(base_avg,is.numeric,scale)



write.table(base_avg_scale,"C:/Users/expeam/Documents/BI/2019/02-febrero/pospago_brackets_consumo/base_avg_scale.csv",sep = ";",row.names = FALSE)
