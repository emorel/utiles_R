library(dplyr)
library(ggplot2)
outlierKD(thepiratebay,size)
thepiratebay<-na.omit(thepiratebay)
summary(thepiratebay)
plot(thepiratebay)

ggplot(data = thepiratebay) +
  geom_histogram(mapping = aes(x = size/1000000), binwidth = 100)

ggplot(data = thepiratebay, mapping = aes(x = size/1000000, colour = category)) +
  geom_freqpoly(binwidth = 100)

ggplot(data = thepiratebay, mapping = aes(x = size/1000000)) + 
  geom_freqpoly(mapping = aes(colour = category), binwidth = 100)

ggplot(data = thepiratebay, mapping = aes(x = category, y = size/1000000)) +
  geom_boxplot()

thepiratebay$category<-as.factor(thepiratebay$category)

ggplot(data = subset(thepiratebay,category==501)) +
  geom_histogram(mapping = aes(x = size/1000000), binwidth = 100)

ggplot(data = thepiratebay) +
  geom_count(mapping = aes(x = size/1000000, y = category))

thepiratebay %>% 
  count(category, size/1000000) %>%  
  ggplot(mapping = aes(x = category, y = size/1000000)) +
  geom_tile(mapping = aes(fill = n))


xs=quantile(thepiratebay$size,c(0,1/3,2/3,1))
xs[1]=xs[1]-.00005
thepiratebay <- thepiratebay %>% mutate(size_f=cut(thepiratebay$size, breaks=xs, labels=c("low","middle","high")))
boxplot(thepiratebay$size~thepiratebay$size_f,col=3:5)

thepiratebay <-select(thepiratebay,-category_f)

