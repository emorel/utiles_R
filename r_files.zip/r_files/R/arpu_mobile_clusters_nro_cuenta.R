dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 1'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                    select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                    
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu1 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 2'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu2 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 3'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu3 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 4'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
 
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
 
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu4 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 5'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu

                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu5 <- fetch(query)
toc()



dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 6'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu6 <- fetch(query)
toc()



dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 7'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     
                     )
                     and ar.FCT_DT = last_day(date'2018-01-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-02-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-03-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-04-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-05-01')
                     and ar.PAYMENT = 'PRE'
                     
                     union all
                     
                     select sum(ar.REV_COMMUNICATION+ar.REV_INFORMATION+ar.REV_SOLUTION+ar.REV_ENTERTAIMENT)/count(distinct ar.ar_sscrbr_dd) as arpu
                     
                     from dtl.ar_monthly_base_fct ar
                     where ar.ar_sscrbr_dd in 
                     (
                     SELECT b.document_number
                     from expeam.tmp_ci_app_ussd b
                     )
                     and ar.FCT_DT = last_day(date'2018-06-01')
                     and ar.PAYMENT = 'PRE'
                     
                     
                     ")
arpu7 <- fetch(query)
toc()
head(arpu1)
head(arpu2)
head(arpu3)
head(arpu4)
head(arpu5)
head(arpu6)
head(arpu7)