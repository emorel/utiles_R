library(stats)
library(caTools)
library(Amelia)
library(dplyr)

con <- dbConnect(Oracle(), user="expeam", password="!enero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"
                     
                     select *
                     from expeam.tmp_base_modelo_fielco_1
                     
                     
                     
                     
                     ")
df <- fetch(query)
#summary(t)
str(df)
length(unique(df$AR_KEY))

df<-subset(df,ANTIGUEDAD_MESES>=7 & REVENUE_PROM_4M >=30000 & EDAD >= 18)
length(unique(df$AR_KEY))

df$ESTADO<-as.factor(df$ESTADO)
df$TIPO_CUENTA_MODALIDAD<-as.factor(df$TIPO_CUENTA_MODALIDAD)
df$MODALIDAD_PAGO<-as.factor(df$MODALIDAD_PAGO)
df$DESCRIPCION_BILLING<-as.factor(df$DESCRIPCION_BILLING)
df$TIPO_PERSONA<-as.factor(df$TIPO_PERSONA)
df$COD_PLAN_CONSUMO<-as.factor(df$COD_PLAN_CONSUMO)
df$ESTADO_CIVIL<-as.factor(df$ESTADO_CIVIL)
df$SEXO<-as.factor(df$SEXO)
df$DEPARTAMENTO<-as.factor(df$DEPARTAMENTO)
df$DISTRITO<-as.factor(df$DISTRITO)
df$MOROSO<-as.factor(df$MOROSO)



df$revenue_rango<-cut(df$REVENUE_PROM_4M/1000, c(0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200))
df$recarga_rango<-cut(df$RECARGA_PROM_4M/1000, c(0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200))
df$edad_rango<-cut(df$EDAD, c(0,10,20,30,40,50,60,70,80,90,100))
df$antiguedad_rango<-cut(df$ANTIGUEDAD_CLIENTE, c(0,3,6,9,12,15,18,21,24,27,30))
df$antiguedad_mes_rango<-cut(df$ANTIGUEDAD_MESES, c(0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160))


# tratamiento basico para bases
df<-na.omit(df)
summary(df)
print(str(df))
length(unique(df$AR_KEY))

#EXCLUIR COLUMNAS DEL MODELO



df<-subset(df,antiguedad_mes_rango == '(45,50]'  |  antiguedad_mes_rango == '(70,75]'  |antiguedad_mes_rango == '(95,100]' |    antiguedad_mes_rango == '(100,105]' |  antiguedad_mes_rango == '(105,110]' |              antiguedad_mes_rango == '(125,130]' |              revenue_rango        ==  '(40,50]'  |             revenue_rango        ==  '(70,80]'  |             revenue_rango        ==  '(160,170]'           )
             
             
df<- select (df,antiguedad_mes_rango,revenue_rango,MOROSO)             
             

str(df)

#GENERAR MODELO
set.seed(123)
sample <- sample.split(df$MOROSO,SplitRatio=0.70)
trainData <- subset(df,sample==TRUE)
testData <- subset(df,sample==FALSE)
telecomModel <- glm(MOROSO ~ .,family=binomial(link="logit"),data=df)
print(summary(telecomModel))
test.predictions <- predict(telecomModel,newdata=testData,type="response")
fitted.results <- ifelse(test.predictions > 0.5,1,0)
testData$MOROSO <- as.character(testData$MOROSO)
testData$MOROSO[testData$MOROSO=="NO"] <- "0"
testData$MOROSO[testData$MOROSO=="SI"] <- "1"
misClasificationError <- mean(fitted.results!=testData$MOROSO)
print(misClasificationError)
accuracyRate <- 1-misClasificationError
print(accuracyRate)

cm<-table(testData$MOROSO,test.predictions > 0.5)
Accuracy <- print((cm[2,2]+cm[1,1])/sum(cm) * 100)
Sensitivity<-print(cm[2,2]/(cm[2,2]+cm[1,2])*100)
Specificity<-print(cm[1,1]/(cm[1,1]+cm[2,1])*100)


save(telecomModel,file = "factura_churn_model.rda")
load("tv_churn_model.rda")

#GENERAR BASE
test.predictions <- predict(telecomModel,newdata=df,type="response")
fitted.results <- ifelse(test.predictions > 0.2,1,0)
#fitted.results <- test.predictions
df$MOROSO <- as.character(df$MOROSO)
df$MOROSO[df$MOROSO=="No"] <- "0"
df$MOROSO[df$MOROSO=="Yes"] <- "1"
results <- cbind(fitted.results,df)
results <- as.data.frame(results)
table(results$fitted.results)
write.csv(results,"churn_tigo_tv.csv")



