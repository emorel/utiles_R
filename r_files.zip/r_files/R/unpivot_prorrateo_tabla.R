library(reshape)

my.df<-base_poblacion_pivot

fun <- function(x) (trunc(x,0))
my.df<-mutate_if(my.df,is.numeric,fun)
my.df[is.na(my.df)]<-0
str(my.df)
#my.df <- as.data.frame(my.df)
#my.result <- melt(my.df, id = c("ID_PDV"))
my.result <-cbind(my.df[1], stack(my.df[-1]))
names(my.df)[1]<-"ID_PDV"
names(my.result)[2]<-"CANT_POBLACION"
names(my.result)[3]<-"MES"

str(my.result)
base.insertar<-my.result
library(ROracle)
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"PDV_POBLACION_2011_2019", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
