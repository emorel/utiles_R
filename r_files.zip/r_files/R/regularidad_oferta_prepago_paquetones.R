
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(ROracle)
con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")
#######
###Cluster de sequiplot
######

dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 7'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

############
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                    select t.ar_key as DOCUMENT_NUMBER
                    ,to_char(t.fct_dt_d,'YYYY-MM-DD') as FECHA_DATOS
                     ,t.fnncl_trnsctn_val as MONTO
                     from expeam.base_finan_7_10_daily t
                     where t.ar_key in
                     (
                      -- cluster
                     select  t.document_number
                     from expeam.tmp_ci_app_ussd t
                     
                     )
                     and t.fct_dt_d between date'2018-03-01' and date'2018-06-30'
                     and t.fnncl_pd_nm 
                     = 
                     '300MB+15MIN+WAx7000GSx2D'
                     --'400MB+30MIN+WAx10000GSx3D'
                     
                     and t.FNNCL_PD_SUB_TP_NM = 'Tigo Money Paquetigos'
                     
                     
                         
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
####en dias
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
length(unique(dfCBS$cust))
round(nbd.EstimateParameters(dfCBS)[2]/
                      nbd.EstimateParameters(dfCBS)[1],2)


tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select t.ar_key as DOCUMENT_NUMBER
                     ,to_char(t.fct_dt_d,'YYYY-MM-DD') as FECHA_DATOS
                     ,t.fnncl_trnsctn_val as MONTO
                     from expeam.base_finan_7_10_daily t
                     where t.ar_key in
                     (
                     -- cluster
                     select  t.document_number
                     from expeam.tmp_ci_app_ussd t
                     
                     )
                     and t.fct_dt_d between date'2018-03-01' and date'2018-06-30'
                     and t.fnncl_pd_nm 
                     = 
                     --'300MB+15MIN+WAx7000GSx2D'
                     '400MB+30MIN+WAx10000GSx3D'
                     
                     and t.FNNCL_PD_SUB_TP_NM = 'Tigo Money Paquetigos'
                     
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
####en dias
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
length(unique(dfCBS$cust))
round(nbd.EstimateParameters(dfCBS)[2]/
                      nbd.EstimateParameters(dfCBS)[1],2)
