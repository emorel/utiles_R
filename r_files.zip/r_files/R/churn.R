#debug(utils:::unpackPkgZip)
#install.packages('dplyr')

library(data.table)   # Fast I/O
library(dplyr)        # Data munging
library(tidyr)        # Data munging
library(lubridate)    # Makes dates easy
library(plotly)       # Interactive charts
library(magrittr)     # pipe operators
library(caret)        # Handy ML functions
library(rpart)        # Decision Trees
library(rpart.plot)   # Pretty tree plots
library(ROCR)         # ML evaluation
library(e1071)        # Misc stat fns
library(randomForest) # rf

set.seed(42)
df <- fread("C:/Users/expeam/Documents/segment/2018/12-diciembre/churn/monthly_data_(2)_(2).csv", drop = 1)
glimpse(df)
str(df)

df %<>%  
  gather(key = date, value = quantity, starts_with("20")) %>%
  separate(date, c("date","paymentMandate"), "_") %>%
  spread(paymentMandate, quantity) %>%
  mutate(incorporation_date = as.Date(incorporation_date),
         date = as.Date(date),
         incorporation_time = round(as.numeric(difftime(as.Date("2014-12-01"), 
                                                        as.Date(incorporation_date), 
                                                        unit="weeks")) / 52.25,
                                    digits = 1)) %>%
  arrange(date)

# What does the new data look like?
glimpse(df)

######################################################



# Create binary 'churn' column  
df$churn <- 0

# For use in for loop - upper bound of data
max.date <- max(df$date)

# Mark all companies as churned in the month immediately their last activity
for (company in unique(df$company_id)) {
  
  # Subset data to company
  df.sub <- subset(df, df$company_id == company)
  
  # Index of last positive mandate OR payment
  last.pos.idx <- tail(which(df.sub$mandates != 0 | df.sub$payments != 0), 1)
  
  # Get date of last activity
  last.activity.date <- df.sub$date[last.pos.idx]
  
  # If less than max.date of dataset mark churn ELSE do nothing i.e. positive at end of period
  if (last.activity.date < max.date) {
    
    # Get churn date (last positive month plus 1mth)
    churn.date <- last.activity.date %m+% months(1)
    
    # Mark month of churn as 1
    df[df$date == churn.date & df$company_id == company, ]$churn <- 1
  }
}

# Multiple rows per company, filter for last month or churn month values...
# Get churners
df %>% filter(churn == 1) -> churners

# Get max date row of remainers (non-churners)
df %>%  
  filter(churn == 0 & !(company_id %in% churners$company_id) & date == max(date)) -> remainers

# Combine and variables coded ready for modelling
churners %>%  
  rbind(remainers) %>%
  mutate(vertical = as.factor(vertical),
         churn    = as.factor(churn)) -> model.df


# Plot churners  
model.df %>%  
  filter(churn == 1) %>%
  group_by(date) %>%
  summarise(n = n()) %>%
  plot_ly( x = ~date, y = ~n, type = 'scatter', mode = 'lines')

table(model.df$churn)  

####Model

######Split Data

# 80/20 train test split  
index    <- createDataPartition(model.df$churn, p = 0.8, list = FALSE)  
train.df <- model.df[index, ]  
test.df  <- model.df[-index, ]

# Check balance of the training split
table(train.df$churn)  
table(test.df$churn)  

##Logistic

# Run model  
Logistic.model <- glm(churn ~ incorporation_time + vertical,  
                      data   = train.df, 
                      family = binomial(link = 'logit'))

# Predict
log.pred <- predict(Logistic.model, newdata = test.df, type = 'response')

# Convert probs to binary
log.pred <- as.factor(ifelse(log.pred > 0.5, 1, 0))

# Evaluation Metrics
log.result    <- confusionMatrix(data = log.pred, test.df$churn)  
log.precision <- log.result$byClass['Pos Pred Value']  
log.recall    <- log.result$byClass['Sensitivity']  
log.F1        <- log.result$byClass['F1']

