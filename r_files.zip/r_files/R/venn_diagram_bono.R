

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                    SELECT distinct b.nro_cuenta as document_number
                     from expeam.tmp_base_bono_fecha_pospago b
                     where b.mes_canje in ('201804','201805')
                    intersect
                    select distinct p.nro_cuenta as document_number
                    from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     AND p.categoria in ('Bill Payments')
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"

                     
                    select distinct p.nro_cuenta as document_number
                    from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     AND p.servicio like '%TV%'
                    and p.nro_cuenta is not null


                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
                    select distinct p.nro_cuenta as document_number
                    from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     AND p.servicio like 'Cobro de facturas'
                      and p.nro_cuenta is not null

                     
                     ")
base3 <- fetch(query)
toc()


#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base1,base2,base3),
  category.names = c("OTROS","FACTURAS HOME","FACTURAS TIGO"),
  filename = 'C:/Users/expeam/Documents/segment/2018/junio/bono/venn_diagramm_bono_billpay_may2018_p_.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple','green'),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  print.mode = 'percent'
  
)

toc() 

