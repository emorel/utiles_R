## customer analysis clusters warm high value low value

library(ROracle)
library(VIM)
library(magrittr)
library(sqldf)
library(dplyr)
library(plotly)

drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!enero2018", dbname="DWH/dwh_olap")

## para instalar paquetes saltando la proteccion del antivirus
debug(utils:::unpackPkgZip)
install.packages('ggplot2')
library(ggplot2)

query <- dbSendQuery(con, "
                     
                     SELECT b.nro_cuenta as \"Customer_id\"
                    ,min(date'2018-03-01'-b.fecha_datos) as \"recency\"
                    ,sum(b.cant) as \"frequency\"
                    ,avg(b.monto) as \"avgorder\"
                    from tigo_cash_rpt.base_cliente_mfs_daily b
                    join expeam.tmp_base_cc_tiendas_oct_nov_17 t
                    on (b.nro_cuenta=t.nro_cuenta)
                    where b.fecha_datos between date'2017-10-01' and date'2018-01-31'
                    GROUP BY b.nro_cuenta
                     
                     ")
result <- fetch(query)
rfmOrders <- result


summary(rfmOrders)

# Display the first lines
head(rfmOrders)

par(mfrow=c(1,2))
# Plot the distribution of the frequency ~ Total
hist(Orders$Total, breaks = 80, main = "Orders", xlab = "Total", col="#2C3E50")
# Plot the distribution of the frequency ~ Avg order
hist(rfmOrders$avgorder, breaks = 80, main = "Average Orders (per customers)", xlab = "Average Orders (per customers)", col="#2C3E50")

#usamos el logaritmo para normalizar nuestros datos!!!
# Use the logarithm for all the variables:
RerfmOrders <- rfmOrders
RerfmOrders$frequency <- log(rfmOrders$frequency)
RerfmOrders$recency <- log(rfmOrders$recency)
RerfmOrders$avgorder <- log(rfmOrders$avgorder)
# Print the first lines
head(RerfmOrders)
summary(RerfmOrders)
# Plot row
par(mfrow=c(1,1))
# Plot the distribution of the log
hist(RerfmOrders$avgorde, breaks = 25, main = "Log (Average Orders (per customers)) ", xlab = "Log (Average Orders (per customers))", col="#2C3E50")

# 1. Run K-means (nstart = 20) and 5 different groups
RerfmOrders <- RerfmOrders %>% filter(frequency>0)
RerfmOrders_ <- RerfmOrders %>% select(recency:avgorder)
RerfmOrders_km <- kmeans(RerfmOrders_, centers = 5, nstart = 20)

# Plot using plotly 
library(plotly)
p <- plot_ly(RerfmOrders, x = RerfmOrders$recency, y = RerfmOrders$avgorder, z = RerfmOrders$frequency, type = "scatter3d", mode = "markers", color=RerfmOrders_km$cluster)%>% layout(showlegend = FALSE)
p %>% layout(showlegend = FALSE)
print(p)
p <- plot
RerfmOrders_km$centers
