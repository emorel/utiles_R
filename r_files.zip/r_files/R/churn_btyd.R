#debug(utils:::unpackPkgZip)
#install.packages('Rmpi')


library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)

con <- dbConnect(Oracle(), user="expeam", password="!enero2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select t.nro_cuenta
                      ,t.fecha_datos
                     ,t.monto
                     from expeam.tmp_envio_2018 t
                     --where t.fecha_datos between '2018-01-01' and '2018-03-31'
                     where t.fecha_datos between '2018-04-01' and '2018-06-30'
                     --where t.fecha_datos between '2018-07-01' and '2018-09-31'
                     --where t.fecha_datos between '2018-10-01' and '2018-12-31'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
dbDisconnect(con)
df<-df_bkp



df<-subset(df, df$NRO_CUENTA %in% sample(df$NRO_CUENTA,5000))

length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
#df<-subset(df,cust %in%(sample(df$cust,size = 1000)))
#dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-02-01")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
#dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-08-01")
#dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-11-01")
dfk<-dfCBS


####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 100,burnin=100,thin=20,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)

table(dfCBS$pactive.pggg)

write.table(dfCBS,file = "C:/Users/expeam/Documents/segment/2018/12-diciembre/churn/envio_btyd_ene_abril_2018.csv",sep = ";",row.names = FALSE)
