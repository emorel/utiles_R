library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(dplyr)
library(readxl)
library(DescTools)

query<-dbSendQuery(con, "
  
                    select 
                   *
                   from  expeam.tmp_base_modelo_fielco_1
")
df <- fetch(query)
df<-na.omit(df)
df$MOROSO<-ifelse(df$MOROSO=="SI",1,0)
str(df)
##########
## MODELO
##########


telecomModel <- lm(MOROSO ~ EDAD+ANTIGUEDAD_MESES+REVENUE_PROM_4M,data=df)
print(summary(telecomModel))
(1-MAE(telecomModel))*100
#(1-MAPE(telecomModel))*100
(1-MSE(telecomModel))*100
(1-RMSE(telecomModel))*100

#################
## PARA PREDICCION
###################
## prueba base 
query<-dbSendQuery(con, "
  
                    select 
                   *
                   from  TIGO_CASH_RPT.V_BASEMICROCREDFIELCO_1003
")
baseTest <- fetch(query)

test.predictions <- predict(telecomModel,newdata=baseTest,type="response")
baseTest$MOROSO <- ifelse(test.predictions > 0.001,1,0)
table(baseTest$MOROSO)
baseFinal<-subset(baseTest,EDAD>=25 & ANTIGUEDAD_MESES >=12 & REVENUE_PROM_4M>=100000 & MOROSO == 0)
str(baseFinal)
summary(baseFinal)
write.table(baseFinal$CLIENTE_MSISDN,"baseMicrocredito_pauta_digital.csv",row.names = FALSE,col.names = FALSE)
