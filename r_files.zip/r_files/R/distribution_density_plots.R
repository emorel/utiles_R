# Load crime data
crime <- read.csv("http://datasets.flowingdata.com/crimeRatesByState-formatted.csv")
crime.new<-crime
# Remove Washington, D.C.
crime.new <- crime[crime$state != "District of Columbia",]

# Remove national averages
crime.new <- crime.new[crime.new$state != "United States ",]

# Box plot
boxplot(crime.new$robbery, horizontal=TRUE, main="Robbery Rates in US")


# Density plot
par(mfrow=c(3, 3))
colnames <- dimnames(crime.new)[[2]]
for (i in 2:8) {
  d <- density(crime.new[,i])
  plot(d, type="n", main=colnames[i])
  polygon(d, col="red", border="gray")
}
