library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(readxl)
library(DescTools)


con<-dbConnect(Oracle(),user="expeam",password="!agosto2018",dbname="DWH")
query<-dbSendQuery(con, "

                    select sum(p.monto) as monto
                    ,sum(p.cant_trx) as cant_trx
                   ,count(distinct p.nro_cuenta) as cant_clientes
                   ,sum(p.monto)/sum(p.cant_trx)  as monto_promedio_trx
                   ,sum(p.monto)/count(distinct p.nro_cuenta) as monto_promedio_cliente
                   --,to_char(p.fecha_datos,'YYYYMM') as mes
                   ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_datos
                   from tigo_cash_rpt.product_tracking p
                   where p.fecha_datos between date'2016-01-01' and date'2018-07-31'
                   and p.servicio = 'Giros Nacionales'
                   --group by to_char(p.fecha_datos,'YYYYMM') 
                   group by p.fecha_datos
                   order by p.fecha_datos


                   ")
result <- fetch(query)
t<-result


View(base_cedulas)

t<-as.data.frame(base_monto_trx_revenue)
#t$FECHA_DATOS<-as.Date(t$FECHA_DATOS)
str(t)

#t<-as.data.frame(log(t[-c(1)]))

# 
t$MONTO_CANJE<-log(t$CANT_TRX)
t$CANT_CANJE<-log(t$MONTO)
t$CANT_CLIENTES_CANJE<-log(t$REVENUE)



chart.Correlation(t, histogram=TRUE, pch=19)
chart.Correlation(t[-c(1)], histogram=TRUE, pch=19)
chart.Correlation(t[-c(6)], histogram=TRUE, pch=19)

plot(t$MONTO_CANJE,t$CANT_CANJE)

library("ggpubr")
ggscatter(t, x = "MONTO_CANJE", y = "CANT_CLIENTES_CANJE", 
          add = "reg.line", conf.int = TRUE, 
          cor.method = "pearson",
          xlab = "Monto canjeado", ylab = "Clientes que canjearon")

ggscatter(t, x = "CANT_CANJE", y = "CANT_CLIENTES_CANJE", 
          add = "reg.line", conf.int = TRUE, 
          cor.method = "pearson",
          xlab = "Cantidad bonos canjeados", ylab = "Clientes que canjearon")

linearMod<-lm(TOTAL_REVENUE~CARGA_TRX+CARGA_MONTO+GIROS_NACIONALES_TRX+GIROS_NACIONALES_MONTO+RETIRO_TRX+RETIRO_MONTO+TRANSFERENCIA_TRX+TRANSFERENCIA_MONTO+TOTAL_TRX+TOTAL_MONTO,data = t[-c(1)])
print(linearMod)
# as.formula(
#   paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
#          paste(sprintf(" %+.2f*%s ", 
#                        coefficients(linearMod)[-1],  
#                        names(coefficients(linearMod)[-1])), 
#                collapse="")
#   )
# )
summary(linearMod)

  
(1-MAPE(linearMod))*100






