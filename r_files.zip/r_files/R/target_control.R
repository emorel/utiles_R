


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")

###############
####TARGET###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                      select *
                      from expeam.TMP_BASE_KPI_TARGET_PRE t
                     where t.fct_dt in (last_day(date'2018-09-01'),last_day(date'2018-10-01'),last_day(date'2018-11-01'))
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_target<-df_bkp

df_target<-subset(df_target,df_target$AR_KEY %in%(sample(df_target$AR_KEY,size = 4000)))

length(unique(df_target$AR_KEY))

###############
####CONTROL###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     
                    select *
                    from expeam.TMP_BASE_KPI_CONTROL_PRE t
                     where t.fct_dt in (last_day(date'2018-09-01'),last_day(date'2018-10-01'),last_day(date'2018-11-01'))
                     
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_control<-df_bkp

df_control<-subset(df_control,df_control$AR_KEY %in%(sample(df_control$AR_KEY,size = 20000)))

length(unique(df_control$AR_KEY))

df_target$TIPO<-1
df_control$TIPO<-0
####################
##EN UNA SOLA TABLA 
###################
df_tg<-rbind(df_target,df_control)
str(df_tg)


#######################
####TRANSFORMACIONES###
#######################

#table(df_tg$ARPU_B)

df_tg<-mutate_if(df_tg,is.character,as.factor)


df_tg$TIPO<-as.factor(df_tg$TIPO)
#df_tg$REGION<-as.factor(df_tg$REGION)
#df_tg$DEVICE_TYPE<-as.factor(df_tg$DEVICE_TYPE)
#table(df_tg$TENURE_B)
#table(df_tg$DATA_CONSUMPTION_B)
#table(df_tg$EDAD_B)
str(df_tg)
df_tg<-na.omit(df_tg)
df_tg <- filter(df_tg, EDAD  > 0, ANTIGUEDAD_MESES > 0, MB_FREE > 0, MB_BILLED > 0
                , AVG_RECHARGE  > 0, MOU > 0, ARPU > 0, DATA_REV > 0, VOICE_REV  > 0
)

str(df_tg)
summary(df_tg)

###############
####BRACKETS###
###############
options(scipen=999)
breaks<-50
df_tg$EDAD_SGM<- cut( df_tg$EDAD, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-20
df_tg$ANTIGUEDAD_MESES_SGM<- cut( df_tg$ANTIGUEDAD_MESES, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$MB_FREE_SGM<- cut( df_tg$MB_FREE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$MB_BILLED_SGM<- cut( df_tg$MB_BILLED, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$AVG_RECHARGE_SGM<- cut( df_tg$AVG_RECHARGE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$MOU_SGM<- cut( df_tg$MOU, breaks = breaks, dig.lab=0,ordered_result = FALSE)
##ARPU
breaks<-100
df_tg$ARPU_SGM<- cut( df_tg$ARPU, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$DATA_REV_SGM<- cut( df_tg$DATA_REV, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-100
df_tg$VOICE_REV_SGM<- cut( df_tg$VOICE_REV, breaks = breaks, dig.lab=0,ordered_result = FALSE)

###########################
#Propensity Score Matching#
########RMatchit###########
###########################




# tic()
# m.out<- matchit(TIPO~DATA_CONSUMPTION+REGION+ARPU+TENURE+DEVICE_SUBTYPE
#                 ,data=df_tg,method = "nearest",ratio=3)
# toc()

tic()
m.out<- matchit(TIPO~CTY_NM+DVC_TYPE+TECNOLOGIA+EDAD_SGM+MB_FREE_SGM+MB_BILLED_SGM+AVG_RECHARGE+MOU_SGM+ARPU_SGM+DATA_REV_SGM+VOICE_REV_SGM,data=df_tg,method = "nearest",exact = c("ARPU_B","TENURE_B","EDAD_B","DEVICE_TYPE","DATA_CONSUMPTION_B","REGION"),ratio=1)
toc()

#summary(m.out)
#plot(m.out,type = "jitter")
#plot(m.out,type = "hist")

df_matched<-match.data(m.out)

str(df_matched)
summary(df_matched)


mean(subset(df_matched,TIPO==1)$ARPU)-
  mean(subset(df_matched,TIPO==0)$ARPU)
# 
# a<-summary(m.out)
# a<-summary(df_matched)
# 
#  kable(a$nn, digits = 2, align = 'c', 
#        caption = 'Table 2: Sample sizes')

# kable(a$sum.matched[c(1,2,4)], digits = 2, align = 'c', 
#       caption = 'Table 3: Summary of balance for matched data')
# 
# a %>%
#   kable() %>%
#   kable_styling()

write.table(df_matched,file = "C:/Users/expeam/Documents/segment/2018/10-octubre/arp_churn_mfs_eleonora/target_control_matched_ene_17.csv",sep = ";",row.names = FALSE)
####################
###ARP Incremental##
###################

base.insertar <-(subset(df_matched,TIPO == 1))$AR_SSCRBR_DD
rs <- dbSendQuery(con, "truncate table expeam.tmp_target1")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_target1 values(:1)", data=base.insertar)
dbCommit(con)



base.insertar <-(subset(df_matched,TIPO == 0))$AR_SSCRBR_DD
rs <- dbSendQuery(con, "truncate table expeam.tmp_control1")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_control1 values(:1)", data=base.insertar)
dbCommit(con)
