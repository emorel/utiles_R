

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
/*SELECT c.ar_key as document_number
from expeam.base_finan_7_10_daily c
                     where c.fct_dt_d between date'2018-01-01' and last_day(date'2018-06-01')
                     and c.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'
                     and c.FNNCL_PD_ALTRNTV_NM = 'PAQUETIGO 555'
*/
                              
/* select p.nro_cuenta as document_number
from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-01-01' and last_day(date'2018-06-01')
                     and p.servicio = 'Paquetigo' */ 

/*  select v.ar_sscrbr_dd as document_number
  from tcljoj.TEMP_MODA_PQ_BY_SUSCRIBER_V2 v
                     where v.fct_dt= last_day(date'2018-06-01')
                     and v.pq_totales >0*/

  select c.nro_cuenta as document_number
  from rpt_information.compra_paquetes_x_canal c
                     where c.fecha between date'2018-06-01' and date'2018-06-30'
                     and lower(c.nombre_generio) like '%money%'
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
/*
  SELECT c.ar_key as document_number
  from expeam.base_finan_7_10_daily c
                     where c.fct_dt_d between date'2018-01-01' and last_day(date'2018-06-01')
                     and c.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'
                     and c.FNNCL_PD_ALTRNTV_NM = 'TIGOSHOP MTS'
*/
/*select p.nro_cuenta as document_number
from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-01-01' and last_day(date'2018-06-01')
                     and p.servicio = 'Paquetigo 222' */

/*  select b.ar_sscrbr_dd as document_number
  from expeam.base_finan_7_10_daily b
                     where b.fct_dt= last_day(date'2018-06-01')
                     and b.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'
                     and b.FNNCL_PD_NM in ('750MBx10000GSx3D','500MBx7000GSx2D' )*/

  select b.ar_sscrbr_dd as document_number
  from expeam.base_finan_7_10_daily b
                     where b.fct_dt= last_day(date'2018-06-01')
                     and b.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'

                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
SELECT c.ar_key as document_number
from expeam.base_finan_7_10_daily c
                     where c.fct_dt_d between date'2018-01-01' and last_day(date'2018-06-01')
                     and c.fnncl_pd_sub_tp_nm='Tigo Money Paquetigos'
                     and c.FNNCL_PD_ALTRNTV_NM = 'TIGOSHOP MTS'

                     
                     ")
base3 <- fetch(query)
toc()


#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$DOCUMENT_NUMBER
base2<-base2$DOCUMENT_NUMBER
base3<-base3$DOCUMENT_NUMBER


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base1,base2),
  category.names = c("chari","ed"),
  filename = 'C:/Users/expeam/Documents/segment/2018/junio/oferta_prepago/venn_diagramm_chard_ed.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple'),
  cex = 0.4,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.4,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  print.mode = 'percent'
  
)

toc() 

