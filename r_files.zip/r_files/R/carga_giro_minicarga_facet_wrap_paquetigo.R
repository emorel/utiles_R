library(ROracle)
library(dplyr)
library(ggplot2)
library(reshape2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)

drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH")

query <- dbSendQuery(con,"
                     
                     
 select 
                     to_char(last_day(p.fecha_datos),'YYYY-MM-DD') as fecha
                     --,sum(p.monto)/sum(p.cant_trx) as cantidad
                      --,sum(p.cant_trx) as cantidad
                     ,sum(p.monto)  as cantidad
                     --,p.subcategoria as categoria
                     ,case when p.servicio in ('Paquetigo','Paquetigos por 2000','Paquetigos por 3000') then 'Paquetigo' else p.servicio end as categoria
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between DATE'2017-01-01' AND DATE'2018-05-31'
                     --and p.servicio like '%inicarga%'
                     --and p.servicio in ('Carga de dinero','Giros Nacionales','Retiro de dinero')
                     and p.subcategoria = 'Menu'
                     group by to_char(last_day(p.fecha_datos),'YYYY-MM-DD'),case when p.servicio in ('Paquetigo','Paquetigos por 2000','Paquetigos por 3000') then 'Paquetigo' else p.servicio end
                     
                     ")


result <- fetch(query)
t <- result

t$FECHA <- as.Date(t$FECHA, format = "%Y-%m-%d")

tiff('C:/Users/expeam/Documents/segment/2018/junio/analisis_semana_revenue/comparativo_selftopup_paquetigo_mayo2018.tiff', width = 45, height = 55, units = 'in', res = 300)
ggplot(t, aes(x=FECHA,y=CANTIDAD/1000000 )) +
  ggtitle("SELF TOP UP - Ticket Promedio")+
  geom_line()	+	
  scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  facet_wrap(~CATEGORIA, scales = 'free_y', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=50),plot.title = element_text(hjust = 0.5))
#geom_text(aes(label=TIPO_DIA,color="Feriados"),size=10)
dev.off()
