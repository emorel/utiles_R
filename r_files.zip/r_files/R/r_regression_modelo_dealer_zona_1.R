
library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)

library(tidyverse)
library(caret)



############################
########DEALERS############
###########################

for (i in c('ANTELL','COMCEL','LOTHAR')) {

  con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")

  query <- dbSendQuery(con,"
                       
                       
                       select
                       k.circuito
                       ,count(distinct k.id_pdv) as cant_pdv
                       ,sum(k.cant_clientes)/3 as cant_clientes
                       ,sum(k.cant_clientes_fcst)/3 as cant_clientes_fcst
                       ,sum(k.hs_sin_saldo)/3 as hs_sin_saldo
                       ,sum(k.hs_sin_saldo)/(13*31*count(distinct k.id_pdv)) as quiebre
                       ,sum(k.poblacion)/3 as poblacion
                       ,sum(k.ventas)/3 as ventas
                       from expeam.base_distrib_kpi_mapeo k
                       where k.mes in (201812)
                       and k.dealer = :1
                       --and k.zona = 'ITAP�A'
                       group by
                       k.circuito
                       
                       
                       ",data= i)
  df_bkp<- fetch(query)

  df<-df_bkp
  dbDisconnect(con)
  
  my_data <- df
  
  
  options(scipen=999)
  my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
  

  data<-my_data
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
  
  summary(telecomModel)
  VIF(telecomModel)
  print(coefficients(telecomModel))


}




############################
##########ANTELL############
############################

for (i in c('AMAMBAY','ASUNCI�N','CAAGUAZ�','CONCEPCI�N + CHACO','CORDILLERA','GRAN ASUNCI�N','SAN PEDRO')) {
  
  con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")

  query <- dbSendQuery(con,"
                       
                       
                       select
                       k.circuito
                       ,count(distinct k.id_pdv) as cant_pdv
                       ,sum(k.cant_clientes)/3 as cant_clientes
                       ,sum(k.cant_clientes_fcst)/3 as cant_clientes_fcst
                       ,sum(k.hs_sin_saldo)/3 as hs_sin_saldo
                       ,sum(k.hs_sin_saldo)/(13*31*count(distinct k.id_pdv)) as quiebre
                       ,sum(k.poblacion)/3 as poblacion
                       ,sum(k.ventas)/3 as ventas
                       from expeam.base_distrib_kpi_mapeo k
                       where k.mes in (201812)
                       and k.dealer = 'ANTELL'
                       and k.zona = :1
                       group by
                       k.circuito
                       
                       
                       ",data= i)
  df_bkp<- fetch(query)

  df<-df_bkp
  dbDisconnect(con)
  
  my_data <- df
  
  
  options(scipen=999)
  my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
  

  data<-my_data
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
  
  #summary(telecomModel)
  #VIF(telecomModel)
  print(coefficients(telecomModel))
  
  
}


############################
##########COMCEL############
############################

for (i in c('ASUNCI�N','CORDILLERA','GRAN ASUNCI�N','GUAIR� + CAAZAP�','�EEMBUCU + MISIONES','PARAGUARI')) {
  
  con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
  
  query <- dbSendQuery(con,"
                       
                       
                       select
                       k.circuito
                       ,count(distinct k.id_pdv) as cant_pdv
                       ,sum(k.cant_clientes)/3 as cant_clientes
                       ,sum(k.cant_clientes_fcst)/3 as cant_clientes_fcst
                       ,sum(k.hs_sin_saldo)/3 as hs_sin_saldo
                       ,sum(k.hs_sin_saldo)/(13*31*count(distinct k.id_pdv)) as quiebre
                       ,sum(k.poblacion)/3 as poblacion
                       ,sum(k.ventas)/3 as ventas
                       from expeam.base_distrib_kpi_mapeo k
                       where k.mes in (201812)
                       and k.dealer = 'COMCEL'
                       and k.zona = :1
                       group by
                       k.circuito
                       
                       
                       ",data= i)
  df_bkp<- fetch(query)
  
  df<-df_bkp
  dbDisconnect(con)
  
  my_data <- df
  
  
  options(scipen=999)
  my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
  

  data<-my_data
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
  
  #summary(telecomModel)
  #VIF(telecomModel)
  print(coefficients(telecomModel))
  
  
}


############################
##########LOTHAR############
############################

for (i in c('ALTO PARAN�','CANINDEY�','CIUDAD DEL ESTE','ITAP�A')) {
  
  con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
  
  query <- dbSendQuery(con,"
                       
                       
                       select
                       k.circuito
                       ,count(distinct k.id_pdv) as cant_pdv
                       ,sum(k.cant_clientes)/3 as cant_clientes
                       ,sum(k.cant_clientes_fcst)/3 as cant_clientes_fcst
                       ,sum(k.hs_sin_saldo)/3 as hs_sin_saldo
                       ,sum(k.hs_sin_saldo)/(13*31*count(distinct k.id_pdv)) as quiebre
                       ,sum(k.poblacion)/3 as poblacion
                       ,sum(k.ventas)/3 as ventas
                       from expeam.base_distrib_kpi_mapeo k
                       where k.mes in (201812)
                       and k.dealer = 'LOTHAR'
                       and k.zona = :1
                       group by
                       k.circuito
                       
                       
                       ",data= i)
  df_bkp<- fetch(query)
  
  df<-df_bkp
  dbDisconnect(con)
  
  my_data <- df
  
  
  options(scipen=999)
  my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
  

  data<-my_data
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
  
  #summary(telecomModel)
  #VIF(telecomModel)
  print(coefficients(telecomModel))
  
  
}