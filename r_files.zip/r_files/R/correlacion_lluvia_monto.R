
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)
library(readxl)

library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
select 
g.\"HORAS_EN_QUIEBRE\"
,g.\"Q_QUIEBRE\"
,g.\"CANT_CLIENTES\"
,g.\"CANT_CLIENTES_EKYC\"
,g.\"TRX#_CARGA_DINERO\"
,g.\"TRX#_GIROS\"
,g.\"TRX#_RETIROS\"
,g.trx#_otros
,g.\"CARGA/GIRO+CARGA%\"
,g.\"TRX#\"
,g.\"MONTO_BILLETERA\"
,g.\"CANT_TRX_CARGA_DEALER\"
,g.monto_carga_dealer
from expeam.g2m_daily_ptm g

                     
                     ")
df_backup <- fetch(query)
toc()
df<-df_backup


base_estudio_lluvia <- read_excel("segment/2018/febrero/estudio_lluvia/base_estudio_lluvia_2016_2017_2018_ASUNCION.xlsx",col_types = c("numeric", "numeric"))
df<-base_estudio_lluvia

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df<-scale(df)
df<-as.data.frame(df)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df$ML<-log(df$ML)
df$MONTO<-log(df$MONTO)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

##correr tres veces minimo

outlierKD(df, ML)
yes
df<-na.omit(df)
outlierKD(df, MONTO)
yes
df<-na.omit(df)



