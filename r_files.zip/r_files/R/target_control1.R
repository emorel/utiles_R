


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")

###############
####TARGET###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     select *
                     from expeam.tmp_base_target1
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_target<-df_bkp

df_target<-subset(df_target,df_target$AR_SSCRBR_DD %in%(sample(df_target$AR_SSCRBR_DD,size = 10000)))

length(unique(df_target$AR_SSCRBR_DD))

###############
####CONTROL###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select *
                     from expeam.tmp_base_control1
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_control<-df_bkp
#df_control<-subset(df_control,df_control$AR_SSCRBR_DD %in%(sample(df_control$AR_SSCRBR_DD,size = 50000)))

length(unique(df_control$AR_SSCRBR_DD))
df_tg<-rbind(df_target,df_control)
###############
####BRACKETS###
###############
options(scipen=999)
breaks<-500
df_tg$ARPU_B<- cut( df_tg$ARPU, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-200
df_tg$DATA_CONSUMPTION_B<- cut( df_tg$DATA_CONSUMPTION, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-20
df_tg$TENURE_B<- cut( df_tg$TENURE, breaks = breaks, dig.lab=0,ordered_result = FALSE)
breaks<-50
df_tg$EDAD_B<- cut( df_tg$EDAD, breaks = breaks, dig.lab=0,ordered_result = FALSE)
#################


#table(df_tg$ARPU_B)




df_tg$TIPO<-as.factor(df_tg$TIPO)
df_tg$REGION<-as.factor(df_tg$REGION)
df_tg$DEVICE_TYPE<-as.factor(df_tg$DEVICE_TYPE)
#table(df_tg$TENURE_B)
#table(df_tg$DATA_CONSUMPTION_B)
#table(df_tg$EDAD_B)
str(df_tg)
df_tg<-na.omit(df_tg)
str(df_tg)
summary(df_tg)

###########################
#Propensity Score Matching#
########RMatchit###########
###########################




# tic()
# m.out<- matchit(TIPO~DATA_CONSUMPTION+REGION+ARPU+TENURE+DEVICE_SUBTYPE
#                 ,data=df_tg,method = "nearest",ratio=3)
# toc()

tic()
m.out<- matchit(TIPO~ARPU+DATA_CONSUMPTION+TENURE+REGION+DEVICE_TYPE+EDAD,data=df_tg,method = "nearest",exact = c("ARPU_B","TENURE_B","EDAD_B","DEVICE_TYPE","DATA_CONSUMPTION_B","REGION"),ratio=1)
toc()

#summary(m.out)
#plot(m.out,type = "jitter")
#plot(m.out,type = "hist")

df_matched<-match.data(m.out)

str(df_matched)
summary(df_matched)


mean(subset(df_matched,TIPO==1)$ARPU)-
mean(subset(df_matched,TIPO==0)$ARPU)
# 
 # a<-summary(m.out)
 # a<-summary(df_matched)
 # 
 #  kable(a$nn, digits = 2, align = 'c', 
 #        caption = 'Table 2: Sample sizes')
 
# kable(a$sum.matched[c(1,2,4)], digits = 2, align = 'c', 
#       caption = 'Table 3: Summary of balance for matched data')
# 
 # a %>%
 #   kable() %>%
 #   kable_styling()

write.table(df_matched,file = "C:/Users/expeam/Documents/segment/2018/10-octubre/arp_churn_mfs_eleonora/target_control_matched_ene_17.csv",sep = ";",row.names = FALSE)
####################
###ARP Incremental##
###################

base.insertar <-(subset(df_matched,TIPO == 1))$AR_SSCRBR_DD
rs <- dbSendQuery(con, "truncate table expeam.tmp_target1")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_target1 values(:1)", data=base.insertar)
dbCommit(con)



base.insertar <-(subset(df_matched,TIPO == 0))$AR_SSCRBR_DD
rs <- dbSendQuery(con, "truncate table expeam.tmp_control1")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_control1 values(:1)", data=base.insertar)
dbCommit(con)
