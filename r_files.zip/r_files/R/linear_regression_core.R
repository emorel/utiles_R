library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(readxl)
library(DescTools)


con<-dbConnect(Oracle(),user="expeam",password="!july2018",dbname="DWH")
query<-dbSendQuery(con, "


                    with
                   carga_mts as
                   (
                   SELECT 
                   last_day(p.fecha_datos) as fecha
                   ,sum(p.monto) as monto
                   ,sum(p.cant_trx) as cant_trx
                   ,COUNT(distinct P.NRO_CUENTA) as cant_clientes
                   from tigo_cash_rpt.product_tracking p
                   where p.fecha_datos BETWEEN DATE'2017-01-01' AND DATE'2018-06-30'
                   and p.servicio in ('Carga de dinero')
                   group by last_day(p.fecha_datos) 
                   )
                   ,giro_mts as
                   (
                   SELECT 
                   last_day(p.fecha_datos)  as fecha
                   ,sum(p.monto) as monto 
                   ,sum(p.cant_trx) as cant_trx
                   ,COUNT(distinct P.NRO_CUENTA) as cant_clientes
                   from tigo_cash_rpt.product_tracking p
                   where p.fecha_datos BETWEEN DATE'2017-01-01' AND DATE'2018-06-30'
                   and p.servicio in ('Giros Nacionales')
                   group by last_day(p.fecha_datos) 
                   )
                   
                   select carga_mts.fecha
                   ,carga_mts.monto as monto_carga
                   ,giro_mts.monto as monto_giro
                   ,carga_mts.cant_trx as trx_carga
                   ,giro_mts.cant_trx as trx_giro
                   ,carga_mts.cant_clientes as cant_clientes_carga
                   ,giro_mts.cant_clientes as cant_clientes_giro  
                   from carga_mts
                   join giro_mts
                   on (carga_mts.fecha=giro_mts.fecha)
                   order by 1
                   
                   
                   ")
result <- fetch(query)
t1<-result



t<-as.data.frame(t1)
str(t)

#t<-as.data.frame(log(t[-c(1)]))

# 
# t$CANT_PTM<-log(t$CANT_PTM)
# t$CANT_CLIENTES<-log(t$CANT_CLIENTES)
# t$CANT_CLIENTE<-log(t$CANT_CLIENTES)


#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)

chart.Correlation(t, histogram=TRUE, pch=19)
chart.Correlation(t[-c(1)], histogram=TRUE, pch=19)


linearMod<-lm(CANT_CLIENTES_CARGA~MONTO_CARGA+MONTO_GIRO+TRX_CARGA+TRX_GIRO+CANT_CLIENTES_GIRO,data = t)
print(linearMod)
# as.formula(
#   paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
#          paste(sprintf(" %+.2f*%s ", 
#                        coefficients(linearMod)[-1],  
#                        names(coefficients(linearMod)[-1])), 
#                collapse="")
#   )
# )
summary(linearMod)


(1-MAPE(linearMod))*100






