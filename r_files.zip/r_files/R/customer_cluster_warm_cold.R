## customer analysis clusters warm high value low value
