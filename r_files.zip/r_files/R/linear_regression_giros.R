library('ROracle')
library(glmulti)
library(dplyr)
library(metafor)
library(tictoc)
library("PerformanceAnalytics")
library(tictoc)
library(stats)
library(caTools)
library(Amelia)
library(readxl)
library(DescTools)


con<-dbConnect(Oracle(),user="expeam",password="!agosto2018",dbname="DWH")
query<-dbSendQuery(con, "

                    select sum(p.monto) as monto
                    ,sum(p.cant_trx) as cant_trx
                   ,count(distinct p.nro_cuenta) as cant_clientes
                   ,sum(p.monto)/sum(p.cant_trx)  as monto_promedio_trx
                   ,sum(p.monto)/count(distinct p.nro_cuenta) as monto_promedio_cliente
                   --,to_char(p.fecha_datos,'YYYYMM') as mes
                   ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_datos
                   from tigo_cash_rpt.product_tracking p
                   where p.fecha_datos between date'2016-01-01' and date'2018-07-31'
                   and p.servicio = 'Giros Nacionales'
                   --group by to_char(p.fecha_datos,'YYYYMM') 
                   group by p.fecha_datos
                   order by p.fecha_datos


                   ")
result <- fetch(query)
t<-result


library(readxl)
base_cedulas <- read_excel("segment/2018/agosto/budget/base_cedulas.xlsx", 
                           sheet = "bases_productos")
View(base_cedulas)

t<-as.data.frame(base_giros)
t$fecha<-as.Date(t$fecha)
str(t)

#t<-as.data.frame(log(t[-c(1)]))

# 
# t$CANT_PTM<-log(t$CANT_PTM)
# t$CANT_CLIENTES<-log(t$CANT_CLIENTES)
# t$CANT_CLIENTE<-log(t$CANT_CLIENTES)


#t1$ANTIGUEDAD_MESES<-(t1$ANTIGUEDAD_MESES-mean(t1$ANTIGUEDAD_MESES))/sd(t1$ANTIGUEDAD_MESES)
#t1$EDAD<-(t1$EDAD-mean(t1$EDAD))/sd(t1$EDAD)
#t1$REVENUE_PROM_4M<-(t1$REVENUE_PROM_4M-mean(t1$REVENUE_PROM_4M))/sd(t1$REVENUE_PROM_4M)
#t1$RECARGA_PROM_4M<-(t1$RECARGA_PROM_4M-mean(t1$RECARGA_PROM_4M))/sd(t1$RECARGA_PROM_4M)

chart.Correlation(t, histogram=TRUE, pch=19)
chart.Correlation(t[-c(1)], histogram=TRUE, pch=19)
chart.Correlation(t[-c(6)], histogram=TRUE, pch=19)


linearMod<-lm(base~monto+cant_trx+ticket_trx+ticket_cliente ,data = t)
print(linearMod)
# as.formula(
#   paste0("y ~ ", round(coefficients(linearMod)[1],2), "", 
#          paste(sprintf(" %+.2f*%s ", 
#                        coefficients(linearMod)[-1],  
#                        names(coefficients(linearMod)[-1])), 
#                collapse="")
#   )
# )
summary(linearMod)

  
(1-MAPE(linearMod))*100






