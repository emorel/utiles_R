library(ROracle)
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
library("arules")


query <- dbSendQuery(con, "
                     
                     SELECT b.nro_cuenta,b.servicio
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     
                     ")
result <- fetch(query)
t <- result


i <- split(t$SERVICIO, t$NRO_CUENTA)
txn <- as(i, "transactions")
#basket_rules <- apriori(txn, parameter = list(sup = 0.005, conf = 0.01, target="rules"))
#basket_rules <- apriori(txn, parameter = list(supp = 0.08, conf = 0.8))
basket_rules <- apriori(txn, parameter = list(minlen=1,supp = 0.0002, conf = 0.0008),appearance = list(lhs=c("Carga de dinero","Transferencia Receptores","Giros Nacionales Receptores"),rhs=c("Pago de Servicios"),default="none"))
basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.002, conf = 0.06),appearance = list(rhs=c("Giros App","Envio App","Minicarga App"),default="lhs"))
basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.001, conf = 0.8),appearance = list(rhs=c("REVENUE MUY BAJO"),lhs=c("LLUVIA TORRENCIAL"),default="none"))
itemFrequencyPlot(txn, topN = 40)
inspect(basket_rules)
basket_rules_broad <- apriori(txn, parameter = list(sup = 0.001, conf = 0.001, target="rules"))
inspect(head(basket_rules,n=20,by="lift"))



inspect(head(basket_rules,n=20,by="lift"))
