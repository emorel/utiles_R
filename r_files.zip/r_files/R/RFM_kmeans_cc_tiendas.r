
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(factoextra)
library(plotly)

con <- dbConnect(Oracle(), user="expeam", password="!enero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"

SELECT 
d.nro_cuenta
,sum(d.monto) as monto
,sum(d.revenue) as revenue
,t.tipo

,min(trunc(sysdate)-d.fecha_datos) as recency
,sum(d.cant_trx) as frequency
,sum(d.monto) as monetary

FROM expeam.v_product_tracking_rev_diario d
join expeam.tmp_base_cc_regalo_no t
on (d.nro_cuenta=t.nro_cuenta)    
WHERE d.fecha_datos BETWEEN DATE'2017-10-01' AND DATE'2018-01-31'
GROUP BY d.nro_cuenta
,t.tipo


")

df <- fetch(query)

df$NRO_CUENTA <-as.factor(df$NRO_CUENTA)
df$RECENCY <- log(df$RECENCY)
df$FREQUENCY <- log(df$FREQUENCY)
df$MONETARY <- log(df$MONETARY)
df$TIPO <-as.factor(df$TIPO)

# outlierKD(df, RECENCY)
# yes
# 
# outlierKD(df, RECENCY)
# yes
# 
# outlierKD(df, FREQUENCY)
# yes
# 
# outlierKD(df, FREQUENCY)
# yes
# 
# outlierKD(df, MONETARY)
# yes
# 
# outlierKD(df, MONETARY)
# yes

df<-na.omit(df)
str(df)
summary(df)

dat<-df

##DETERMINAR LA CANTIDAD DE CLUSTERS
#set.seed(123)
#fviz_nbclust(dat[,c(-1,-5)], kmeans, method = "wss")


fit <- kmeans(dat[,c(-1,-2,-3,-4)], 6, iter.max=3000)

length(unique(dat$NRO_CUENTA))

table(fit$cluster)



barplot(table(fit$cluster), col="maroon")

pca <- prcomp(dat[,c(-1,-2,-3,-4)])
pca_dat <- mutate(fortify(pca), col=fit$cluster)

ggplot(pca_dat) +
  geom_point(aes(x=PC1, y=PC2, fill=factor(col)), size=3, col="#7f7f7f", shape=21) +
  scale_fill_viridis(name="Cluster", discrete=TRUE) + theme_bw(base_family="Helvetica")
  
# autoplot(fit, data=dat[,c(-1,-2,-3,-4)], frame=TRUE, frame.type='norm')




dat$cluster<-fit$cluster

# p<-plot_ly(dat,x=dat$RECENCY,y=dat$MONETARY,z=dat$FREQUENCY
#            ,type = "scatter3d",mode="markers",color = dat$cluster
#            )%>% layout(showlegend=FALSE)
# p
summary(subset(dat,cluster==1))
summary(subset(dat,cluster==2))
summary(subset(dat,cluster==3))
summary(subset(dat,cluster==4))
summary(subset(dat,cluster==5))
summary(subset(dat,cluster==6))

ggplot(data = dat, mapping = aes(x = TIPO, y = MONETARY)) +
  geom_boxplot()+
  facet_wrap(~cluster,nrow = 1)

###Extraer un cluster especifico
base.insertar<-data.frame("NRO_CUENTA"=(subset(dat,cluster == 5))$NRO_CUENTA
                          ,"MSISDN"=NA
                          ,"TIPO"=(subset(dat,cluster == 5))$TIPO
                          )

rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,:2,:3)", data=base.insertar)
dbCommit(con)
