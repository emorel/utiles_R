#debug(utils:::unpackPkgZip)
#install.packages("lattice")

library(dplyr)
library(ggplot2)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)
 
 # Load
 library("tm")
 library("SnowballC")
 library("wordcloud")
 library("RColorBrewer")
 library(magrittr)
 library(tidyverse)
 library(tibble)
 library(tidytext) 
 

#news <- read.csv('abcnews-date-text.csv', header = T, stringsAsFactors = F)

con <- dbConnect(Oracle(), user="expeam", password="!enero2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                        select to_char(l.fecha_transaccion,'yyyymmdd') as publish_date
                        ,l.comentario_de_la_transaccion as headline_text
                     from expeam.llamadas_mfs l
                     
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
news<-df_bkp
#str(news)
#news <- read.csv('abcnews-date-text.csv', header = T, stringsAsFactors = F)

news %>% group_by(PUBLISH_DATE) %>% count() %>% arrange(desc(n))

news %>% group_by(PUBLISH_DATE) %>% count() %>% ggplot() + geom_line(aes(PUBLISH_DATE,n, group = 1))

library(stringr)
news_more <- news %>% mutate(year = str_sub(PUBLISH_DATE,1,4),
                             month = str_sub(PUBLISH_DATE,5,6),
                             date = str_sub(PUBLISH_DATE,7,8))

news_more %>% group_by(month) %>% count()  %>% ggplot() + geom_bar(aes(month,n), stat ='identity')

library(udpipe)
#model <- udpipe_download_model(language = "english")
u <- udpipe_download_model(language = "spanish")
#udmodel_english <- udpipe_download_model(language = "english")
udmodel_spanish <- udpipe_load_model(u$file_model)


news_more_2008 <- news_more %>% filter(year == 2018 & month == 12)


s <- udpipe_annotate(udmodel_spanish,news_more_2008$HEADLINE_TEXT)
#s <- udpipe_annotate(udmodel_spanish,news_more_2008)
x <- data.frame(s)

#x <- document_term_frequencies(x)
#x <- document_term_matrix(x)

#x <- dtm_remove_terms(x, terms = c("CLIENTE", "VERIFICA","LINEA","MTS","TIGO","WSVALIDACION","BILLETERA","ASESORA","USSD","CORRECTAMENTE","ASESOR","MONEY","INDICA","�???�","�???�","SUSCRIPTOR","GUARANIES","LUEGO","CONFIRMA"))
#library(stringr)
x<-x %>% filter(!str_detect(token, c("GS","PERO","CASO","NO","QUE","SE","CLIENTE", "VERIFICA","LINEA","MTS","TIGO","WSVALIDACION","BILLETERA","ASESORA","USSD","CORRECTAMENTE","ASESOR","MONEY","INDICA","�???�","�???�","SUSCRIPTOR","GUARANIES","LUEGO","CONFIRMA")))
x<-subset(x,!(token %in% c("*555#","GS","PERO","CASO","NO","QUE","SE","CLIENTE", "VERIFICA","LINEA","MTS","TIGO","WSVALIDACION","BILLETERA","ASESORA","USSD","CORRECTAMENTE","ASESOR","MONEY","INDICA","�???�","�???�","SUSCRIPTOR","GUARANIES","LUEGO","CONFIRMA")))

library(lattice)
stats <- txt_freq(x$upos)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = stats, col = "yellow", 
         main = "UPOS (Universal Parts of Speech)\n frequency of occurrence", 
         xlab = "Freq")
## NOUNS
stats <- subset(x, upos %in% c("NOUN")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "cadetblue", 
         main = "Most occurring nouns", xlab = "Freq")

## ADJECTIVES
stats <- subset(x, upos %in% c("ADJ")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "purple", 
         main = "Most occurring adjectives", xlab = "Freq")

## NOUNS
stats <- subset(x, upos %in% c("VERB")) 
stats <- txt_freq(stats$token)
stats$key <- factor(stats$key, levels = rev(stats$key))
barchart(key ~ freq, data = head(stats, 20), col = "gold", 
         main = "Most occurring Verbs", xlab = "Freq")

## Using RAKE
stats <- keywords_rake(x = x, term = "lemma", group = "doc_id", 
                       relevant = x$upos %in% c("NOUN", "ADJ"))
stats$key <- factor(stats$keyword, levels = rev(stats$keyword))
barchart(key ~ rake, data = head(subset(stats, freq > 3), 20), col = "red", 
         main = "Keywords identified by RAKE", 
         xlab = "Rake")


## Using a sequence of POS tags (noun phrases / verb phrases)
x$phrase_tag <- as_phrasemachine(x$upos, type = "upos")
stats <- keywords_phrases(x = x$phrase_tag, term = tolower(x$token), 
                          pattern = "(A|N)*N(P+D*(A|N)*N)*", 
                          is_regex = TRUE, detailed = FALSE)
stats <- subset(stats, ngram > 1 & freq > 3)
stats$key <- factor(stats$keyword, levels = rev(stats$keyword))
barchart(key ~ freq, data = head(stats, 20), col = "magenta", 
         main = "Keywords - simple noun phrases", xlab = "Frequency")

