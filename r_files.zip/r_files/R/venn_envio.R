

#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!diciembre2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
    SELECT distinct b.document_number as NRO_CUENTA
    from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-11-20' and date'2018-12-10'
                     and b.service_id in (46,402)
                                     
                     
                     ")
base1 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
    SELECT distinct b.document_number as NRO_CUENTA
    from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-01-01' and date'2018-11-19'
                     and b.service_id in (4,401)
                     
                     
                     ")
base2 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
    SELECT distinct b.document_number as NRO_CUENTA
    from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-01-01' and date'2018-11-19'
                     and b.service_id in (36)
                     
                     ")
base3 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
     SELECT distinct b.document_number as NRO_CUENTA
    from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-01-01' and date'2018-11-19'
                     and b.service_id in (46,402)
                     
                     ")
base4 <- fetch(query)
toc()

tic()
query <- dbSendQuery(con,"
                     
    SELECT distinct b.document_number as NRO_CUENTA
    from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-01-01' and date'2018-11-19'
                     and b.service_id =1
                     
                     ")
base5 <- fetch(query)
toc()


tic()
query <- dbSendQuery(con,"
                     
                     
    SELECT distinct b.document_number as NRO_CUENTA
                     from tigo_cash_rpt.base_cliente_mfs_daily_ci b
                     where b.fecha_datos between date'2018-11-20'-60 and date'2018-12-31'-60
                     and b.service_id in (46,402)
                     ")
base6 <- fetch(query)
toc()


#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$NRO_CUENTA
base2<-base2$NRO_CUENTA
base3<-base3$NRO_CUENTA
base4<-base4$NRO_CUENTA
base5<-base5$NRO_CUENTA
base6<-base6$NRO_CUENTA

#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  #x = list(wallet_l,smart_l,shop_l,tm_app_l),
  x = list(base1,base2,base3,base5),
  #category.names = c("WALLET","SMART","SHOP_APP","TM_APP"),
  category.names = c("Envio 3Sem","P2P 2018","Giros 2018","Carga 2018"),
  filename = 'C:/Users/expeam/Documents/segment/2018/11-noviembre/analisis_envio/venn/venn_diagramm_envio_p2p_giros_carga.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple','green','red'),
  cex = 0.3,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.3,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27),
  #cat.dist = c(0.05, 0.05),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 

