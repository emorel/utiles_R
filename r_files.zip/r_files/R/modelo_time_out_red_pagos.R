
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)
library(readxl)
library(DescTools)
library(metafor)

library("PerformanceAnalytics")

red_pagos_modelo <- read_excel("red_pagos_modelo_mensual_tgpg_mbc_conf.xlsx")

red_pagos_modelo <- read_excel("modelo_cross.xlsx")

df<-red_pagos_modelo[-c(5)]
df<-na.omit(df)

df<-red_pagos_modelo


plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)



df$TRX<-log(df$TRX)
df$MONTO<-log(df$MONTO)
df$CLIENTE<-log(df$CLIENTE)
df$TPS<-log(df$TPS)

##correr tres veces minimo

outlierKD(df, vendidas)
yes
df<-na.omit(df)

outlierKD(df, activas)
yes
df<-na.omit(df)

#######
outlierKD(df, MONTO)
yes
df<-na.omit(df)

outlierKD(df, CANT_CLIENTES)
yes
df<-na.omit(df)
##########
## MODELO
##########


telecomModel <- lm(MONTO ~ . ,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100

telecomModel <- lm(TRX ~ EVENTO ,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100

telecomModel <- lm(MONTO ~ EVENTO ,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100

telecomModel <- lm(CLIENTE ~ EVENTO ,data=df)
print(summary(telecomModel))
(1-MAPE(telecomModel))*100

#df<-df_backup[-c(1,3,7)]

(1-MAE(telecomModel))*100
(1-MAPE(telecomModel))*100 ##only with positives data
(1-MSE(telecomModel))*100
(1-RMSE(telecomModel))*100

as.formula(
  paste0("y ~ ", round(coefficients(telecomModel)[1],5), "", 
         paste(sprintf(" %+.5f*%s ", 
                       coefficients(telecomModel)[-1],  
                       names(coefficients(telecomModel)[-1])), 
               collapse="")
  )
)

