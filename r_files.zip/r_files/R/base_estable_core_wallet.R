library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")


###############################
###Regularidad por servicio####
###############################

FINMES = c(
  
  "2017-01-01","2017-02-01","2017-03-01","2017-04-01"
  ,"2017-05-01","2017-06-01","2017-07-01","2017-08-01"
  ,"2017-09-01","2017-10-01","2017-11-01","2017-12-01"
  ,"2018-01-01","2018-02-01","2018-03-01","2018-04-01"
  ,"2018-05-01","2018-06-01","2018-07-01","2018-08-01"
  ,"2018-09-01"
)
##########################
##se toma el primer mes##
##########################
c<-data.frame(FINMES[1],FINMES[1])
print(c)
tic()
query <- dbSendQuery(con,"
                       
                     
                     select distinct bm.nro_cuenta
                     from tigo_cash_rpt.base_cliente_mfs_daily bm
                     where bm.fecha_datos between last_day(to_date(:1,'YYYY-MM-DD')) -60 and last_day(to_date(:2,'YYYY-MM-DD'))-1-- cambio
                      and bm.service_id not IN (3,502,515,521,522,524,525,525) -- NO SELF TOP UP
                     AND
                     (
                     (
                     bm.tipo IN ('from MENU','from APP','from CARD','from POS','from ATM')
                     )
                     OR
                     (
                     bm.service_id IN (1,2,98)
                     )
                     OR
                     (
                     bm.servicio = 'Giros Nacionales Receptores'
                     )
                     )                     
                     
                     ", data=c)
df_bkp <- fetch(query)
df<-df_bkp
toc()
##################################
##se toman los meses siguientes##
#################################

for (c in FINMES[-c(1)]) {
  d<-data.frame(c,c)
  print(c)
  tic()
  query <- dbSendQuery(con,"
                       
                       
                     select distinct bm.nro_cuenta
                     from tigo_cash_rpt.base_cliente_mfs_daily bm
                       where bm.fecha_datos between last_day(to_date(:1,'YYYY-MM-DD')) -60 and last_day(to_date(:2,'YYYY-MM-DD'))-1-- cambio
                        and bm.service_id not IN (3,502,515,521,522,524,525,525) -- NO SELF TOP UP
                       AND
                       (
                       (
                       bm.tipo IN ('from MENU','from APP','from CARD','from POS','from ATM')
                       )
                       OR
                       (
                       bm.service_id IN (1,2,98)
                       )
                       OR
                       (
                       bm.servicio = 'Giros Nacionales Receptores'
                       )
                       )
                       
                       
                       
                       ", data=d)
  df_bkp <- fetch(query)
  df1<-df_bkp
  
  
  df<-merge(x = df, y = df1, by = "NRO_CUENTA")

  toc()
}

str(df)

minsert<-df

rs <- dbSendQuery(con, "truncate table expeam.BASE_ESTABLE_CW_NSTU_17_18", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.BASE_ESTABLE_CW_NSTU_17_18 values(:1)", data=minsert)

dbCommit(con)
