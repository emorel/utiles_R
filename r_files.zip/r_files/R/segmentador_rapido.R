con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     select distinct p.nro_cuenta as document_number
                    ,to_char(p.fecha_datos,'YYYYMM') as fecha_datos
                     ,sum(p.monto) as monto
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2017-01-01' and date'2018-05-31'
                     AND p.categoria in ('Cash In','Receptores')
                     group by  p.nro_cuenta
                     ,to_char(p.fecha_datos,'YYYYMM')
                     
                     
                     ")
dfa1 <- fetch(query)
toc()
base_arpu_linea<-dfa1

xs=quantile(base_arpu_linea$REVENUE,c(0,1/5,2/5,3/5,4/5,1))
xs[1]=xs[1]-.00005
base_arpu_linea <- base_arpu_linea %>% mutate(REVENUE_f=cut(base_arpu_linea$REVENUE, breaks=xs, labels=c("1.~very~low","2.~low","3.~middle","4.~high","5.~very high")))
boxplot(base_arpu_linea$REVENUE~base_arpu_linea$REVENUE_f,col=3:5)

write.table(base_arpu_linea,file = "base_arpu_ci.csv",sep = ";",row.names = FALSE)
