
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
 


        select 

        p.ar_key as document_number
        ,count(*) as monto
        ,p.fct_dt
        from EXPEAM.base_finan_7_10 p
        where p.ar_key in
        (
          select ar_key from
          
          (
          select 
          p.AR_KEY,p.FCT_DT
          from EXPEAM.base_finan_7_10 p
          where p.fct_dt between date'2018-01-01' and last_day(date'2018-05-01')
          and p.fnncl_pd_sub_tp_nm in ('TIGOSHOP Paquetigo','TIGOSHOPAPP Paquetigo')
          and upper(p.FNNCL_PD_NM) like '%MB%10000%'
          intersect
          select 
          p.AR_KEY,p.FCT_DT
          from EXPEAM.base_finan_7_10 p
          where p.fct_dt between date'2018-01-01' and last_day(date'2018-05-01')
          and p.fnncl_pd_sub_tp_nm in ('Tigo Money','Tigo Money Recarga a Terceros')
          and p.fnncl_pd_altrntv_nm in ('SelfTopUp(TigoCash)','TIGO_CASH')
          and p.fnncl_trnsctn_val >= 10000
          )
        )
group by p.ar_key,p.fct_dt


                     ")
t <- fetch(query)
toc()
summary(t)
  
  tiff('C:/Users/expeam/Documents/segment/2018/junio/oferta_prepago/paquetigo_prepago_mfs_histograma_2018_10000.tiff', width = 35, height = 25, units = 'in', res = 200)
  bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34)
  ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
    ggtitle("FREQ PAQUETIGOS ADQUIRIDOS LUEGO DE UNA MINICARGA DESDE TIGO MONEY POR MES (10000)(2018)")+
    geom_histogram(breaks=bins,position="identity")+
    scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
    scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
    theme(axis.text.x = element_text(angle = 45,size = 20)
          ,axis.text.y = element_text(size = 20)
          ,axis.title.x = element_text(size = 20)
          ,axis.title.y = element_text(size = 20)
          ,title = element_text(size = 40)
          )+
    ylab(label="PORCENTAJE")+
    xlab(label="FREQ")
  dev.off()

bins <- c(0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000,15000,16000,17000,18000,19000,20000,21000,22000,23000,24000,25000,26000,27000,28000,29000,30000)
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45))+
  ylab(label="PORCENTAJE")+
  xlab(label="MONTO_CARGA")




bins <- c(0,10,20,30,40,50,60,70,80,90,100)
ggplot(t,aes(x=EDAD,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="EDAD")

bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)
ggplot(t,aes(x=ANTIGUEDAD_CLIENTE,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  ylab(label="PORCENTAJE")+
  xlab(label="ANTIGUEDAD_CLIENTE")


ggplot(t, aes(x=MONTO)) +
  theme_bw() +
  scale_x_continuous(breaks = pretty(t$MONTO/1000, n = 10)) +
  geom_histogram(alpha=0.6, binwidth=50) +
  ggtitle("Distribucion por TOTAL_CARGA")+
  theme(axis.text.x = element_text(angle=45))


basedate <- as.POSIXct(t$DIA,origin ="1582-10-14", tz = "GMT")
#tiff('C:/Users/edgar/Documents/analisis_envio/comparativo_var_envio_abandono_1.tiff', width = 35, height = 15, units = 'in', res = 300)
ggplot(t, aes(x=DIA,y=DATA )) +
  ggtitle("CORE Vs Envio")+
  geom_line()	+	
  scale_x_datetime(minor_breaks = basedate,breaks=pretty_breaks(n=30)) +
  facet_wrap(~TYPE+BASE, scales = 'free_y', ncol = 2)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=1)+geom_point(size=1/9)+theme(text = element_text(size=10),plot.title = element_text(hjust = 0.5))
#dev.off()