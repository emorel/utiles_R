debug(utils:::unpackPkgZip)
remotes::install_github("erblast/oetteR")

debug(utils:::unpackPkgZip)
install.packages("pipelearner")

debug(utils:::unpackPkgZip)
devtools::install_github("drsimonj/pipelearner")


suppressPackageStartupMessages( require(scorecard) )
suppressPackageStartupMessages( require(tidyverse) )
suppressPackageStartupMessages( require(oetteR) )

data('germancredit')

data = germancredit %>%
  as_tibble()

#replace '.' in variable names not compatible with f_train_lasso
vars = names(data) %>%
  str_replace_all( '\\.', '_')

names(data) <- vars

# convert response factor variable to dummy variable

data = data %>%
  mutate( creditability = ifelse( creditability == 'bad', 1, 0 )
          , creditability = as.factor(creditability) )

summary(data)