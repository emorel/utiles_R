#debug(utils:::unpackPkgZip)
#install.packages("splitstackshape")
#Sys.getenv(c("R_MAX_NUM_DLL"))
#Sys.setenv("R_MAX_NUM_DLL"=1000)

library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)


##### OUTLIERS ######


## FUNCION ELIMINAR OUTLIERS
outlierKD <- function(dt, var) {
  var_name <- eval(substitute(var),eval(dt))
  na1 <- sum(is.na(var_name))
  m1 <- mean(var_name, na.rm = T)
  par(mfrow=c(2, 2), oma=c(0,0,3,0))
  #boxplot(var_name, main="With outliers")
  #hist(var_name, main="With outliers", xlab=NA, ylab=NA)
  outlier <- boxplot.stats(var_name)$out
  mo <- mean(outlier)
  var_name <- ifelse(var_name %in% outlier, NA, var_name)
  #boxplot(var_name, main="Without outliers")
  #hist(var_name, main="Without outliers", xlab=NA, ylab=NA)
  #title("Outlier Check", outer=TRUE)
  na2 <- sum(is.na(var_name))
  cat("Outliers identified:", na2 - na1, "n")
  cat("Propotion (%) of outliers:", round((na2 - na1) / sum(!is.na(var_name))*100, 1), "n")
  cat("Mean of the outliers:", round(mo, 2), "n")
  m2 <- mean(var_name, na.rm = T)
  cat("Mean without removing outliers:", round(m1, 2), "n")
  cat("Mean if we remove outliers:", round(m2, 2), "n")
  #response <- readline(prompt="Do you want to remove outliers and to replace with NA? [yes/no]: ")
  #if(response == "y" | response == "yes"){
  dt[as.character(substitute(var))] <- invisible(var_name)
  assign(as.character(as.list(match.call())$dt), dt, envir = .GlobalEnv)
  cat("Outliers successfully removed", "n")
  return(invisible(dt))
  #} else{
  #     cat("Nothing changed", "n")
  #     return(invisible(var_name))
  #}
}


############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
select 
--t.ciudad
                     --t.id_pdv
                     t.circuito
                     ,t.zona
                     ,t.nombre_dealer 
                     ,t.mes
                     ,count(distinct t.id_pdv) as cant_pdv
                     --, count(distinct t.id_pdv ) over (partition by t.circuito) as cant_pdv
                     ,sum(t.horas_sin_saldo2) as hs_sin_saldo
                     ,sum(t.horas_sin_saldo2)/count(distinct t.id_pdv) as hs_sin_saldo_pdv
                     ,sum(p.cant_clientes)/count(distinct t.id_pdv) as cant_clientes_pdv
                     ,sum(t.horas_sin_saldo2)/(13*31*count(distinct t.id_pdv)) as quiebre
                     ,sum(t.ventas)/count(distinct t.id_pdv) as Ventas_pdv
                     ,sum(t.cant_veces_sin_saldo) as cant_veces_sin_saldo
                     ,sum(p.cant_clientes) as cant_clientes
                     from expeam.v_boc_epin_indirecta t
                     left join expeam.clientes_pdv_2018 p on t.id_pdv = p.id_pdv and t.mes = p.mes
                     --where t.mes in (201801,201802,201803,201804,201805,201806,201807,201808,201809,201810,201811,201812)
                     --where t.mes in (201810,201811,201812)
                     where t.mes in (201812)
                     --and t.ciudad = '14 DE MAYO'
                     group by
                     --t.id_pdv
                     t.circuito
                     --t.ciudad
                     ,t.zona
                     ,t.nombre_dealer
                     ,t.mes
                     order by t.nombre_dealer
                     ,t.zona
                     --,t.id_pdv
                    
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
#my_data <- df
str(df)
dbDisconnect(con)

#my_data<-select(df,CIRCUITO,ZONA,NOMBRE_DEALER,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO,QUIEBRE,VENTAS)
my_data<-select(df,CIRCUITO,ZONA,NOMBRE_DEALER,CANT_PDV,CANT_CLIENTES_PDV,HS_SIN_SALDO_PDV,QUIEBRE,VENTAS_PDV)

### OUTLIERS
outlierKD(my_data, CANT_PDV)
outlierKD(my_data, CANT_CLIENTES_PDV)
outlierKD(my_data, HS_SIN_SALDO_PDV)
outlierKD(my_data, QUIEBRE)
outlierKD(my_data, VENTAS_PDV)
my_data<-na.omit(my_data)

##NORMALIZACION
my_data$CANT_PDV <- sqrt(my_data$CANT_PDV)
my_data$CANT_CLIENTES <- sqrt(my_data$CANT_CLIENTES)
my_data$HS_SIN_SALDO <- sqrt(my_data$HS_SIN_SALDO)
my_data$QUIEBRE <- sqrt(my_data$QUIEBRE)
my_data$VENTAS <- sqrt(my_data$VENTAS)
my_data<-na.omit(my_data)



plot(df$VENTAS,df$CANT_PDV)
plot(df$VENTAS,df$CANT_CLIENTES)
plot(df$VENTAS,df$HS_SIN_SALDO)
plot(df$VENTAS,df$QUIEBRE)

chart.Correlation(my_data[,-c(1,2,3)], histogram=TRUE, pch=19)

############
####TOTAL###
############
data<-my_data
telecomModel <- lm(VENTAS_PDV ~ CANT_CLIENTES_PDV+HS_SIN_SALDO_PDV ,data=data)
coefficients(telecomModel)
summary(telecomModel)
par(mfrow=c(2,2))
plot(telecomModel)
#VIF(telecomModel)

## generamos las formulas por segmento
######################
##### POR CIRCUITO####
######################
#str(my_data)
data<-my_data

df_coef<-data.frame(CIRCUITO="CIRCUITO",ZONA="ZONA",NOMBRE_DEALER="NOMBRE_DEALER"
                    ,INTERCEPT=as.numeric(coefficients(telecomModel)[1]),CANT_PDV=as.numeric(coefficients(telecomModel)[2])
                    ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[3]),HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
                    ,QUIEBRE=as.numeric(coefficients(telecomModel)[5]) )

df_coef$CIRCUITO<-as.character(df_coef$CIRCUITO)
df_coef$ZONA<-as.character(df_coef$ZONA)
df_coef$NOMBRE_DEALER<-as.character(df_coef$NOMBRE_DEALER)

df_coef<-df_coef[-c(1),]


#str(df_coef)

for (i in sort(unique(my_data$CIRCUITO))) {
  data<-subset(my_data,CIRCUITO ==i)
  #print(head(data))
  #print(i)
  telecomModel <- lm(VENTAS ~ CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO+QUIEBRE ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_por_circuito/residuals_ventas_quiebre_circuito_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  #print(i)
  #print(coefficients(telecomModel))
  CIRCUITO<-as.character(data[1,1])
  ZONA=as.character(data[1,2])
  NOMBRE_DEALER=as.character(data[1,3])
  New<-data.frame(CIRCUITO=CIRCUITO,ZONA=ZONA,NOMBRE_DEALER=NOMBRE_DEALER
                  ,INTERCEPT=as.numeric(coefficients(telecomModel)[1]),CANT_PDV=as.numeric(coefficients(telecomModel)[2])
                  ,CANT_CLIENTES=as.numeric(coefficients(telecomModel)[3]),HS_SIN_SALDO=as.numeric(coefficients(telecomModel)[4])
                  ,QUIEBRE=as.numeric(coefficients(telecomModel)[5]) )
  
  
  df_coef<-rbind(df_coef,New)
  
  #print(coefficients(telecomModel))
}




df_coef_totales<-merge(df_coef,my_data,by="CIRCUITO",all.x=TRUE,no.dups = FALSE)

dbWriteTable(con,"TMP_QUIEBRE_COEF_CIRCUITO", df_coef_totales, rownames=FALSE, overwrite = TRUE, append = FALSE)

