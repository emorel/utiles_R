#debug(utils:::unpackPkgZip)
#install.packages('Rmpi')


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!noviembre2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     

                      select *
                     from expeam.tmp_base_mfs_retiro18 t
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-10-01")
dfk<-dfCBS

dfksc<-scale(dfCBS[-c(1,6,8)])

k.clust<-15

fit <- kmeans(dfksc, k.clust, iter.max=3000,algorithm = "Lloyd")



dfk$cluster<-as.factor(fit$cluster)
dfkl<-merge(x = df, y = dfk[c(1,11)], by = "cust", all.x = TRUE)


## Timing Patterns
# op <- par(mfrow = c(3, 4))
# p1<-plotTimingPatterns(subset(dfkl, cluster==1), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p2<-plotTimingPatterns(subset(dfkl, cluster==2), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p3<-plotTimingPatterns(subset(dfkl, cluster==3), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p4<-plotTimingPatterns(subset(dfkl, cluster==4), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p5<-plotTimingPatterns(subset(dfkl, cluster==5), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p6<-plotTimingPatterns(subset(dfkl, cluster==6), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p7<-plotTimingPatterns(subset(dfkl, cluster==7), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p8<-plotTimingPatterns(subset(dfkl, cluster==8), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p9<-plotTimingPatterns(subset(dfkl, cluster==9), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p10<-plotTimingPatterns(subset(dfkl, cluster==10), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p11<-plotTimingPatterns(subset(dfkl, cluster==11), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")
# p12<-plotTimingPatterns(subset(dfkl, cluster==12), n = 150, T.cal = "2018-08-01",headers = c("Past", "Future"), title = "")


#par(op)

###  BOX Plot Parametros
# 
# p1<-ggplot(data = dfk, mapping = aes(x = cluster, y = sales)) +
#   geom_boxplot()
# p2<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
#   geom_boxplot()
# p3<-ggplot(data = dfk, mapping = aes(x = cluster, y = x)) +
#   geom_boxplot()
# p4<-ggplot(data = dfk, mapping = aes(x = cluster, y = t.x)) +
#   geom_boxplot()
# 
# grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)


## Regularity
# op <- par(mfrow = c(3, 4))
# (k.wheat[1] <- estimateRegularity(subset(dfkl, cluster==1), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[2] <- estimateRegularity(subset(dfkl, cluster==2), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[3] <- estimateRegularity(subset(dfkl, cluster==3), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[4] <- estimateRegularity(subset(dfkl, cluster==4), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[5] <- estimateRegularity(subset(dfkl, cluster==5), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[6] <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[7] <- estimateRegularity(subset(dfkl, cluster==7), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[8] <- estimateRegularity(subset(dfkl, cluster==8), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[9] <- estimateRegularity(subset(dfkl, cluster==9), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[10] <- estimateRegularity(subset(dfkl, cluster==10), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[11] <- estimateRegularity(subset(dfkl, cluster==11), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
# (k.wheat[12] <- estimateRegularity(subset(dfkl, cluster==12), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))

k.wheat<-0
for (i in 1:k.clust) {
  k.wheat[i]<-0
}



for (i in 1:k.clust) {
  tryCatch(
    k.wheat[i]<-estimateRegularity(subset(dfkl, cluster==i), method = "wheat",plot = FALSE, title = "Wheat & Morrison"), error=function(e) 
      k.wheat[i]<-0
  )
}
k.wheat[is.na(k.wheat)]<-0

###cada cuantos dias transaccionan
# trx.w<-0
# 
# trx.w[1]<-(nbd.EstimateParameters(subset(dfk,cluster==1))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==1))[1])
# 
# trx.w[2]<-(nbd.EstimateParameters(subset(dfk,cluster==2))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==2))[1])
# 
# trx.w[3]<-(nbd.EstimateParameters(subset(dfk,cluster==3))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==3))[1])
# 
# trx.w[4]<-(nbd.EstimateParameters(subset(dfk,cluster==4))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==4))[1])
# 
# trx.w[5]<-(nbd.EstimateParameters(subset(dfk,cluster==5))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==5))[1])
# 
# trx.w[6]<-(nbd.EstimateParameters(subset(dfk,cluster==6))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==6))[1])
# 
# trx.w[7]<-(nbd.EstimateParameters(subset(dfk,cluster==7))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==7))[1])
# 
# trx.w[8]<-(nbd.EstimateParameters(subset(dfk,cluster==8))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==8))[1])
# 
# trx.w[9]<-(nbd.EstimateParameters(subset(dfk,cluster==9))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==9))[1])
# 
# trx.w[10]<-(nbd.EstimateParameters(subset(dfk,cluster==10))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==10))[1])
# 
# trx.w[11]<-(nbd.EstimateParameters(subset(dfk,cluster==11))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==11))[1])
# 
# trx.w[12]<-(nbd.EstimateParameters(subset(dfk,cluster==12))[2]/
#     nbd.EstimateParameters(subset(dfk,cluster==12))[1])
# 
# mean(trx.w)
# 


##Generamos un vector con los mejores clusters
cluster<-unique(fit$cluster)
clust<-NULL
for (i in 1:k.clust) {
  if (k.wheat[i] >=mean(k.wheat)) {
    clust<-c(clust,i)
  }
}

table(fit$cluster)
#clust<-c(3,5,6,11)
dfinsert<-subset(dfk[,c("cust","cluster")],cluster %in% clust)

rs <- dbSendQuery(con, "truncate table expeam.base_para_bulk", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.base_para_bulk values(:1,:2)", data=dfinsert)

dbCommit(con)

##################################
###INSERTAMOS   CUST,LITT #######
#################################

dfinsert<-dfCBS[,c("cust","litt")]

rs <- dbSendQuery(con, "truncate table expeam.TMP_PAQ_REG", data=dfinsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.TMP_PAQ_REG values(:1,:2)", data=dfinsert)

dbCommit(con)



