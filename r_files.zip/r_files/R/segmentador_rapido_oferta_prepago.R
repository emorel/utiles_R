con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     

                      select 
                      count(*) as monto
                     ,p.ar_key as document_number
                     ,to_char(p.fct_dt,'YYYYMM') as fecha_datos
                     from EXPEAM.base_finan_7_10 p
                     where p.ar_key in
                     (
                     select ar_key from
                     
                     (
                     select 
                     p.AR_KEY,p.FCT_DT
                     from EXPEAM.base_finan_7_10 p
                     where p.fct_dt between date'2018-01-01' and last_day(date'2018-01-01')
                     and p.fnncl_pd_sub_tp_nm in ('TIGOSHOP Paquetigo','TIGOSHOPAPP Paquetigo')
                     and upper(p.FNNCL_PD_NM) like '%MB%10000%'
                     intersect
                     select 
                     p.AR_KEY,p.FCT_DT
                     from EXPEAM.base_finan_7_10 p
                     where p.fct_dt between date'2018-01-01' and last_day(date'2018-01-01')
                     and p.fnncl_pd_sub_tp_nm in ('Tigo Money','Tigo Money Recarga a Terceros')
                     and p.fnncl_pd_altrntv_nm in ('SelfTopUp(TigoCash)','TIGO_CASH')
                     and p.fnncl_trnsctn_val >= 10000
                     )
                     )
                     group by 
                     p.ar_key
                     ,p.fct_dt
                     
                     
                     ")
dfa1 <- fetch(query)
toc()
base_arpu_linea<-dfa1

#base_arpu_linea$cut<-round(cut(base_arpu_linea$MONTO,breaks = 10),0)

xs=quantile(base_arpu_linea$MONTO,c(0,1/4,2/4,3/4,1))
xs[1]=xs[1]-.00005
base_arpu_linea <- base_arpu_linea %>% mutate(MONTO_f=cut(base_arpu_linea$MONTO, breaks=xs, labels=c("10000.1~2.","10000.2~3.","10000.3~4.","10000.4+.")))
boxplot(base_arpu_linea$MONTO~base_arpu_linea$MONTO_f,col=3:5)

dfinsert<-base_arpu_linea
#rs <- dbSendQuery(con, "truncate table expeam.TMP_BASE_PQ_7000 ")

#dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.TMP_BASE_PQ_7000 values(:1,:2,:3,:4)", data=dfinsert)

dbCommit(con)


