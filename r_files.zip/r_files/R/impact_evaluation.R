# Exacaster, 2016-06, based on methodology v0.4
#
# This R script aims to replicate general idea behind Digital Impact Analysis. 
# We will skip data preparation step and supply test data.
# Note that original analysis were performed using Python and sklearn.
#
# Project goal: Project aims to measure what impact product usage has on customer 
# behavior KPIs such as churn risk, ARPU etc.
# Challenge:there is no target and control groups to compare with/without product service, 
# because service is publicly available in the market. 
# Approach: The chosen methodology was to create control group AFTER the fact. Control group was 
# identified by searching customer base for users that are in all ways as similar to target as possible.
#
# Definitions:
# link_period - month during which account has started to use service. Denoted as 0.
# pre_link_period - months before link period that are used for training. Denoted as -1, -2, ...
# post_link_period - months after link period that are used to measure impact. Denoted as 1, 2, ...
# target_group - users who started to use service during link period and are not new customers (have 
# history during pre-link period).
# control_group - users who have not registered nor used given service during pre-link, link and post-link 
# periods, are not new (have history during pre-link period) and who are very similar to target group in 
# terms of given metric list and forced group label.
# forced_label - group label by which target and control groups have to be identical.

library(data.table)
library(FNN)    # Nearest Neighbours implementation used in modeling section
library(ggplot2)
setwd("C:\\Users\\tcljml\\Documents\\Paquete de Navidad 1GB")     # Change to directory which contains demo files

# Parameters
link_periods <- c('2018-11')  # Process enables to use multiple vintages
train_metrics_monthly <- c()#c('metric_1', 'metric_2', 'metric_3', 'metric_4', 'metric_5', 'metric_6', 'metric_7', 'metric_8')  # Metrics that will be used for training monthly for pre link period
train_metrics_period <- c('metric_1', 'metric_2', 'metric_3', 'metric_4', 'metric_5', 'metric_6', 'metric_7')   # Metrics that will be aggregated during pre link period and used for training
pre_link_period <- 3    # Number of months used in training
post_link_period <- 1   # Number of months used to measure impact

# PART 1. Data preparation

# All necessary data for our model is supplied using two files. We will use syntetic example below.
# File user_type should contain monthly user type definition and forced label for each link period:
# Format: user_type = (period, account_id, type, forced_label)
# Column type should contain only values target and potential to identify linked users and users that can be used as
# base to search for control group respectively. 
# We advise not to use a lot of forced labels. Experiments with 10-12 labels were stable, but using more can lead into
# small subgroups and unstable control group.

user_type <- fread('user_type_pre.tsv', dec = ',', sep='\t',
                   colClasses=c('character','character','character','character'))
colnames(user_type) <- c('period', 'account_id', 'type', 'forced_label')

# While preparing usage metrics keep in mind to exclude churned users. Later churn will be measured if user has a missing
# period. Also make sure that all users have data throughout pre link period. Metrics should be aggreggated monthly.
# Here you have an option to include only training metrics and add other analysis metrics after model creation (this might
# improve computation time) step or include them all.
# Keep in mind that nearest neighbours does not scale well, thus you might need to use random samples.
# Format: usage_metrics = (period, account_id, metric_1, metric_2, ...)

usage_metrics <- fread('usage_metrics_pre.tsv', dec = ',', sep='\t',
                       colClasses=c('character','character','numeric','numeric','numeric','numeric','numeric', 'numeric','numeric'))
colnames(usage_metrics) <- c('period', 'account_id', 'metric_1', 'metric_2', 'metric_3', 'metric_4', 'metric_5', 'metric_6', 'metric_7')

# PART 2. Model
# Training step will be executed for each link period and forced label pair sepperately.
# Model output: model_keys = (period, account_id, group)

groups <- user_type[, unique(forced_label)]
model_keys <- data.table()


for (dt in link_periods){   # run for each link period
  
  # Collect pre link period train dates for future filtering
  train_periods <- substr(seq(as.Date(paste(dt, "01", sep = '-')), 
                              length = pre_link_period, by = "-1 month"), 1, 7)
  print(train_periods)
  control_group <- c()
  for (group in groups){    # run each forced label group individually
      
    # Select target and potential accounts for the given period and forced label group
      target_users <- user_type[(period == dt) & (type == 'target') & 
                                  (forced_label == group), unique(account_id)]
      potential_users <- user_type[(period == dt) & (type == 'potential') & 
                                     (forced_label == group), unique(account_id)]
      
    # Make sure that target and potential groups are non empty and execute model
      if ((length(target_users) != 0) & (length(potential_users) != 0)){
        
        # From usage metrics select only data for training periods and necessary accounts
        data <- usage_metrics[(period %in% train_periods) & ((account_id %in% target_users) | (account_id %in% potential_users)), 
                      c("account_id", "period", train_metrics_monthly, train_metrics_period), with=FALSE]
        
        # Prepare monthly and aggregated by period matrics
        aggregated_data <- data[, c("account_id", train_metrics_period), with=FALSE][, lapply(.SD, sum), by = account_id]
        for (monthly_metric in train_metrics_monthly) {
          aggregated_data <- merge(aggregated_data, dcast(data, account_id ~ period, value.var = monthly_metric, 
                                                          fun.aggregate = sum), by = "account_id")
        }
        
        # Scale metrics. This step can be used to weight metrics by adding multipliers if necessary.
        scalecols <- colnames(aggregated_data)[-1]
        aggregated_data[, (scalecols):=lapply(.SD,scale), .SDcols=scalecols]
        
        # Use nearest neighbors and extract one congrol users for each target user from potential users base
        indexes <- get.knnx(aggregated_data[account_id %in% potential_users, -1, with = FALSE], 
                 aggregated_data[account_id %in% target_users, -1, with = FALSE], k = 1)$nn.index[,1]
        
        # Append results
        control_group <- c(control_group, aggregated_data[account_id %in% potential_users][indexes, unique(account_id)])
    
      }
  }
  
  # Leave only unique account ids for the given period
  control_group <- unique(control_group)
  target_group <- user_type[(period == dt) & (type == 'target'), unique(account_id)]
  
  # Append period results
  tmp_control <- data.table(period = dt, account_id = control_group, group = "control")
  tmp_target <- data.table(period = dt, account_id = target_group, group = "target")
  model_keys <- rbind(model_keys, tmp_target, tmp_control)

}

# Export 
write.table(model_keys, "model_keys_pre.csv", sep = ',', row.names = FALSE)

# Write to database
if(FALSE) {
  # Load libraries
  library(DBI)
  library(ROracle)
  
  # tns data can be read from file like this: tns = read.csv("panza_tns.csv")
  
  # Establish connection to the database
  con <- dbConnect(ROracle::Oracle(),
                   dbname = "PANZA", 
                   host = "replicator.telecel.net.py", 
                   port = 1521, 
                   user = "tcljml", 
                   password =.rs.askForPassword("Enter password:"))
  
  # Check if db connection works with: 
  dbReadTable(con, 'DUAL')
  
#  colnames(model_keys) <- c("period", "account_id", "group")
  dbWriteTable(con,"T_NAVIDAD_1GB__MODEL_KEYS_PRE", model_keys, rownames=FALSE, overwrite = TRUE, append = FALSE)
  
  dbDisconnect(con)
  remove(con)
}

if(FALSE) {
  
  con2 <- dbConnect(ROracle::Oracle(),
                    dbname = "DWH", 
                    host = "dwh4m.telecel.net.py", 
                    port = 1521, 
                    user = "tcljml", 
                    password =.rs.askForPassword("Enter password:"))
  
  # Check if db connection works with: 
  dbReadTable(con2, 'DUAL')
  
  #  colnames(model_keys) <- c("period", "account_id", "group")
  dbWriteTable(con2,"T_NAVIDAD_1GB__MODEL_KEYS_PRE", model_keys, rownames=FALSE, overwrite = TRUE, append = FALSE)
  
  dbDisconnect(con2)
  remove(con2)
}

# PART 3. Impact evaluation
# Following plots give a rough guidelines how to create plots using model keys. First we will join our data.

data <- merge(usage_metrics, model_keys, by = "account_id")
data[, month := as.numeric(round((as.Date(paste(period.x, "01", sep = '-')) - as.Date(paste(period.y, "01", sep = '-')))/30))]
data <- data[(month >= -pre_link_period) & (month <= post_link_period)]

# Churn
# As mentioned above usage_metrics should contain only unchurned users, thus calculating the number of users during each
# period should yeld total unchurned user count. This easily leads to cumulative churn plots. 

pivot <- data[, .N, by = .(group, month)]
pivot <- merge(pivot, pivot[month == 0, .(group, N)], by = "group")
pivot[, churn := 1 - N.x / N.y]
ggplot(pivot, aes(x = month, y = churn, group = group, color = group)) +
  geom_line() + geom_point() + xlab("Period") + ylab("Churn rate") + expand_limits(y=0)

# Monthly churn rate can easily obtained from previous result.

# Metric statistics
# While evaluating results we expect to see roughly the same value during pre link months. 

pivot <- data[, .(value = mean(metric_1)), by=.(month, group)]
ggplot(pivot, aes(x = month, y = value, group = group, color = group)) +
  geom_line() + geom_point() + xlab("Period") + ylab("Metric mean") + expand_limits(y=0)

