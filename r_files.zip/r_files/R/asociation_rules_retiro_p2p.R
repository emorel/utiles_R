library(ROracle)
library("arules")
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")



query <- dbSendQuery(con, "
                     
SELECT b.nro_cuenta,b.servicio
from tigo_cash_rpt.base_cliente_mfs_daily b
where b.fecha_datos between date'2017-12-01' and date'2017-12-31'
and b.nro_cuenta in
(
    SELECT b.nro_cuenta
    from tigo_cash_rpt.base_cliente_mfs_daily b
    where b.fecha_datos between date'2017-12-01' and date'2017-12-31'
    minus
    SELECT t.msisdn
    FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
    LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON (T.PK_CATEGORIA=C.PK_CATEGORIA)
    WHERE T.FECHA BETWEEN DATE'2017-12-01' AND DATE'2017-12-31'
    AND T.SERVICE_ID = 2
    AND T.RESULT = 0
    AND T.TYPE_AUX=1
    AND T.WALLET_TYPE_ID = 1
)
                     
                     ")
result <- fetch(query)
t <- result


i <- split(t$SERVICIO, t$NRO_CUENTA)
txn <- as(i, "transactions")

basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.002, conf = 0.06),appearance = list(rhs=c("Giros App","Envio App","Minicarga App"),default="lhs"))
basket_rules <- apriori(txn, parameter = list(maxlen=2,supp = 0.02, conf = 0.06),appearance = list(lhs=c("Carga de dinero"),rhs=c("Minicarga")))
basket_rules <- apriori(txn, parameter = list(minlen=2,supp = 0.001, conf = 0.8),appearance = list(rhs=c("REVENUE MUY BAJO"),lhs=c("LLUVIA TORRENCIAL"),default="none"))
itemFrequencyPlot(txn, topN = 40)
inspect(basket_rules)
basket_rules_broad <- apriori(txn, parameter = list(sup = 0.001, conf = 0.001, target="rules"))
inspect(head(basket_rules,n=20,by="lift"))



inspect(head(basket_rules,n=20,by="lift"))
