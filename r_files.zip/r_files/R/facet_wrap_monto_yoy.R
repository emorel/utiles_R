library(ROracle)
library(dplyr)
library(scales)
library(ggplot2)
library(reshape2)


con <- dbConnect(Oracle(), user="expeam", password="!enero2018", dbname="DWH/dwh_olap")


query <- dbSendQuery(con,"
                     

                 
                      SELECT sum(t.monto)/1000000 AS monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     /*,count(distinct t.transaction_id) as cant_trx
                     ,c.servicio*/
                     ,'4.- MONTO - RETIRO OTC (MMG)' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (2)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/

                     union all 

                     SELECT sum(t.monto)/1000000 AS monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     /*,count(distinct t.transaction_id) as cant_trx
                     ,c.servicio*/
                     ,'1.- MONTO - RETIRO ATM (MMG)' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (98)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/

                     union all

                     SELECT /*sum(t.monto) AS monto*/
                     count(distinct t.transaction_id) as monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     
                     /*,c.servicio*/
                     ,'5.- CANT_TRX - RETIRO OTC' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (2)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/

                     union all

                     SELECT /*sum(t.monto) AS monto*/
                     count(distinct t.transaction_id) as monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     
                     /*,c.servicio*/
                     ,'2.- CANT_TRX - RETIRO ATM' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (98)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/
                     
                     union all

                     SELECT sum(t.monto)/
                     count(distinct t.msisdn) as monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     
                     /*,c.servicio*/
                     ,'3.- TICKET POR CLIENTE - RETIRO ATM' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (98)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/

                     union all

                     SELECT sum(t.monto)/
                     count(distinct t.msisdn) as monto
                     ,TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD') as FECHA
                     
                     /*,c.servicio*/
                     ,'6.- TICKET POR CLIENTE - RETIRO OTC' as tipo
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c
                     ON (t.pk_categoria=c.pk_categoria)
                     /*join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
                     on (t.msisdn=tt.nro_cuenta)
                     left join expeam.funcionarios BF
                     on (t.msisdn= bf.nro_linea)*/
                     WHERE t.fecha BETWEEN DATE'2017-07-01' AND DATE'2018-01-31'
                     AND c.service_id in (2)
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(last_day(t.fecha), 'YYYY-MM-DD')
                     /*,c.servicio,
                     ,nvl2(bf.nro_linea,'COLABORADOR','CLIENTE')
                     ,c.servicio*/
                     

                     ")

df <- fetch(query)
df1<-df

df1$TIPO<-as.factor(df1$TIPO)
df1$FECHA<-as.Date(df1$FECHA,format = "%Y-%m-%d")

str(df1)

ggplot(df1,aes(x=FECHA,y=MONTO))+
  #geom_line(color="steelblue",size=2)+
  scale_x_date(breaks = pretty_breaks(n=10))+
  facet_wrap(~TIPO,scales="free_y",ncol=3,nrow=2)+
  theme(axis.text.x = element_text(angle = 45))+
  geom_smooth(span=0.3,method='loess',size=1.5)+
  geom_point(size=1,color="blue")+
  
theme(text=element_text(size=20))
#+  geom_label(aes(label=SEMANA),size=2)



