
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)
library(stats)
library(scales)
library(lsr)

con <- dbConnect(Oracle(), user="expeam", password="!agosto2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
select sum(b.monto_mov)/3 as monto
,b.msisdn
from tigo_cash_rpt.base_agente_mfs_daily b
join expeam.v_agent_idms_msisdn va
on (b.agent_id= va.AGENT_ID and b.msisdn = va.MSISDN)
where b.fecha between date'2018-05-01' and date'2018-07-31'
group by b.msisdn 
                     
                     ")
t <- fetch(query)
toc()
summary(t)

# 
# xs=quantile(t$MONTO,c(0/5,1/5,2/5,3/5,4/5,5/5))
# xs[1]=xs[1]-.00005
# t <- t %>% mutate(MONTO_f=cut(t$MONTO, breaks=xs, labels=c("A","B","C","D","E")))
# boxplot(t$MONTO~t$MONTO_f,col=3:5)
# summary(t)


options(scipen=999)
breaks<-100
t$SEGMENT <- cut( t$MONTO, breaks = breaks, dig.lab=10,ordered_result = TRUE)
t$SEGMENT_ORD <- cut( t$MONTO, breaks = breaks, dig.lab=10,ordered_result = TRUE,labels = 1:breaks)
summary(t)
str(t)
summary(t$SEGMENT)

#tiff('C:/Users/expeam/Documents/segment/2018/junio/analisis_semana_revenue/comparativo_selftopup_ticket_mayo2018_m.tiff', width = 45, height = 35, units = 'in', res = 300)
ggplot(t, aes(x=SEGMENT,y=MONTO)) +
  ggtitle("Segmentos de PTM")+
  geom_bar( aes(x=SEGMENT,y=MONTO),stat="identity")+
  #scale_x_date(breaks=pretty_breaks(n=30)) +
  scale_y_continuous(breaks=pretty_breaks(n=5)) +
  #facet_wrap(~CLUSTER, scales = 'fixed', ncol = 1)+
  theme(axis.text.x = element_text(angle=45))+
  #geom_smooth(span=0.5,alpha=0.1)+
  geom_point(size=1/9)+
  theme(text = element_text(size=8),plot.title = element_text(hjust = 0.5))
#geom_text(aes(label=TIPO_DIA,color="Feriados"),size=10)
#dev.off()




write.table(t,file = "C:/Users/expeam/Documents/segment/2018/agosto/segmentacion_ptm/base_ptm.csv",sep = ";",row.names = FALSE)
  