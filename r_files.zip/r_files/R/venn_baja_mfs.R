

#upload library
library(ROracle)
library(VennDiagram)
library(gplots)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
##ene-2018
tic()
query <- dbSendQuery(con,"
                     
                    select b.nro_cuenta
                    from expeam.mfs_base_baja b
                     
                     ")
base1 <- fetch(query)
toc()

##ene-2019
tic()
query <- dbSendQuery(con,"
                     
                     
                      select '0'||substr(ar.MSISDN_DD,-9,9) as AR_SSCRBR_DD
                      from smy.ar_monthly_base_fct ar
                     left join dtl.ar_adtnl_trckng_fct ad on (ar.AR_KEY = ad.AR_KEY)
                     where ar.FCT_DT in (date'2019-01-31',date'2019-02-28')
                     and ad.FCT_DT in (date'2019-01-31',date'2019-02-28')
                     and ar.PAYMENT = 'PRE'
                     and ad.ar_cmmrcl_st_key = 54
                     
                     ")
base2 <- fetch(query)
toc()
##ene-2019
tic()
query <- dbSendQuery(con,"
                     
                  select '0'||substr(ar.MSISDN_DD,-9,9) as AR_SSCRBR_DD
                  from smy.ar_monthly_base_fct ar
                     left join dtl.ar_adtnl_trckng_fct ad on (ar.AR_KEY = ad.AR_KEY)
                     where ar.FCT_DT in (date'2019-01-31',date'2019-02-28')
                     and ad.FCT_DT in (date'2019-01-31',date'2019-02-28')
                     and ar.PAYMENT = 'POS'
                     and ad.ar_cmmrcl_st_key = 54 
                     
                     ")
base3 <- fetch(query)
toc()


##TIGO_BILL_PAYS
tic()
query <- dbSendQuery(con,"
                     
                  select '0'||substr(ar.MSISDN_DD,-9,9) as AR_SSCRBR_DD
                  from smy.ar_monthly_base_fct ar
                  left join dtl.ar_adtnl_trckng_fct ad on (ar.AR_KEY = ad.AR_KEY)
                  where ar.FCT_DT = date'2019-02-28'
                  and ad.FCT_DT = date'2019-02-28'
                  and ar.PAYMENT = 'POS'
                  and ad.ar_cmmrcl_st_key = 54 
                     
                     ")
base4 <- fetch(query)
toc()



#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$NRO_CUENTA
#base1[is.na(base1)]<-"1"
base2<-base2$AR_SSCRBR_DD
#base2[is.na(base2)]<-"1"
base3<-base3$AR_SSCRBR_DD
#base3[is.na(base3)]<-"1"
base4<-base4$AR_KEY
#base4[is.na(base4)]<-"1"



#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base1,base2,base3),
  category.names = c("MFS","PRE","POS"),
  filename = 'C:/Users/expeam/Documents/BI/2019/03-marzo/mfs_baja_clientes/venn_diagramm_mfs_baja_pre_pos.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow','purple','green'),
  cex = 0.5,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.5,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 
