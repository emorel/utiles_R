library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
SELECT t.msisdn
,TO_CHAR(t.fecha, 'YYYY-MM-DD') as FECHA_datos
                     ,sum(t.monto) as monto
                     from tigo_cash_rpt.base_mfs_det_trx t
                     JOIN tigo_cash_rpt.base_mfs_categoria c ON (t.pk_categoria=c.pk_categoria)
                     /*join 
                     (
                     select  x.nro_cuenta
                     from rpt_vas.cuenta_tac_cdr x
                     left join dtl.dvc_dim y
                     on (x.tac = y.dvc_tac_cd)
                     where x.fecha = trunc(sysdate-1,'mm')-1
                     and y.OS_NM = 'Android'
                     and lower(y.DVC_TP_NM) like '%smartphone%'
                     
                     ) sm
                     on (t.msisdn = sm.nro_cuenta)*/
                     WHERE t.fecha BETWEEN DATE'2017-01-01' AND DATE'2018-02-28'
                     and t.msisdn /*not*/ in (select f.msisdn from expeam.base_app_ene_feb18 f )
                     AND c.service_id = 4
                     AND t.result = 0
                     AND t.type_aux = 1
                     GROUP BY TO_CHAR(t.fecha, 'YYYY-MM-DD')
                     ,t.msisdn
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
groceryElog<-df

length(unique(groceryElog$MSISDN))
groceryElog$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
set.seed(123)
colnames(groceryElog) <- c("cust","date","sales")
str(groceryElog)
length(unique(groceryElog$cust))

plotTimingPatterns(subset(groceryElog,cust=='0986845837'), n = 30, T.cal = "2017-11-01",
                   headers = c("Past", "Future"), title = "")

op <- par(mfrow = c(1, 2), mar = c(2.5, 2.5, 2.5, 2.5))
weekly_inc_total <- elog2inc(groceryElog, by = 1, first = TRUE)
weekly_inc_repeat <- elog2inc(groceryElog, by = 1, first = FALSE)
plot(weekly_inc_total, typ = "l", frame = FALSE, main = "Incremental")
lines(weekly_inc_repeat, col = "red")

weekly_cum_total <- elog2cum(groceryElog, by = 1, first = TRUE)
weekly_cum_repeat <- elog2cum(groceryElog, by = 1, first = FALSE)
plot(weekly_cum_total, typ = "l", frame = FALSE, main = "Cumulative")
lines(weekly_cum_repeat, col = "red")
par(op)

range(groceryElog$date)
groceryCBS <- elog2cbs(groceryElog, T.cal = "2017-11-01")
head(groceryCBS, 5)

op <- par(mfrow = c(1, 2))
(k.wheat <- estimateRegularity(groceryElog, method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.mle <- estimateRegularity(groceryElog, method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)

# load grocery dataset, if it hasn't been done before

groceryCBS <- elog2cbs(groceryElog, T.cal = "2017-11-01")

##############
##NBD MODEL###
##############

# estimate NBD parameters
round(params.nbd <- nbd.EstimateParameters(groceryCBS), 3)
# report log-likelihood
nbd.cbs.LL(params.nbd, groceryCBS)

# calculate expected future transactions for customers who've
# had 1 to 5 transactions in first 52 weeks
est5.nbd <- nbd.ConditionalExpectedTransactions(params.nbd,
                                                T.star = 59, x = 1:5, T.cal = 52)
for (i in 1:5) {
  cat("x =", i, ":", sprintf("%5.3f", est5.nbd[i]), "\n")
}


# predict whole customer cohort
groceryCBS$xstar.nbd <- nbd.ConditionalExpectedTransactions(
  params = params.nbd, T.star = 52,
  x = groceryCBS$x, T.cal = groceryCBS$T.cal)

# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(groceryCBS$x.star)),
      `NBD` = c(`Holdout` = round(sum(groceryCBS$xstar.nbd))))

######################
##Pareto/NBD MODEL###
######################

params.pnbd <- BTYD::pnbd.EstimateParameters(groceryCBS)
names(params.pnbd) <- c("r", "alpha", "s", "beta")
round(params.pnbd, 3)
BTYD::pnbd.cbs.LL(params.pnbd, groceryCBS)

# predict whole customer cohort
groceryCBS$xstar.pnbd <- BTYD::pnbd.ConditionalExpectedTransactions(
  params = params.pnbd, T.star = 52,
  x = groceryCBS$x, t.x = groceryCBS$t.x,
  T.cal = groceryCBS$T.cal)
# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(groceryCBS$x.star)),
      `Pareto/NBD` = c(`Holdout` = round(sum(groceryCBS$xstar.pnbd))))

###################################
##BG/CNBD-k and MBG/CNBD-k MODEL###
###################################

# estimate parameters for various models
params.bgnbd <- BTYD::bgnbd.EstimateParameters(groceryCBS) # BG/NBD
params.bgcnbd <- bgcnbd.EstimateParameters(groceryCBS) # BG/CNBD-k
params.mbgnbd <- mbgnbd.EstimateParameters(groceryCBS) # MBG/NBD
params.mbgcnbd <- mbgcnbd.EstimateParameters(groceryCBS) # MBG/CNBD-k
row <- function(params, LL) {
  names(params) <- c("k", "r", "alpha", "a", "b")
  c(round(params, 3), LL = round(LL))
}
rbind(`BG/NBD` = row(c(1, params.bgnbd),
                     BTYD::bgnbd.cbs.LL(params.bgnbd, groceryCBS)),
      `BG/CNBD-k` = row(params.bgcnbd,
                        bgcnbd.cbs.LL(params.bgcnbd, groceryCBS)),
      `MBG/NBD` = row(params.mbgnbd,
                      mbgcnbd.cbs.LL(params.mbgnbd, groceryCBS)),
      `MBG/CNBD-k` = row(params.mbgcnbd,
                         mbgcnbd.cbs.LL(params.mbgcnbd, groceryCBS)))

# predict whole customer cohort
groceryCBS$xstar.mbgcnbd <- mbgcnbd.ConditionalExpectedTransactions(
  params = params.mbgcnbd, T.star = 52,
  x = groceryCBS$x, t.x = groceryCBS$t.x,
  T.cal = groceryCBS$T.cal)
# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(groceryCBS$x.star)),
      `MBG/CNBD-k` = c(`Holdout` = round(sum(groceryCBS$xstar.mbgcnbd))))


nil <- mbgcnbd.PlotTrackingInc(params.mbgcnbd,
                               T.cal = groceryCBS$T.cal,
                               T.tot = max(groceryCBS$T.cal + groceryCBS$T.star),
                               actual.inc.tracking = elog2inc(groceryElog))
####################
##Pareto/GGG MODEL###
#####################

#groceryCBS<-subset(groceryCBS,cust %in% sample(groceryCBS$cust,1000))

# estimte Pareto/GGG
pggg.draws <- pggg.mcmc.DrawParameters(groceryCBS,chains = 1,mcmc = 500) # ~2mins on 2015 MacBook Pro
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(groceryCBS, pggg.draws)
# conditional expectations
groceryCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
groceryCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
groceryCBS$palive.pggg <- mcmc.PAlive(pggg.draws)
# show estimates for first few customers
head(groceryCBS[, c("x", "t.x", "x.star",
                    "xstar.pggg", "pactive.pggg", "palive.pggg")])
# report median cohort-level parameter estimates
round(apply(as.matrix(pggg.draws$level_2), 2, median), 3)

# report mean over median individual-level parameter estimates

median.est <- sapply(pggg.draws$level_1, function(draw) {
  apply(as.matrix(draw), 2, median)
})
round(apply(median.est, 1, mean), 3)

# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(groceryCBS$x.star)),
      `Pareto/GGG` = round(sum(groceryCBS$xstar.pggg)),
      `MBG/CNBD-k` = round(sum(groceryCBS$xstar.mbgcnbd)),
      `Pareto/NBD (HB)` = round(sum(groceryCBS$xstar.pnbd.hb)))


# error on customer level
mae <- function(act, est) {
  stopifnot(length(act)==length(est))
  sum(abs(act-est)) / sum(act)
}
mae.pggg <- mae(groceryCBS$x.star, groceryCBS$xstar.pggg)
mae.mbgcnbd <- mae(groceryCBS$x.star, groceryCBS$xstar.mbgcnbd)
#mae.pnbd.hb <- mae(groceryCBS$x.star, groceryCBS$xstar.pnbd.hb)

rbind(`Pareto/GGG` = c(`MAE` = round(mae.pggg, 3))
      ,`MBG/CNBD-k` = c(`MAE` = round(mae.mbgcnbd, 3))
      #,`Pareto/NBD (HB)` = c(`MAE` = round(mae.pnbd.hb, 3))
)

lift <- 1 - mae.pggg / mae.mbgcnbd
cat("Lift in MAE:", round(100*lift, 1), "%")

write.table(groceryCBS,"p2p_params.csv",row.names = FALSE,sep = ";")
