library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!octubre2018", dbname="DWH/dwh_olap")


###############################
###Regularidad por servicio####
###############################

FINMES = c(
  
  "2018-04-01","2018-05-01","2018-06-01"
  ,"2018-07-01","2018-08-01","2018-09-01"
)
##########################
##se toma el primer mes##
##########################
c<-data.frame(FINMES[1])
print(c)
tic()
query <- dbSendQuery(con,"
                     
   

                    select f.AR_SSCRBR_DD
                    from smy.ar_monthly_base_fct f
                     left join dtl.ar_trckng_fct at
                     on (at.AR_KEY = f.AR_KEY)
                     left join dtl.pd_dim p on p.PD_KEY = at.PD_KEY
                     --inner join dtl.brckt_dim a on (a.brckt_key = f.total_arpu_brckt_key)
                     where f.PAYMENT= 'PRE' -- payment type group
                     and f.CMMRCL_BS_UN_KEY = 1 --Mobile Business unit --DTL.BS_UN_DIM t
                     and f.TOTAL_ARPU_BRCKT_KEY not in (9,10)
                     --and a.BRCKT_NM not in ('ARPU = $0','$0 < ARPU < $0.5')
                     and f.MB_DATA_4G > 0 -- user technology
                     and f.AR_CMMRCL_ST_KEY = 54 --existing --dtl.     ar_st_dim
                     and at.FCT_DT = last_day(to_date(:1,'YYYY-MM-DD'))
                     and f.FCT_DT= at.FCT_DT
                     and nvl(p.DVC_TP_CD, 'HS') = 'HS' -- linea 118 : smy_cstmr.v_qos_existing                  
                     
                     
                     ", data=c)
df_bkp <- fetch(query)
df<-df_bkp
toc()
##################################
##se toman los meses siguientes##
#################################

for (c in FINMES[-c(1)]) {
  d<-data.frame(c)
  print(c)
  tic()
  query <- dbSendQuery(con,"
                       
                       
                    select f.AR_SSCRBR_DD
                    from smy.ar_monthly_base_fct f
                       left join dtl.ar_trckng_fct at
                       on (at.AR_KEY = f.AR_KEY)
                       left join dtl.pd_dim p on p.PD_KEY = at.PD_KEY
                       --inner join dtl.brckt_dim a on (a.brckt_key = f.total_arpu_brckt_key)
                       where f.PAYMENT= 'PRE' -- payment type group
                       and f.CMMRCL_BS_UN_KEY = 1 --Mobile Business unit --DTL.BS_UN_DIM t
                       and f.TOTAL_ARPU_BRCKT_KEY not in (9,10)
                       --and a.BRCKT_NM not in ('ARPU = $0','$0 < ARPU < $0.5')
                       and f.MB_DATA_4G > 0 -- user technology
                       and f.AR_CMMRCL_ST_KEY = 54 --existing --dtl.     ar_st_dim
                       and at.FCT_DT = last_day(to_date(:1,'YYYY-MM-DD'))
                       and f.FCT_DT= at.FCT_DT
                       and nvl(p.DVC_TP_CD, 'HS') = 'HS' -- linea 118 : smy_cstmr.v_qos_existing                  
                       
                       
                       
                       
                       ", data=d)
  df_bkp <- fetch(query)
  df1<-df_bkp
  
  
  df<-merge(x = df, y = df1, by = "AR_SSCRBR_DD")
  
  toc()
}

str(df)

minsert<-df

rs <- dbSendQuery(con, "truncate table expeam.TMP_BASE_ESTABLE_PRE_18", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.TMP_BASE_ESTABLE_PRE_18 values(:1)", data=minsert)

dbCommit(con)
