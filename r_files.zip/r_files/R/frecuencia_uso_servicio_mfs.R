


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2017-01-01' and date'2017-08-31'
                     --and b.service_id in (402,401,46,4)
                     and b.service_id in (36)
                     
                     
                     
                     
                     ")
df_bkp <- fetch(query)
df<-df_bkp
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2017-07-01")
(nbd.EstimateParameters(dfCBS)[2]/
    nbd.EstimateParameters(dfCBS)[1])

########################
########################

query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     --and b.service_id in (402,401,46,4)
                     and b.service_id in (36)
                     
                     
                     
                     
                     ")
df_bkp <- fetch(query)
df<-df_bkp
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")
(nbd.EstimateParameters(dfCBS)[2]/
    nbd.EstimateParameters(dfCBS)[1])

