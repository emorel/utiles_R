


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(sampling)
library(SamplingStrata)
library(splitstackshape)


###############
####TARGET###
###############
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select *
                      from TMP_BASE_POT_PQ_EXT_CLU t
                     where t.base_antes = 1 
                      and t.NRO_CLUSTER = 'Cluster 5'
                     
                     
                     ")
df_target_bkp <- fetch(query)
toc()
dbDisconnect(con)
df_target<-df_target_bkp

options(scipen=999)
breaks<-50
df_target$ARPU_B<- cut( df_target$ARPU, breaks = breaks, dig.lab=10,ordered_result = FALSE)

#tiff('C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/boxplot_base_target_800.tiff', width = 75, height = 25, units = 'in', res = 200)
#  boxplot(AR_KEY~ARPU_B,df_target)
#dev.off()

## tomamos muestra estratificada
df_target<-stratified(df_target,"ARPU_B",.9999)

#df_target<-subset(df_target,df_target$AR_KEY %in%(sample(df_target$AR_KEY,size = 10000)))

length(unique(df_target$AR_KEY))
## eliminamos bracket usado para muestra estratificada
df_target<-df_target[,-c(18)]

###############
####CONTROL###
###############
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select *
                      from TMP_BASE_POT_PQ_EXT_CLU t
                     where t.base_antes = 0
                     
                     
                     ")
df_control_bkp <- fetch(query)
toc()
dbDisconnect(con)
df_control<-df_control_bkp


options(scipen=999)
breaks<-50
df_control$ARPU_B<- cut( df_control$ARPU, breaks = breaks, dig.lab=10,ordered_result = FALSE)


## tomamos muestra estratificada
df_control<-stratified(df_control,"ARPU_B",.015)

#df_target<-subset(df_target,df_target$AR_KEY %in%(sample(df_target$AR_KEY,size = 10000)))

length(unique(df_control$AR_KEY))
## eliminamos bracket usado para muestra estratificada
df_control<-df_control[,-c(18)]




########################################
#####UNIMOS LAS BASES TARGET CONTROL####
########################################

df_tg<-rbind(df_target,df_control)

### total de clientes
length(unique(df_tg$AR_KEY))

########################################
####BRACKETS PARA VARIABLES CONTINUAS###
########################################
options(scipen=999)
breaks<-20
df_tg$ANTIGUEDAD_MESES_B<- cut( df_tg$ANTIGUEDAD_MESES, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$MB_FREE_B<- cut( df_tg$MB_FREE, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$MB_BILLED_B<- cut( df_tg$MB_BILLED, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$AVG_RECHARGE_B<- cut( df_tg$AVG_RECHARGE, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$MOU_B<- cut( df_tg$MOU, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$ARPU_B<- cut( df_tg$ARPU, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$DATA_REV_B<- cut( df_tg$DATA_REV, breaks = breaks, dig.lab=4,ordered_result = FALSE)
df_tg$VOICE_REV_B<- cut( df_tg$VOICE_REV, breaks = breaks, dig.lab=4,ordered_result = FALSE)


#############################################################
####BRACKETS PARA VARIABLES CHARACTER A FACTOR (CATEGORICAS)#
#############################################################

df_tg<-mutate_if(df_tg,is.character,as.factor)

## eliminamos nulos
#df_tg<-na.omit(df_tg)
## ver como queda el data frame
#str(df_tg)
#summary(df_tg)

###########################
#Propensity Score Matching#
########RMatchit###########
###########################




# tic()
# m.out<- matchit(TIPO~DATA_CONSUMPTION+DISTRITO+ARPU+TENURE+DEVICE_SUBTYPE
#                 ,data=df_tg,method = "nearest",ratio=3)
# toc()

## eliminamos las columnas que no se utilizan
str(df_tg)
data<-df_tg[,-c(1,3,17)] ##FCT_DT,MSISDN_DD,NRO_CLUSTER
## arpu, data,MB_BILLED_B,AVG_RECHARGE_B
tic()
m.out<- matchit(BASE_ANTES~DVC_TYPE+TECNOLOGIA+ANTIGUEDAD_MESES,data=data,method = "nearest",exact = c("MB_BILLED_B","AVG_RECHARGE_B","ARPU_B"),ratio=1)
toc()

summary(m.out)$nn
#plot(m.out,type = "jitter")
#plot(m.out,type = "hist")

df_matched<-match.data(m.out)


#str(df_matched)
#summary(df_matched)






mean(subset(df_matched,BASE_ANTES==1)$ARPU)-
  mean(subset(df_matched,BASE_ANTES==0)$ARPU)

mean(subset(df_matched,BASE_ANTES==1)$MB_BILLED)-
  mean(subset(df_matched,BASE_ANTES==0)$MB_BILLED)

mean(subset(df_matched,BASE_ANTES==1)$AVG_RECHARGE)-
  mean(subset(df_matched,BASE_ANTES==0)$AVG_RECHARGE)


#write.table(df_matched,file = "C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/target_control_matched_feb_19_pqext_1.csv",sep = ";",row.names = FALSE)
####################
###ARP Incremental##
###################

base.insertar<-select(df_matched,"AR_KEY","BASE_ANTES")
base.insertar$NRO_CLUSTER <- 'Cluster 5'
colnames(base.insertar)<-c("AR_KEY","TIPO_BASE","NRO_CLUSTER")
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_BASE_TG_CLU", base.insertar, rownames=FALSE, overwrite = FALSE, append = TRUE)
#dbWriteTable(con,"TMP_BASE_TG_CLU", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
