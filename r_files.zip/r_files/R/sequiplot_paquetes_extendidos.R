#debug(utils:::unpackPkgZip)
#install.packages('openxlsx')



library(ROracle)
library(dplyr)
library(ggplot2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(TraMineR)
library(data.table)
library(dplyr)
library(bayesm)
library(NMF)
library("cluster")
library(WeightedCluster)
library(tictoc)
library("wesanderson")
library(ROracle)
library(viridis)
library(RColorBrewer)
library(gtools)
library(scales)
library(TraMineR)


con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     select *
                     from expeam.tmp_base_ci_co_sts
                     
                     
                     ")
dfa1 <- fetch(query)
toc()
dbDisconnect(con)
dfa<-dfa1

#dfa<-dcast(dfa, MSISDN ~ MES, value.var="NIVEL", fun.aggregate=max)
#dfa[is.na(dfa)]<-"PDV EPIN"

#str(dfa)
#dfa<-dfa1[c(1,14,15,16,17,18)]

#dfa<-subset(dfa, dfa$DOCUMENT_NUMBER %in% sample(dfa$DOCUMENT_NUMBER,10000))
#dfa<-dcast(dfa,DOCUMENT_NUMBER ~ FECHA_DATOS,value.var = 'MONTO')
## Conteos
# dfa$CANT_NULL<-rowSums(is.na(dfa))
# 
# 





length(unique(dfa$DOCUMENT_NUMBER))

# dfa <- subset(dfa,CANT_CONV>0 & CANT_OTC >1)

#str(dfa)
##insercion en base de datos
#base.insertar <- unique(dfa$DOCUMENT_NUMBER)
#rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
#rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1,null)", data=base.insertar)
#dbCommit(con)
#dfa[is.na(dfa)]<-'NO_ACTIVITY'

## para ordernar variables CHR numericas
#mvad.scode<-seqstatl(dfa[-c(1,5,6,7)], var=NULL, format='STS')
#mvad.scode<-seqstatl(dfa[-c(1,183,184,185,186)], var=NULL, format='STS')
mvad.scode<-seqstatl(dfa[-c(1,81,82,83)], var=NULL, format='STS')
#mvad.scode<-seqstatl(dfa[-c(1,32,33,34,35,36)], var=NULL, format='STS')
#mvad.scode<-seqstatl(dfa[c(153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182)], var=NULL, format='STS')
mvad.scode<-mixedsort(mvad.scode)
mvad.scode

###
##PALETA DE COLORES
n <- length(mvad.scode)
paleta<-viridis_pal(option = "D")(n)  # n = number of colors seeked
pie(rep(1,n), col=paleta)

## otra manera
#qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
#col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
#pie(rep(1,n), col=sample(col_vector, n))
########
##generacion de graficos 
apc<-ncol(dfa)-4
#apc<-ncol(dfa[c(153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,177,178,179,180,181,182)])
#dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE ,right = "DEL",left = "DEL",gaps="DEL",alphabet = mvad.scode, states = mvad.scode, labels = mvad.scode)
dfa.seq <- seqdef(dfa, 2:apc, xtstep = 10,cpal=paleta,weighted = FALSE,alphabet = mvad.scode, states = mvad.scode, labels = mvad.scode)
#dfa.seq <- seqdef(dfa, 153:apc, xtstep = 10,cpal=paleta,weighted = FALSE,alphabet = mvad.scode, states = mvad.scode, labels = mvad.scode)

#SEQIPLOT
##
tiff('C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/sequiplot/seqIplot_pq_diarios_extendidos_10000.tiff', width = 35, height = 25, units = 'in', res = 200)
  seqIplot(dfa.seq, border = NA, xtstep = 1,sortv="from.start",cex.legend=3,cex.main=3,cex.axis = 2,main="Cronograma compra paquetes DIARIOS - EXTENDIDOS - N= 10.000")
dev.off()
##
#SEQDPLOT
##
tiff('C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/sequiplot/seqdplot_pq_diarios_extendidos_10000.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA,cex.legend=3,cex.main=4,cex.axis = 3,main="Share compra paquetes DIARIOS - EXTENDIDOS - N= 10.000")
dev.off()
##



##armado de clusters ## full matrix para reducir la matriz de distancias.. (utilizar with.missing para mostrar actividad)
#dfa.om <- seqdist(dfa.seq, method = "OM", indel = 1, sm = "TRATE",with.missing = FALSE,full.matrix=TRUE)
cant.clust<-5
dfa.om <- seqdist(dfa.seq, method = "OM", indel = 1, sm = "TRATE",with.missing = TRUE,full.matrix=TRUE)
tic()
clusterward <- agnes(dfa.om, diss = TRUE, method = "ward")
toc()
dfa.cl4 <- cutree(clusterward, k = cant.clust)
cl4.lab <- factor(dfa.cl4, labels = paste("Cluster", 1:cant.clust))
###agregar clusters a cada cliente
dfa$CLUSTER<-cl4.lab
###Extraer un cluster especifico
#base.insertar <-(subset(dfa,cluster == 'Cluster 1'))$DOCUMENT_NUMBER
base.insertar<-data.frame(AR_KEY=dfa$DOCUMENT_NUMBER,CLUSTER=dfa$CLUSTER)
con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
  dbWriteTable(con,"TMP_SEQUIPLOT_BASE_CLUST10000", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
##
#SEQIPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/sequiplot/seqIplot_pq_diarios_extendidos_10000_q.tiff', width = 35, height = 25, units = 'in', res = 200)
seqIplot(dfa.seq, border = NA, group = cl4.lab, xtstep = 1,sortv="from.start",cex.legend=6,cex.main=5,cex.axis = 4,main="Cronograma compra paquetes DIARIOS - EXTENDIDOS - N= 10.000")
dev.off()
##
#SEQDPLOT CLUSTER
##
tiff('C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/graficos/sequiplot/seqdplot_pq_diarios_extendidos_10000_q.tiff', width = 35, height = 25, units = 'in', res = 200)
seqdplot(dfa.seq,xtstep = 1, border = NA, group = cl4.lab,cex.legend=6,cex.main=3,cex.axis = 4,main="Share compra paquetes DIARIOS - EXTENDIDOS - N= 10.000")
dev.off()
##

#LEGENDS
#tiff('C:/Users/expeam/Documents/segment/2018/analisis_cc_cash_out_tiendas/seqIplot_clientes_cc_tiendas_entrega_3487_c.tiff', width = 5, height = 10, units = 'in', res = 200)
#seqlegend(dfa.seq)
#dev.off()
