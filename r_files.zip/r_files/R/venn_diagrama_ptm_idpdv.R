
#upload library
library(VennDiagram)
library(tictoc)


con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")
##DMS
tic()
query <- dbSendQuery(con,"
                     
                  select t.ID_POINT_OF_SALE as idpdv
                  from RPL_DMS2.COM_POINT_OF_SALE t
                     where t.ID_POINT_OF_SALE is not null                     
                     
                     
                     ")
base1 <- fetch(query)
toc()

##MTS
tic()
query <- dbSendQuery(con,"
                     

                      select to_number(ha.POS_ID) as idpdv
                      from rpl_tigo_cash.h_agent_mobile ha
                     where ha.FECHA= trunc(sysdate)
                     --and ha.POS_ID is not null
                     and regexp_like(ha.POS_ID,'[[:digit:]]')
                     and ha.POS_ID <> '0.'

                     ")
base2 <- fetch(query)
toc()
##DMS_MTS
tic()
query <- dbSendQuery(con,"
                     
            select ttc.ID_POS as idpdv
            from rpl_dms2.tbl_tigo_cash ttc     


                     ")
base3 <- fetch(query)
toc()
##TIGO_BILL_PAYS
tic()
query <- dbSendQuery(con,"
                     
            select   bm.document_number
              from tigo_cash_rpt.base_cliente_mfs_daily_ci bm
                     where bm.service_id IN (21603,512,3001)
                     and bm.fecha_datos between date'2017-12-31' -60 and date'2017-12-31'-1-- cambio
                     
                     ")
base4 <- fetch(query)
toc()

##OTC
tic()
query <- dbSendQuery(con,"
                     
                     select   bm.document_number
                     from tigo_cash_rpt.base_cliente_mfs_daily_ci bm
                     where bm.service_id IN (36,1)
                     and bm.fecha_datos between date'2017-12-31' -60 and date'2017-12-31'-1-- cambio
                     
                     ")
base5 <- fetch(query)
toc()


#Then generate 3 sets of words.There I generate 3 times 200 SNPs names.
base1<-base1$IDPDV
base1[is.na(base1)]<-"1"
base2<-base2$IDPDV
base2[is.na(base2)]<-"1"
base3<-base3$IDPDV
base3[is.na(base3)]<-"1"
base4<-base4$IDPDV
base4[is.na(base4)]<-"1"
base5<-base5$IDPDV
base5[is.na(base5)]<-"1"


#The goal of the Venn Diagram is to count how many words are common between SNP_pop_1 and SNP_pop_2, between SNP_pop_1 and SNP_pop_3 and so on...
#The venn.diagram function do it automatically and draw it! (you will get a png file in your current working directory)

tic()
venn.diagram(
  x = list(base1,base2,base3),
  category.names = c("DMS","MTS","DMS_MTS"),
  filename = 'C:/Users/expeam/Documents/segment/2018/09-septiembre/crecimiento_ptm/venn_diagramm_dms_mts.png',
  output = TRUE ,
  imagetype="png" ,
  height = 768 , 
  width = 1024 , 
  resolution = 300,
  compression = "lzw",
  lwd = 2,
  lty = 'blank',
  fill = c('yellow', 'purple','green'),
  cex = 0.5,
  fontface = "bold",
  fontfamily = "sans",
  cat.cex = 0.5,
  cat.fontface = "bold",
  cat.default.pos = "outer",
  #cat.pos = c(-27, 27, 135),
  #cat.dist = c(0.055, 0.055, 0.085),
  cat.fontfamily = "sans",
  #print.mode = 'percent'
  
)

toc() 

