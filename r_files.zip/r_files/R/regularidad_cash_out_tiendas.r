library(BTYDplus)
library(reshape2)
library(dplyr)
library(tictoc)
con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     

SELECT t.document_number
,TO_CHAR(t.fecha, 'YYYY-MM-DD') as FECHA_datos
,sum(t.monto) as monto
from tigo_cash_rpt.base_mfs_det_trx t
JOIN tigo_cash_rpt.base_mfs_categoria c
ON (t.pk_categoria=c.pk_categoria)
join expeam.tmp_base_cc_tiendas_oct_nov_17 tt
on (t.msisdn=tt.nro_cuenta)
WHERE t.fecha BETWEEN DATE'2017-06-01' AND DATE'2018-01-31'
AND c.service_id = 98
AND t.result = 0
AND t.type_aux = 1
GROUP BY TO_CHAR(t.fecha, 'YYYY-MM-DD')
,t.document_number

                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
length(unique(df$DOCUMENT_NUMBER))

df$FECHA_DATOS <- as.Date(df$FECHA_DATOS, format = "%Y-%m-%d")
df$DOCUMENT_NUMBER<-factor(df$DOCUMENT_NUMBER)

set.seed(123)

colnames(df) <- c("cust","date","sales")
summary(df)
str(df)
length(unique(df$cust))


plotTimingPatterns(df, n = 150, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")

#plotTimingPatterns(subset(df, cust=='0961822132'), n = 50, T.cal = "2017-08-31",headers = c("Past", "Future"), title = "")

#generamos la tabla cbs
dfcbs<-elog2cbs(df)
summary(dfcbs)
length(dfcbs$cust)



head(arrange(dfcbs, desc(litt)))
#df1<-subset(df, cust %in% dfcbs$cust)

estimateRegularity(df, method = "wheat",plot = TRUE, title = "Wheat & Morrison")
estimateRegularity(df, method = "mle",plot = TRUE, title = "Wheat & Morrison")


#REGULARIDAD DEL CLIENTE


unique.cust<-unique(df$cust)
unique.cust.cant<-length(unique(df$cust))
mat <- matrix(, nrow = length(unique.cust), ncol = 2)
j=1
for (i in unique.cust){
  mat[j,1]=i
  mat[j,2]=estimateRegularity(subset(df, cust %in% i), method = "mle")
  j=j+1
  if (j>unique.cust.cant) break
}
write.table(mat,file="factura_regularity.csv", sep = ";" ,quote = TRUE,eol = "\n",row.names = FALSE,col.names = FALSE)

write.table(dfcbsinsert,file="factura_parametros.csv", sep = ";" ,quote = TRUE,eol = "\n",row.names = FALSE,col.names = FALSE)




#P(Active), P(Alive)

dfcbs <- elog2cbs(df, T.cal = "2017-11-01")

# estimte Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfcbs) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfcbs, pggg.draws)
# conditional expectations
dfcbs$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfcbs$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfcbs$palive.pggg <- mcmc.PAlive(pggg.draws)
# show estimates for first few customers
head(dfcbs[, c("x", "t.x", "x.star","xstar.pggg", "pactive.pggg", "palive.pggg")])

#hacemos left join
dfcbs.bkp<-dfcbs
dfinsert.bkp<-dfinsert
colnames(dfinsert.bkp)<-c("cust","date")


dfcbsinsert<-merge(dfcbs,dfinsert.bkp,by="cust",all.x = TRUE)

dfcbsinsert<-select(dfcbsinsert,-cust)

colnames(dfcbsinsert)[12] <- "k"

#insertamos en la base

dfinsert<-as.data.frame(mat)
dfinsert$V2 <- chartr('.', ',', dfinsert$V2)

rs <- dbSendQuery(con, "insert into expeam.PACTIVE_FACTURA values(:1, :2, :3, :4,to_date(:5,'yyyy-mm-dd'), :6,:7, :8,:9, :10,:11, :12)", data=dfcbsinsert)

dbCommit(con)


dfcbsinsert$x <- chartr('.', ',', dfcbsinsert$x)
dfcbsinsert$t.x <- chartr('.', ',', dfcbsinsert$t.x)
dfcbsinsert$litt <- chartr('.', ',', dfcbsinsert$litt)
dfcbsinsert$first <- chartr('.', ',', dfcbsinsert$first)
dfcbsinsert$T.cal <- chartr('.', ',', dfcbsinsert$T.cal)
dfcbsinsert$T.star <- chartr('.', ',', dfcbsinsert$T.star)
dfcbsinsert$x.star <- chartr('.', ',', dfcbsinsert$x.star)
dfcbsinsert$xstar.pggg <- chartr('.', ',', dfcbsinsert$xstar.pggg)
dfcbsinsert$pactive.pggg <- chartr('.', ',', dfcbsinsert$pactive.pggg)
dfcbsinsert$palive.pggg <- chartr('.', ',', dfcbsinsert$palive.pggg)

str(dfcbsinsert)
dfcbsinsert$first
dfcbsinsert$first <- as.character(dfcbsinsert$first)