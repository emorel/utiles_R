
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)

con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select p.nro_cuenta
                     ,p.monto
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     and p.servicio = 'Carga de dinero'
                     and p.nro_cuenta in
                     (
                     select p.nro_cuenta
                     from tigo_cash_rpt.product_tracking p
                     
                     join expeam.tmp_base_pospago_mayo18 a
                     on (p.nro_cuenta=a.ar_sscrbr_dd)
                     
                     where p.fecha_datos between date'2018-04-01' and date'2018-05-31'
                     AND p.categoria = 'Bill Payments' 
                     and p.subcategoria = 'MENU Payments'
                     
                     
                     )
                     
                     
                     ")
t <- fetch(query)
toc()

summary(t)
par(mfrow=c(2,1)) 

xs=quantile(t$MONTO,c(0,1/10,2/10,3/10,4/10,5/10,6/10,7/10,8/10,9/10,10/10))
xs[1]=xs[1]-.00005
t <- t %>% mutate(MONTO_F=cut(t$MONTO, breaks=xs, labels=c("1","2","3","4","5","6","7","8","9","10")))

boxplot(t$MONTO~t$MONTO_F,col=3:5)


ggplot(data = t) +
  geom_histogram(mapping = aes(x = MONTO/1000), binwidth = 1000)

ggplot(data = t, mapping = aes(x = MONTO/1000, colour = MONTO_F)) +
  geom_freqpoly(binwidth = 10)

ggplot(data = t, mapping = aes(x = MONTO/1000)) + 
  geom_freqpoly(mapping = aes(colour = MONTO_F), binwidth = 10)

ggplot(data = t, mapping = aes(x = MONTO_F, y = MONTO/1000)) +
  geom_boxplot()


t$MONTO_F<-as.factor(t$MONTO_F)

ggplot(data = subset(t,MONTO_F)) +
  geom_histogram(mapping = aes(x = MONTO/1000), binwidth = 100)

t %>% 
  count(MONTO_F, MONTO/1000) %>%  
  ggplot(mapping = aes(x = MONTO_F, y = MONTO/1000)) +
  geom_tile(mapping = aes(fill = n))




t <-select(t,-category_f)

plot(select(t,c(edad_rango,MOROSO)))
plot(select(t,c(antiguedad_mes_rango,MOROSO)))
plot(select(t,c(revenue_rango,MOROSO)))
plot(select(t,c(recarga_rango,MOROSO)))
