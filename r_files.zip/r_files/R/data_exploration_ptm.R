
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(tictoc)
library(ROracle)
library(stats)

con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                    select sum(b.monto_mov) as monto
                    ,b.msisdn
                     ,last_day(b.fecha) as fecha
                     from tigo_cash_rpt.base_agente_mfs_daily b
                     where b.fecha between date'2018-06-01' and date'2018-07-31'
                     group by b.msisdn
                     ,last_day(b.fecha) 
                     
                     ")
t <- fetch(query)
toc()
summary(t)

tiff('C:/Users/expeam/Documents/segment/2018/agosto/segmentacion_ptm/histograma_comisiones_ptm.tiff', width = 35, height = 25, units = 'in', res = 200)
#bins <- c(0,500,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000,6500,7000,7500,8000,8500,9000,9500,10000,10500,11000,11500,12000,12500,13000,13500,14000,14500,15000,15500,16000,16500,17000,17500,18000,18500,19000,19500,20000,20500,21000,21500,22000,22500,23000,23500,24000,24500,25000,25500,26000,26500,27000,27500,28000,28500,29000,29500,30000,30500,31000,31500,32000,32500,33000,33500,34000,34500,35000,35500,36000,36500,37000,37500,38000,38500,39000,39500,40000,40500,41000,41500,42000,42500,43000,43500,44000,44500,45000,45500,46000,46500,47000,47500,48000,48500,49000,49500,50000)
bins <-  quantile(t$MONTO,0:130*(1/130))
#bins <-  max(t$MONTO)/1000
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  ggtitle("COMISIONES - PTM (2018)")+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45,size = 20)
        ,axis.text.y = element_text(size = 20)
        ,axis.title.x = element_text(size = 20)
        ,axis.title.y = element_text(size = 20)
        ,title = element_text(size = 40)
        )+
  ylab(label="PORCENTAJE")+
  xlab(label="COMISIONES PTM")
dev.off()


tiff('C:/Users/expeam/Documents/segment/2018/julio/caida_core_bussiness/histograma_minicarga.tiff', width = 35, height = 25, units = 'in', res = 200)
bins <- c(0,500,1000,1500,2000,2500,3000,3500,4000,4500,5000,5500,6000,6500,7000,7500,8000,8500,9000,9500,10000,10500,11000,11500,12000,12500,13000,13500,14000,14500,15000,15500,16000,16500,17000,17500,18000,18500,19000,19500,20000,20500,21000,21500,22000,22500,23000,23500,24000,24500,25000,25500,26000,26500,27000,27500,28000,28500,29000,29500,30000,30500,31000,31500,32000,32500,33000,33500,34000,34500,35000,35500,36000,36500,37000,37500,38000,38500,39000,39500,40000,40500,41000,41500,42000,42500,43000,43500,44000,44500,45000,45500,46000,46500,47000,47500,48000,48500,49000,49500,50000,50500,51000,51500,52000,52500,53000,53500,54000,54500,55000,55500,56000,56500,57000,57500,58000,58500,59000,59500,60000)
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  ggtitle("MINICARGA - TIGO MONEY (2018)")+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45,size = 20)
        ,axis.text.y = element_text(size = 20)
        ,axis.title.x = element_text(size = 20)
        ,axis.title.y = element_text(size = 20)
        ,title = element_text(size = 40)
  )+
  ylab(label="PORCENTAJE")+
  xlab(label="MONTO_MINICARGA")
dev.off()


bins <- c(0,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000,14000,15000,16000,17000,18000,19000,20000,21000,22000,23000,24000,25000,26000,27000,28000,29000,30000)
ggplot(t,aes(x=MONTO,y=(..count../sum(..count..))*100))+
  
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=30))+
  theme(axis.text.x = element_text(angle = 45))+
  ylab(label="PORCENTAJE")+
  xlab(label="MONTO_CARGA")




bins <- c(0,10,20,30,40,50,60,70,80,90,100)
ggplot(t,aes(x=EDAD,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="EDAD")

bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)
ggplot(t,aes(x=ANTIGUEDAD_CLIENTE,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  ylab(label="PORCENTAJE")+
  xlab(label="ANTIGUEDAD_CLIENTE")


ggplot(t, aes(x=MONTO)) +
  theme_bw() +
  scale_x_continuous(breaks = pretty(t$MONTO/1000, n = 10)) +
  geom_histogram(alpha=0.6, binwidth=50) +
  ggtitle("Distribucion por TOTAL_CARGA")+
  theme(axis.text.x = element_text(angle=45))


basedate <- as.POSIXct(t$DIA,origin ="1582-10-14", tz = "GMT")
#tiff('C:/Users/edgar/Documents/analisis_envio/comparativo_var_envio_abandono_1.tiff', width = 35, height = 15, units = 'in', res = 300)
ggplot(t, aes(x=DIA,y=DATA )) +
  ggtitle("CORE Vs Envio")+
  geom_line()	+	
  scale_x_datetime(minor_breaks = basedate,breaks=pretty_breaks(n=30)) +
  facet_wrap(~TYPE+BASE, scales = 'free_y', ncol = 2)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=1)+geom_point(size=1/9)+theme(text = element_text(size=10),plot.title = element_text(hjust = 0.5))
#dev.off()