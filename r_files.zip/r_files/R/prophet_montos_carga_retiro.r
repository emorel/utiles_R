library(prophet)
library(dplyr)
library(bsts)
library(lubridate)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"

                     
/*SELECT SUM(T.MONTO) AS MONTO
,to_char(t.fecha,'YYYY-MM-DD') as fecha
FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
LEFT JOIN RPL_TIGO_CASH.SERVICE S ON(T.SERVICE_ID=S.SERVICE_ID)
LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON(T.PK_CATEGORIA=C.PK_CATEGORIA)
WHERE T.FECHA BETWEEN DATE'2016-01-01' AND DATE'2018-02-28'
AND NOT(T.SERVICE_ID IN(4,36,46,401,402) AND T.TYPE_AUX=2)
AND T.RESULT =0
--and c.servicio in ('Ande','Ande-NV','Chacomer','Chacomer-NV','Electroban','Electroban-NV','FPUNA','Fundacion Pya.','Fundacion Pya-NV','Inverfin','La Red','La Red-NV','Pago de Servicios')
and c.servicio in ('Carga de dinero')
GROUP BY to_char(t.fecha,'YYYY-MM-DD')*/

SELECT sum (b.monto) AS MONTO
,to_char(b.fecha_datos,'YYYY-MM-DD') as FECHA
from tigo_cash_rpt.product_tracking b
where b.fecha_datos between date'2016-01-01' and date'2018-02-28'
--AND b.categoria in ('Merchant Payments')
GROUP BY to_char(b.fecha_datos,'YYYY-MM-DD')
order by 2

")


result <- fetch(query)


df <- result

df$FECHA <- as.Date(df$FECHA, format = "%Y-%m-%d")

outlierKD(df, MONTO)
yes
#df<-na.omit(df)

outlierKD(df, MONTO)
yes
#df<-na.omit(df)


colnames(df)<-c("y","ds")


playoffs <- data_frame(
  holiday = 'feriados',
  ds = as.Date(c('2016-01-01', '2016-02-29','2016-03-24', '2016-03-25', '2016-05-01','2016-05-14','2016-05-15','2016-06-12','2016-08-15','2016-10-03','2016-12-08','2016-12-25',
                 '2017-01-01', '2017-02-27','2017-04-13', '2017-04-14','2017-05-01','2017-05-14','2017-05-15','2017-06-12','2017-08-14','2017-10-02','2017-12-08','2017-12-25',
                 '2018-01-01', '2018-02-26','2018-03-29', '2018-03-30', '2018-05-01','2018-05-14','2018-05-15','2018-06-11','2018-08-15','2018-10-03','2018-12-08','2018-12-25',
                 '2016-01-03','2016-01-10','2016-01-17','2016-01-24','2016-01-31','2016-02-07','2016-02-14','2016-02-21','2016-02-28','2016-03-06','2016-03-13','2016-03-20','2016-03-27','2016-04-03','2016-04-10','2016-04-17','2016-04-24','2016-05-01','2016-05-08','2016-05-15','2016-05-22','2016-05-29','2016-06-05','2016-06-12','2016-06-19','2016-06-26','2016-07-03','2016-07-10','2016-07-17','2016-07-24','2016-07-31','2016-08-07','2016-08-14','2016-08-21','2016-08-28','2016-09-04','2016-09-11','2016-09-18','2016-09-25','2016-10-02','2016-10-09','2016-10-16','2016-10-23','2016-10-30','2016-11-06','2016-11-13','2016-11-20','2016-11-27','2016-12-04','2016-12-11','2016-12-18','2016-12-25','2017-01-01','2017-01-08','2017-01-15','2017-01-22','2017-01-29','2017-02-05','2017-02-12','2017-02-19','2017-02-26','2017-03-05','2017-03-12','2017-03-19','2017-03-26','2017-04-02','2017-04-09','2017-04-16','2017-04-23','2017-04-30','2017-05-07','2017-05-14','2017-05-21','2017-05-28','2017-06-04','2017-06-11','2017-06-18','2017-06-25','2017-07-02','2017-07-09','2017-07-16','2017-07-23','2017-07-30','2017-08-06','2017-08-13','2017-08-20','2017-08-27','2017-09-03','2017-09-10','2017-09-17','2017-09-24','2017-10-01','2017-10-08','2017-10-15','2017-10-22','2017-10-29','2017-11-05','2017-11-12','2017-11-19','2017-11-26','2017-12-03','2017-12-10','2017-12-17','2017-12-24','2017-12-31','2018-01-07','2018-01-14','2018-01-21','2018-01-28','2018-02-04','2018-02-11','2018-02-18','2018-02-25','2018-03-04','2018-03-11','2018-03-18','2018-03-25','2018-04-01','2018-04-08','2018-04-15','2018-04-22','2018-04-29','2018-05-06','2018-05-13','2018-05-20','2018-05-27','2018-06-03','2018-06-10','2018-06-17','2018-06-24','2018-07-01','2018-07-08','2018-07-15','2018-07-22','2018-07-29','2018-08-05','2018-08-12','2018-08-19','2018-08-26','2018-09-02','2018-09-09','2018-09-16','2018-09-23','2018-09-30','2018-10-07','2018-10-14','2018-10-21','2018-10-28','2018-11-04','2018-11-11','2018-11-18','2018-11-25','2018-12-02','2018-12-09','2018-12-16','2018-12-23','2018-12-30')),
  lower_window = 0,
  upper_window = 1
)
holidays <- bind_rows(playoffs)
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality = TRUE, holidays = holidays,seasonality.prior.scale = 50)
#m <- prophet(df,yearly.seasonality = TRUE)
#m <- prophet(df,seasonality.prior.scale = 20,changepoint.prior.scale = 0.001)
#m <- prophet()
#m <- add_seasonality(  m, name='weekly', period=7, fourier.order=3, prior.scale=150)



#Daily
future <- make_future_dataframe(m, periods = 31)
tail(future)
#Monthly
#future <- make_future_dataframe(m, periods = 12, freq = 'month')
#tail(future)


##OUTLIERS
# outliers <- (as.Date(df$ds) > as.Date('2015-01-01')
#             & as.Date(df$ds) < as.Date('2016-01-31'))



#df$y[outliers] = NA
#m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE)
#m <- prophet(df)



forecast <- predict(m, future)
tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

#prophet_plot_components(m, forecast)
plot(m, forecast)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
write.table(df[c("ds","y")],file="actual_1.csv",sep=";",row.names = FALSE)
##definimos las fechas para el subset
#sf <- c(as.Date('2017-04-01', format = "%Y-%m-%d"),as.Date('2017-04-08', format = "%Y-%m-%d"))
#i <- as.Date('2017-04-15', format = "%Y-%m-%d")
#while (i<=Sys.Date()+28){
#	sf <- append(sf,i)
#	i<-i+7
#}
#solo seleccionamos las fechas del reporte del comite
##cada 7 dias
#subset(forecast[c("ds","yhat")],forecast$ds %in% sf)
#write.csv(subset(forecast[c("ds","yhat")],forecast$ds %in% sf),"forecast_merchant_payment.csv")

df_month<-forecast %>% group_by(month=floor_date(ds,'month')) %>%  summarize(amount=sum(yhat))


# df_month<-data.frame(
# "FECHA"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,as.character(as.Date(forecast$ds, format = "%Y-%m-%d")),NA)
# ,"DATO"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,forecast$yhat,NA)
# )
# df_month<-na.omit(df_month)
# df_month<-as.data.frame(df_month)

#write.csv(df_month,"forecast_1.csv",row.names=FALSE)
write.table(df_month,file="forecast_1.csv",sep=";",row.names = FALSE)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
#write.csv(forecast[c("ds","yhat")],"forecast_1.csv")

