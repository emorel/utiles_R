
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)
library(readxl)
library(DescTools)

library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
with
monto as
(
select 
to_char(b.fecha_datos,'YYYYMM') as mes
,round(sum(b.monto)/1000000,0) as monto
from tigo_cash_rpt.base_cliente_mfs_daily b
where b.fecha_datos between date'2016-01-01' and date'2018-02-28'
and b.tipo = 'from OTC'
group by to_char(b.fecha_datos,'YYYYMM')
)
,lluvia as
(
select 
to_char(l.fecha_datos,'YYYYMM') as mes
,sum(l.ml) as ml
from expeam.base_dias_lluvias_2016_2017 l
where l.ciudad = 'PILAR'
group by to_char(l.fecha_datos,'YYYYMM')
)
select monto.monto
,lluvia.ml
from monto
left join lluvia
on (monto.mes = lluvia.mes)

                     
                     ")
df_backup <- fetch(query)
toc()
df<-df_backup


#base_estudio_lluvia <- read_excel("segment/2018/febrero/estudio_lluvia/base_estudio_lluvia_2016_2017_2018_ASUNCION.xlsx",col_types = c("numeric", "numeric"))
#df<-base_estudio_lluvia

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df<-scale(df)
df<-as.data.frame(df)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

df$ML<-log(df$ML)
df$MONTO<-log(df$MONTO)

plot(df)
chart.Correlation(df, histogram=TRUE, pch=19)

##correr tres veces minimo

outlierKD(df, ML)
yes
df<-na.omit(df)
outlierKD(df, MONTO)
yes
df<-na.omit(df)

##########
## MODELO
##########


telecomModel <- lm(MONTO ~ ML,data=df)
print(summary(telecomModel))


(1-MAE(telecomModel))*100
#(1-MAPE(telecomModel))*100
(1-MSE(telecomModel))*100
(1-RMSE(telecomModel))*100

as.formula(
  paste0("y ~ ", round(coefficients(telecomModel)[1],2), "", 
         paste(sprintf(" %+.2f*%s ", 
                       coefficients(telecomModel)[-1],  
                       names(coefficients(telecomModel)[-1])), 
               collapse="")
  )
)