
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)
library(tictoc)

library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"


                    /*with
                     pt as
                     (
                     SELECT sum(p.monto) as monto
                     ,sum(p.monto)/sum(p.cant_trx) as ticket_trx
                     ,sum(p.cant_trx) as cant_trx
                     ,p.fecha_datos as fecha
                     FROM tigo_cash_rpt.product_tracking p
                     WHERE p.fecha_datos BETWEEN date'2016-01-01' AND date'2018-01-31'
                     and p.categoria = 'Self Top Up'
                    --and p.servicio in ('Ande','Ande-NV','Banco Familiar-NV','Chacomer','Electroban','FPUNA','Fundacion Pya.','Inverfin','La Red','Pago de Servicios','Pago Fielco')
                     group by p.fecha_datos
                     )
                     ,base as
                     (
                     SELECT v.cantidad
                     ,v.fecha_datos as fecha
                     from expeam.res_base_mfs_dai_cat_ci_60 v
                     where v.fecha_datos BETWEEN date'2016-01-01'-60 AND date'2018-01-31'
                     AND v.categoria = 'Self Top Up'
                     AND v.disconnects_indicator = 'Begining Day'
                     )
                     select pt.monto/base.cantidad as ticket_cliente
                     ,base.cantidad as cant_cliente
                     ,pt.cant_trx
                     ,pt.ticket_trx
                     ,pt.monto
                     from pt
                     join base on
                     (pt.fecha=base.fecha)*/

                      /*SELECT
                      sum(decode(p.servicio,'Ande',p.monto,0)) as monto_ande
                     ,sum(decode(p.servicio,'Chacomer',p.monto,0)) as monto_chacomer
                     ,sum(decode(p.servicio,'Electroban',p.monto,0)) as monto_electroban
                     ,sum(decode(p.servicio,'Pago de Servicios',p.monto,0)) as monto_pago_servicios
                     ,sum(p.cant_trx) as cant_trx
                      ,sum(p.monto) as monto_total
                     --,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha
                     FROM tigo_cash_rpt.product_tracking p
                     WHERE p.fecha_datos BETWEEN date'2015-01-01' AND date'2018-01-31'
                     and p.servicio in ('Ande','Ande-NV','Chacomer','Electroban','FPUNA','Fundacion Pya.','Inverfin','La Red','Pago de Servicios')
                     --and p.servicio in ('Ande','Ande-NV')
                     --and p.servicio in ('Pago de Servicios')
                     --and p.servicio in ('Chacomer','Electroban','FPUNA','Fundacion Pya.','Inverfin','La Red')
                     --and p.categoria = 'Self Top Up'
                     group by to_char(p.fecha_datos,'YYYY-MM-DD')
                      order by 1*/


                      /*SELECT
                      sum(decode(p.subcategoria,'3rd Party Network',p.monto,0)) as monto_3party
                     ,sum(decode(p.subcategoria,'Mobile Devices',p.monto,0)) as monto_m2m
                     ,sum(decode(p.subcategoria,'Companion Card',p.monto,0)) as monto_companion
                     ,sum(decode(p.subcategoria,'Payment Gateway',p.monto,0)) as monto_boton
                     ,sum(p.cant_trx) as cant_trx
                     ,sum(p.monto) as monto_total
                     FROM tigo_cash_rpt.product_tracking p
                     WHERE p.fecha_datos BETWEEN date'2015-01-01' AND date'2018-01-31'
                     and p.categoria = 'Merchant Payments'
                     group by to_char(p.fecha_datos,'YYYY-MM-DD')
                     order by 1*/


                      SELECT 
                      SUM(T.MONTO) AS MONTO
                      ,sum(t.can_trx) as cant_trx
                      ,sum(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Ande',t.monto,0))) as monto_ande_menu
                     ,sum(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Ande',t.can_trx,0))) as trx_ande_menu
                     ,count(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Ande',t.document_number,0))) as cliente_ande_menu
                     
                     ,sum(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Ande',t.monto,0))) as monto_ande_otc
                     ,sum(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Ande',t.can_trx,0))) as trx_ande_otc
                     ,count(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Ande',t.document_number,0))) as cliente_ande_otc
                     
                     ,sum(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Pago de Servicios',t.monto,0))) as monto_netel_menu
                     ,sum(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Pago de Servicios',t.can_trx,0))) as trx_netel_menu
                     ,count(decode(c.sub_categoria , 'MENU Payments',decode(c.servicio ,'Pago de Servicios',t.document_number,0))) as cliente_netel_menu
                     
                     ,sum(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Pago de Servicios',t.monto,0))) as monto_netel_otc
                     ,sum(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Pago de Servicios',t.can_trx,0))) as trx_netel_otc
                     ,count(decode(c.sub_categoria , 'OTC Payments',decode(c.servicio ,'Pago de Servicios',t.document_number,0))) as cliente_netel_otc
                     
                     
                     FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
                     LEFT JOIN RPL_TIGO_CASH.SERVICE S ON(T.SERVICE_ID=S.SERVICE_ID)
                     LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON(T.PK_CATEGORIA=C.PK_CATEGORIA)
                     WHERE T.FECHA BETWEEN DATE'2016-01-01'AND TRUNC(SYSDATE-1,'MM')-1
                     AND NOT(T.SERVICE_ID IN(4,36,46,401,402) AND T.TYPE_AUX=2)
                     AND T.RESULT !=1
                     and c.servicio in ('Ande','Pago de Servicios')
                     GROUP BY to_char(t.fecha,'YYYY-MM-DD')
                     

                     ")
df <- fetch(query)
toc()
t<-df
#summary(t)
str(t)
tiff('C:/Users/expeam/Documents/segment/2018/forecast_1_2018/correlacion_others_menu_otc.tiff', width = 35, height = 25, units = 'in', res = 200)
plot(t)
dev.off()
my_data <- t
tiff('C:/Users/expeam/Documents/segment/2018/forecast_1_2018/correlacion_others_menu_otc_1.tiff', width = 35, height = 25, units = 'in', res = 200)
chart.Correlation(my_data, histogram=FALSE, pch=10)
dev.off()
t$MONTO<-log(t$MONTO)
t$MONTO_ANDE<-log(t$MONTO_ANDE)
t$TRX_ANDE<-log(t$TRX_ANDE)
t$CLIENTE_ANDE<-log(t$CLIENTE_ANDE)
t$MONTO_NETEL<-log(t$MONTO_NETEL)
t$TRX_NETEL<-log(t$TRX_NETEL)
t$CLIENTE_NETEL<-log(t$CLIENTE_NETEL)
t$CANT_TRX<-log(t$CANT_TRX)
plot(t)
my_data <- t
chart.Correlation(my_data, histogram=TRUE, pch=19)

outlierKD(t, MONTO)
yes
t<-na.omit(t)
outlierKD(t, MONTO_ANDE)
yes
t<-na.omit(t)
outlierKD(t, TRX_ANDE)
yes
t<-na.omit(t)
outlierKD(t, CLIENTE_ANDE)
yes
t<-na.omit(t)
outlierKD(df, MONTO_NETEL)
yes
t<-na.omit(t)
outlierKD(df, TRX_NETEL)
yes
t<-na.omit(t)
outlierKD(t, CLIENTE_NETEL)
yes
t<-na.omit(t)
outlierKD(df, CANT_TRX)
yes
t<-na.omit(t)

outlierKD(t, MONTO)
yes
t<-na.omit(t)
outlierKD(t, MONTO_ANDE)
yes
t<-na.omit(t)
outlierKD(t, TRX_ANDE)
yes
t<-na.omit(t)
outlierKD(t, CLIENTE_ANDE)
yes
t<-na.omit(t)
outlierKD(df, MONTO_NETEL)
yes
t<-na.omit(t)
outlierKD(df, TRX_NETEL)
yes
t<-na.omit(t)
outlierKD(t, CLIENTE_NETEL)
yes
t<-na.omit(t)
outlierKD(df, CANT_TRX)
yes
t<-na.omit(t)



plot(t)
my_data <- t
chart.Correlation(my_data, histogram=TRUE, pch=19)

t$TICKET_CLIENTE<-cut(t$TICKET_CLIENTE,breaks = 10)
t$CANT_CLIENTE<-cut(t$CANT_CLIENTE, breaks = 10)
t$CANT_TRX<-cut(t$CANT_TRX, breaks = 10)
t$TICKET_TRX<-cut(t$TICKET_TRX,breaks = 10)
t$MONTO<-cut(t$MONTO, breaks = 2)

plot(t)

par(mfrow=c(2,2)) 

bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=RECARGA_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity", alpha=.5)+
  #geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = 0,size=1) +
  #geom_text(aes(label = round((..count../sum(..count..))*100,0)))+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="RECARGA PROMEDIO (4M)")



bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=REVENUE_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity", alpha=.5)+
  #geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = 0,size=1) +
  #geom_text(aes(label = round((..count../sum(..count..))*100,0)))+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="REVENUE PROMEDIO (4M)")


bins <- c(0,10,20,30,40,50,60,70,80,90,100)
ggplot(t,aes(fill=MOROSO,x=EDAD,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="EDAD")

bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)
ggplot(t,aes(fill=MOROSO,x=ANTIGUEDAD_CLIENTE,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  ylab(label="PORCENTAJE")+
  xlab(label="ANTIGUEDAD_CLIENTE")


bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=REVENUE_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  facet_wrap(~DEPARTAMENTO, scales = 'free_y', ncol = 2)+
  ylab(label="PORCENTAJE")+
  xlab(label="REVENUE_PROM_4M")


ggplot(t, aes(x=TOTAL_CARGA)) +
  theme_bw() +
  scale_x_continuous(breaks = pretty(t$TOTAL_CARGA, n = 10)) +
  geom_histogram(alpha=0.6, binwidth=2500) +
  ggtitle("Distribucion por TOTAL_CARGA")+
  theme(axis.text.x = element_text(angle=45))


basedate <- as.POSIXct(t$DIA,origin ="1582-10-14", tz = "GMT")
#tiff('C:/Users/edgar/Documents/analisis_envio/comparativo_var_envio_abandono_1.tiff', width = 35, height = 15, units = 'in', res = 300)
ggplot(t, aes(x=DIA,y=DATA )) +
  ggtitle("CORE Vs Envio")+
  geom_line()	+	
  scale_x_datetime(minor_breaks = basedate,breaks=pretty_breaks(n=30)) +
  facet_wrap(~TYPE+BASE, scales = 'free_y', ncol = 2)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=1)+geom_point(size=1/9)+theme(text = element_text(size=10),plot.title = element_text(hjust = 0.5))
#dev.off()




ggplot(t, aes(x= RECARGA_MENSUAL)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = -.5,size=1) +
  labs(y = "Percent", fill="day") +
  scale_y_continuous(labels = scales::percent)


ggplot(t, aes(x=RECARGA_MENSUAL,y=(..count../sum(..count..))*100, fill=MOROSO)) +
  geom_histogram(binwidth=10000, alpha=.5, position="identity")
