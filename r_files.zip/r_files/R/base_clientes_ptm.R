library(ROracle)
library(dplyr)
library(tictoc)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")
FINMES = c(
  
  "2015-01-31","2015-02-28","2015-03-31","2015-04-30"
  ,"2015-05-31","2015-06-30","2015-07-31","2015-08-31"
  ,"2015-09-30","2015-10-31","2015-11-30","2015-12-31"
  ,"2016-01-31","2016-02-29","2016-03-31","2016-04-30"
  ,"2016-05-31","2016-06-30","2016-07-31","2016-08-31"
  ,"2016-09-30","2016-10-31","2016-11-30","2016-12-31"
  ,"2017-01-31","2017-02-28","2017-03-31","2017-04-30"
  ,"2017-05-31","2017-06-30","2017-07-31","2017-08-31"
  ,"2017-09-30","2017-10-31","2017-11-30","2017-12-31"
  ,"2018-01-31"
)


## este ciclo permite obtener la base de clientes
#m.mat <- matrix(, nrow = 37, ncol = 3)
#i=1
df_ptm<-data.frame()
for (MONTH in FINMES){
 
  
## como tenemos 4 parametros, creamos un data frame con 4 parametros tambien  
FECHA_DATOS <- data.frame(FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH),FECHA_DATOS=c(MONTH))

query <- dbSendQuery(con,"
                     


                      select 
                      count( distinct a.POINT_OF_SALE) as cant_ptm
                     ,c.NAME as circuito
                      ,to_date(:5,'YYYY-MM-DD') as fecha
                      from
                     (
                      select ha.POINT_OF_SALE
                      from rpl_tigo_cash.h_transaction_movement t
                      join rpl_tigo_cash.h_agent ha on (t.SOURCE=ha.AGENT_ID and t.FECHA=ha.FECHA and ha.LEVEL_ID in (21,31,35,36,38))
                      where t.FECHA between to_date(:1,'YYYY-MM-DD')-59 and to_date(:2,'YYYY-MM-DD')
                         AND t.LEVEL_ID IN (21,31,35,36,38)
                        and t.TYPE in (0,1)
                        and t.MOVEMENT_TYPE=0 
                         union 
                      select ha.POINT_OF_SALE
                      from rpl_tigo_cash.h_transaction_movement t
                     join rpl_tigo_cash.h_agent ha on (t.DESTINY=ha.AGENT_ID and t.FECHA=ha.FECHA and ha.LEVEL_ID in (21,31,35,36,38))  
                     where t.FECHA between to_date(:3,'YYYY-MM-DD')-59 and to_date(:4,'YYYY-MM-DD')
                         AND t.LEVEL_ID IN (21,31,35,36,38)
                        and t.TYPE in (0,2)
                        and t.MOVEMENT_TYPE=0
                     ) a
                     join rpl_dms2.com_point_of_sale p
                      on (a.POINT_OF_SALE=p.ID_POINT_OF_SALE)
                     JOIN rpl_dms2.tbl_pos_circuits tpc
                     on (p.ID_POINT_OF_SALE=tpc.POS)
                     join rpl_dms2.tbl_circuits c
                     on (tpc.CIRCUIT=c.ID)
                    group by c.NAME
                     
                     
                     
                     ",data=FECHA_DATOS)



tic()
df <- fetch(query)
toc()

##aqui se insertan los datos en cada columna
# if (exists(df_ptm)) {
df_ptm<-rbind(df_ptm,df)
# } else {
#   df_ptm<-data.frame("CANT_PTM"=df$CANT_PTM,"CIRCUITO"=df$CIRCUITO,"FECHA"=df$FECHA)
# }
# m.mat[i,1]=df$CANT_PTM
# m.mat[i,2]=df$CIRCUITO
# m.mat[i,3]=MONTH

##mostramos el dato insertado en la matriz
#print(paste(m.mat[i,1]," ",m.mat[i,2]))
print(str(df_ptm))
#i=i+1

}

#m.mat
df_ptm


#cant_pdv_fecha<-as.data.frame(m.mat)
#colnames(cant_pdv_fecha)<-c("CANT_PTM","CIRCUITO","FECHA")
write.csv(df_ptm,"cant_tmp_circuito_fecha.csv")
