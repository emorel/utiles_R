debug(utils:::unpackPkgZip)
install.packages('gtable')


library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select p.ar_key as document_number
                     ,to_char(p.fct_dt_d,'yyyy-mm-dd') as fecha_datos
                     ,p.fnncl_trnsctn_val
                     from EXPEAM.base_finan_7_10_daily p
                     where p.fct_dt_d between date'2018-01-01' and date'2018-06-30'
                     and p.FNNCL_PD_SUB_TP_NM = 'Tigo Money Paquetigos'
                     and p.FNNCL_PD_NM= '300MB+15MIN+WAx7000GSx2D'                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$DOCUMENT_NUMBER))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
#colnames(df_func) <- c("cust","name")
str(df)
length(unique(df$cust))


#dfCBS <- elog2cbs(df, T.cal = "2018-05-01")
#str(dfCBS)
#head(dfCBS, 5)

####en dias
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
length(unique(dfCBS$cust))


#(nbd.EstimateParameters(subset(dfCBS,cust %in% c('0961336760')))[2]/
#    nbd.EstimateParameters(subset(dfCBS,cust %in% c('0983454819','0981662000','0984925900','0985108181','0981800993','0985484017','0981900773','0981922513','0981989591','0981404466') ))[1])



op <- par(mfrow = c(1, 2))
(k.wheat <- estimateRegularity(df, method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.mle <- estimateRegularity(df, method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)

#plotTimingPatterns(subset(df, cust %in% c('0981478782')), n = 150, T.cal = "2017-11-01",headers = c("Past", "Future"), title = "")


params.bgnbd <- BTYD::bgnbd.EstimateParameters(dfCBS) # BG/NBD
params.bgcnbd <- bgcnbd.EstimateParameters(dfCBS) # BG/CNBD-k
params.mbgnbd <- mbgnbd.EstimateParameters(dfCBS) # MBG/NBD
params.mbgcnbd <- mbgcnbd.EstimateParameters(dfCBS) # MBG/CNBD-k
row <- function(params, LL) {
  names(params) <- c("k", "r", "alpha", "a", "b")
  c(round(params, 3), LL = round(LL))
}
rbind(`BG/NBD` = row(c(1, params.bgnbd),
                     BTYD::bgnbd.cbs.LL(params.bgnbd, dfCBS)),
      `BG/CNBD-k` = row(params.bgcnbd,
                        bgcnbd.cbs.LL(params.bgcnbd, dfCBS)),
      `MBG/NBD` = row(params.mbgnbd,
                      mbgcnbd.cbs.LL(params.mbgnbd, dfCBS)),
      `MBG/CNBD-k` = row(params.mbgcnbd,
                         mbgcnbd.cbs.LL(params.mbgcnbd, dfCBS)))


# calculate expected future transactions for customers who've
# had 1 to 5 transactions in first 12 weeks, but then remained
# inactive for 40 weeks
est5.mbgcnbd <- mbgcnbd.ConditionalExpectedTransactions(params.mbgcnbd,
                T.star = 60, x = 1:5, t.x = 30, T.cal = 60)
for (i in 1:5) {
  cat("x =", i, ":", sprintf("%5.3f", est5.mbgcnbd[i]), "\n")
}




####################
##Pareto/GGG MODEL###
#####################

# estimate Pareto/GGG
tic()
pggg.draws <- pggg.mcmc.DrawParameters(dfCBS,mcmc = 200,chains = 1) # ~2mins on 2015 MacBook Pro
toc()
# generate draws for holdout period
pggg.xstar.draws <- mcmc.DrawFutureTransactions(dfCBS, pggg.draws)
# conditional expectations
dfCBS$xstar.pggg <- apply(pggg.xstar.draws, 2, mean)
# P(active)
dfCBS$pactive.pggg <- mcmc.PActive(pggg.xstar.draws)
# P(alive)
dfCBS$palive.pggg <- mcmc.PAlive(pggg.draws)
# show estimates for first few customers
head(dfCBS[, c("x", "t.x", "x.star",
               "xstar.pggg", "pactive.pggg", "palive.pggg")])
# report median cohort-level parameter estimates
round(apply(as.matrix(pggg.draws$level_2), 2, median), 3)

# report mean over median individual-level parameter estimates

median.est <- sapply(pggg.draws$level_1, function(draw) {
  apply(as.matrix(draw), 2, median)
})
round(apply(median.est, 1, mean), 3)

# compare predictions with actuals at aggregated level
rbind(`Actuals` = c(`Holdout` = sum(dfCBS$x.star)),
      `Pareto/GGG` = round(sum(dfCBS$xstar.pggg)),
      `MBG/CNBD-k` = round(sum(dfCBS$xstar.mbgcnbd)),
      `Pareto/NBD (HB)` = round(sum(dfCBS$xstar.pnbd.hb)))


# error on customer level
mae <- function(act, est) {
  stopifnot(length(act)==length(est))
  sum(abs(act-est)) / sum(act)
}
mae.pggg <- mae(dfCBS$x.star, dfCBS$xstar.pggg)
#mae.mbgcnbd <- mae(dfCBS$x.star, dfCBS$xstar.mbgcnbd)
#mae.pnbd.hb <- mae(dfCBS$x.star, dfCBS$xstar.pnbd.hb)

rbind(`Pareto/GGG` = c(`MAE` = round(mae.pggg, 3))
      #,`MBG/CNBD-k` = c(`MAE` = round(mae.mbgcnbd, 3))
      #,`Pareto/NBD (HB)` = c(`MAE` = round(mae.pnbd.hb, 3))
)

lift <- 1 - mae.pggg / mae.mbgcnbd
cat("Lift in MAE:", round(100*lift, 1), "%")

######## agregamos parametro de intertransaction time per customer

tic()
df_param=matrix(nrow = 35000,ncol = 2)
w=1
for (c in dfCBS$cust) {
  df_param[w,1]=c
  df_param[w,2]=round(nbd.EstimateParameters(subset(dfCBS,cust == c))[2]/
                        nbd.EstimateParameters(subset(dfCBS,cust == c))[1],2)
  w=w+1
}
toc()
colnames(df_param) <- c("cust","param")
df_param<-na.omit(df_param)
dfCBS<-merge(x = dfCBS, y = df_param, by = "cust", all.x = TRUE)
dfCBS$param<-as.numeric(as.character(dfCBS$param))
options(scipen = 9999)
str(dfCBS)
#dfCBS<-dfCBS[-c(14,15,16)]
############
##K-MEANS###
############

dfk<-dfCBS
##excluimos la fecha y el nro_cuenta
dfksc<-scale(dfCBS[-c(1,6,8)])

fit <- kmeans(dfksc, 5, iter.max=3000)


table(fit$cluster)



barplot(table(fit$cluster), col="maroon")

pca <- prcomp(dfksc)
pca_dat <- mutate(fortify(pca), col=fit$cluster)

ggplot(pca_dat) +
  geom_point(aes(x=PC1, y=PC2, fill=factor(col)), size=3, col="#7f7f7f", shape=21) +
  scale_fill_viridis(name="Cluster", discrete=TRUE) + theme_bw(base_family="Helvetica")

dfk$cluster<-as.factor(fit$cluster)
##agregar cluster as df
str(dfk)

###########################
##visualizar por cluster###
###########################
##para agregar el lcuster a la base original
dfkl<-merge(x = df, y = dfk[c(1,15)], by = "cust", all.x = TRUE)
##eliminamoos los clientes que no tienen cluster
#(algunos clientes se eliminan al inicio por no tener transacciones suficientes)
dfkl<-na.omit(dfkl)
length(unique(dfCBS$cust))
length(unique(dfkl$cust))
####

subset(dfk, cluster==2)[order(dfk$param),]
dfk[order(dfk$param),]

subset(dfk, param==max(subset(dfk, cluster==2)$param))

## Timing Patterns
op <- par(mfrow = c(2, 3))
p1<-plotTimingPatterns(subset(dfkl, cluster==1), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p2<-plotTimingPatterns(subset(dfkl, cluster==2), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p3<-plotTimingPatterns(subset(dfkl, cluster==3), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p4<-plotTimingPatterns(subset(dfkl, cluster==4), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p5<-plotTimingPatterns(subset(dfkl, cluster==5), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p6<-plotTimingPatterns(subset(dfkl, cluster==6), n = 150, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
p6<-plotTimingPatterns(subset(dfkl, cust==c(2943,12208)), n = 2, T.cal = "2018-04-01",headers = c("Past", "Future"), title = "")
par(op)

## Regularity
op <- par(mfrow = c(2, 3))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==1), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==2), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==3), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==4), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
(k.wheat <- estimateRegularity(subset(dfkl, cluster==5), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
#(k.wheat <- estimateRegularity(subset(dfkl, cluster==6), method = "wheat",plot = TRUE, title = "Wheat & Morrison"))
#(k.mle <- estimateRegularity(subset(dfkl, cluster==6), method = "mle",plot = TRUE, title = "Maximum Likelihood"))
par(op)

###cada cuantos dias transaccionan
subset(dfk,cust=='12208')$param
subset(dfkl,cust=='12208')
subset(dfCBS,cust=='12208')

(nbd.EstimateParameters(subset(dfk,cust=='538127'))[2]/
    nbd.EstimateParameters(subset(dfk,cust=='538127'))[1])
(nbd.EstimateParameters(subset(dfk,cluster==1))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==1))[1])
(nbd.EstimateParameters(subset(dfk,cluster==2))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==2))[1])
(nbd.EstimateParameters(subset(dfk,cluster==3))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==3))[1])
(nbd.EstimateParameters(subset(dfk,cluster==4))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==4))[1])
(nbd.EstimateParameters(subset(dfk,cluster==5))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==5))[1])
(nbd.EstimateParameters(subset(dfk,cluster==6))[2]/
    nbd.EstimateParameters(subset(dfk,cluster==6))[1])
###  BOX Plot Parametros

p1<-ggplot(data = dfk, mapping = aes(x = cluster, y = sales)) +
  geom_boxplot()
p2<-ggplot(data = dfk, mapping = aes(x = cluster, y = litt)) +
  geom_boxplot()
p3<-ggplot(data = dfk, mapping = aes(x = cluster, y = x)) +
  geom_boxplot()
p4<-ggplot(data = dfk, mapping = aes(x = cluster, y = t.x)) +
  geom_boxplot()

grid.arrange(p1,p2,p3,p4,nrow=2,ncol=2)



#facet_wrap(~cluster,nrow = 1)

#########################
## parametros de seleccion
###########################
pactive<-1
itt<-2
clust<-c(1,2,3,4,5,6)
######################
#insertamos en la base
######################
dfinsert<-dfk[c(1,15)]
str(dfinsert)


#dfinsert<-subset(dfCBS,pactive.pggg>=pactive & param<=itt & cluster %in% clust)
#length(dfinsert$cust)

#dfinsert$V2 <- chartr('.', ',', dfinsert$V2)

rs <- dbSendQuery(con, "truncate table expeam.BASE_7_10_PRE ")

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.BASE_7_10_PRE values(:1,:2)", data=dfinsert)

dbCommit(con)

write.table(dfinsert,"base_bulk_abril_2018.csv",sep = ";",row.names = FALSE)

