library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")

###################
#####servicios######
####################

query <- dbSendQuery(con,"
                     
                     
                    select distinct b.servicio
                    from tigo_cash_rpt.base_cliente_mfs_daily b
                     where b.fecha_datos between date'2018-8-1' and date'2018-8-31'
                     and b.tipo not in('from OTC')
                     and b.service_id not in (2,98,27,3002,12,1100)
                     and b.servicio not in('Envio Receptores','Transferencia Receptores','Envio App Receptores','Giros App Receptores')
                     order by 1
                     
                     
                     ")
servicios <- fetch(query)


############################
######PRIMER SERVICIO#######
############################

tic()
query <- dbSendQuery(con,"
                     
                     
                       select b.nro_cuenta
                       ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto as monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     WHERE b.fecha_datos BETWEEN DATE'2018-03-01' AND DATE'2018-08-31'
                     and b.tipo not in('from OTC')
                     and b.service_id not in (2,98,27,3002,12,1100)
                     and b.servicio not in('Envio Receptores','Transferencia Receptores','Envio App Receptores','Giros App Receptores')
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp

df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")
dfCBSl<-dfCBS[c(1)]

###############################
###Regularidad por servicio####
###############################

serv1<-servicios$SERVICIO

for (serv in serv1) {
  print(serv)
  tic()
  query <- dbSendQuery(con,"
                       
                       
                       select b.nro_cuenta
                       ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                       ,b.monto as monto
                       from tigo_cash_rpt.base_cliente_mfs_daily b
                       WHERE b.fecha_datos BETWEEN DATE'2018-03-01' AND DATE'2018-08-31'
                     and b.tipo not in('from OTC')
                     and b.service_id not in (2,98,27,3002,12,1100)
                     and b.servicio not in('Envio Receptores','Transferencia Receptores','Envio App Receptores','Giros App Receptores')

                       and b.servicio = :1
                       
                       
                       ", data=serv)
  df_bkp <- fetch(query)
  
  df<-df_bkp
  
  length(unique(df$NRO_CUENTA))
  df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
  colnames(df) <- c("cust","date","sales")
  dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")
  dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
  #cbind(dfCBSl,serv)
  dfCBSl[is.na(dfCBSl)]<-0
  toc()
}
colnames(dfCBSl) <- c("cust",servicios$SERVICIO)
## contamos, por linea,cuantas celdas contienen 0 
dfCBSl$CANT_NONZERO<-rowSums(ifelse(dfCBSl !=0,1,0))
str(dfCBSl)##469924
dfCBSl<-dfCBSl[!dfCBSl$CANT_NONZERO > 1,]
str(dfCBSl)##188695
dfCBSl<-dfCBSl[-c(ncol(dfCBSl))]
str(dfCBSl)##281229
###################################################################
####insertamos en una tabla los nombres de productos preferidos#####
###################################################################


n<- servicios$SERVICIO
ln<-length(dfCBSl$cust)
#l<-2:ncol(dfCBSl)
i<-1
#i=211
l<-as.vector(dfCBSl[i,-c(1)])
m<-c(dfCBSl[i,1],n[order(l, decreasing=TRUE)])
i=i+1
tic()
while (i<=nrow(dfCBSl)) {
  l<-as.vector(dfCBSl[i,-c(1)])
  m<-rbind(m,c(dfCBSl[i,1],n[order(l, decreasing=TRUE)]))
  print((i/ln)*100)
  i=i+1
}
toc()
m<-as.data.frame(m)
minsert<-m[c(1,2,3,4,5)]
rs <- dbSendQuery(con, "truncate table expeam.BASE_CLIENTE_PRODUCTO_PREF", data=minsert)

dbCommit(con)


rs <- dbSendQuery(con, "insert into expeam.BASE_CLIENTE_PRODUCTO_PREF values(:1,:2,:3,:4,:5,null,null,null)", data=minsert)

dbCommit(con)
