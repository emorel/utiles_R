#debug(utils:::unpackPkgZip)
#install.packages("GGally")
## modelo predictivo distribucion
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)

library(tidyverse)
library(caret)



############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                      select
                      k.circuito
                     ,count(distinct k.id_pdv) as cant_pdv
                     ,sum(k.cant_clientes) as cant_clientes
                     ,sum(k.cant_clientes_fcst) as cant_clientes_fcst
                     ,sum(k.hs_sin_saldo) as hs_sin_saldo
                     ,sum(k.hs_sin_saldo)/(13*31*count(distinct k.id_pdv)) as quiebre
                     ,sum(k.poblacion) as poblacion
                     ,sum(k.ventas) as ventas
                     from expeam.base_distrib_kpi_mapeo k
                     where k.mes = 201812
                     and k.dealer = 'ANTELL'
                     and k.zona = 'ASUNCI�N'
                     group by
                     k.circuito
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)
#str(df)
my_data <- df


options(scipen=999)
my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
#my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,CANT_CLIENTES_FCST,HS_SIN_SALDO,POBLACION,)
#my_data<-select(df,VENTAS,CANT_PDV,CANT_CLIENTES,HS_SIN_SALDO)
#my_data<-select(df,VENTAS,CANT_CLIENTES,HS_SIN_SALDO)
#my_data<-select(df,CANT_PDV,HS_SIN_SALDO)

#ggpairs(my_data, title = "Scatterplot Matrix")


#####################
#####NIVEL PAIS#####
####################
data<-my_data
telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
#telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO ,data=data)
#telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+CANT_CLIENTES_FCST+HS_SIN_SALDO+POBLACION ,data=data)
#telecomModel <- lm(VENTAS ~  CANT_CLIENTES+HS_SIN_SALDO ,data=data)
summary(telecomModel)
VIF(telecomModel)
coefficients(telecomModel)
#plot(telecomModel)

### modelo quiebre cant_pdv
telecomModel <- lm(CANT_CLIENTES ~  CANT_PDV ,data=data)
summary(telecomModel)
coefficients(telecomModel)



## segmentacion por dealer_zona
options(scipen=999)
#my_data<-na.omit(my_data)
#my_data[is.na(my_data)] <- 0
#data<-subset(my_data,DEALER_ZONA =='COMCEL - PARAGUARI')
#print(i)
#telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO+COMPRAS ,data=data)
#summary(telecomModel)
#print(coefficients(telecomModel))


for (i in sort(unique(my_data$DEALER_ZONA))) {
  data<-subset(my_data,DEALER_ZONA ==i)
  #print(i)
  telecomModel <- lm(VENTAS ~  CANT_CLIENTES+HS_SIN_SALDO ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  
  #grid.arrange(g1, g2, g3, nrow=1)  # one row
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_intervalos_confianza/confidence_interval_ventas_quiebre_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  
  #plot(telecomModel$residuals, pch = 16, col = "red")
  print(coefficients(telecomModel))
  #f <- summary(telecomModel)$fstatistic  # parameters for model p-value calc
  #model_p <- pf(f[1], f[2], f[3], lower=FALSE)
  #print(model_p)
  #print(confint(telecomModel))
}



plot(telecomModel)

anova(telecomModel)

## por dealer

for (i in sort(unique(my_data$NOMBRE_DEALER))) {
  data<-subset(my_data,NOMBRE_DEALER ==i)
  #print(i)
  telecomModel <- lm(VENTAS ~  CANT_PDV+CANT_CLIENTES+HS_SIN_SALDO+QUIEBRE ,data=data)
  #print(summary(telecomModel))
  #par(mfrow=c(2,2))
  #plot(telecomModel,main=i)
  #dev.copy(png,paste0('C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/graficos_intervalos_confianza/residuals_ventas_quiebre_dealer_',i,'.png'))   # to save the array of plots     
  #dev.off()                         # to close the device
  print(coefficients(telecomModel))
}

summary(telecomModel)



base.insertar<-my_data
dbWriteTable(con,'TMP_EPIN_QUIEBRE_SGM', base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
dbDisconnect(con)

