library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(varhandle)
library(snow)
library(ROracle)


con <- dbConnect(Oracle(), user="expeam", password="!septiembre2018", dbname="DWH/dwh_olap")
##################
######CARGA#######
##################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Carga de dinero'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")
dfCBSl<-dfCBS[c(1,4)]
colnames(dfCBSl) <- c("cust","carga")

for (i in 1:255) {
  
}
#############################
#####GIROS NACIONALES########
#############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Giros Nacionales'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3)]
colnames(dfCBSl) <- c("cust","carga","giro")

dfCBSl[is.na(dfCBSl)]<-0

#########################
#####TRANSFERENCIA#######
#########################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Transferencia'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia")

dfCBSl[is.na(dfCBSl)]<-0


###################
#####MINICARGA######
####################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Minicarga'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga")

dfCBSl[is.na(dfCBSl)]<-0

###########################
#####RECEPTOR GIRO########
##########################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Giros Nacionales Receptores'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro")

dfCBSl[is.na(dfCBSl)]<-0


###################################
#####RECEPTOR TRANSFERENCIA########
####################################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Transferencia Receptores'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia")

dfCBSl[is.na(dfCBSl)]<-0

##############################
#####COBRO DE FACTURAS########
##############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                      join expeam.base_mfs_servicio_preferido p
                      on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Cobro de facturas'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7,8)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura")

dfCBSl[is.na(dfCBSl)]<-0




############################
#####Pago de Salarios#######
############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.base_mfs_servicio_preferido p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Pago de Salarios'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7,8,9)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura","pago_salario")

dfCBSl[is.na(dfCBSl)]<-0




############################
#####Retiro de dinero#######
############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.base_mfs_servicio_preferido p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Retiro de dinero'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7,8,9,10)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura","pago_salario","retiro_dinero")

dfCBSl[is.na(dfCBSl)]<-0




############################
#####Pago de marcaderia#####
############################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.base_mfs_servicio_preferido p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Pago Mercad.'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7,8,9,10,11)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura","pago_salario","retiro_dinero","pago_comercio")

dfCBSl[is.na(dfCBSl)]<-0


#############################################
#####Retiro de dinero con pin incluido#######
############################################

tic()
query <- dbSendQuery(con,"
                     
                     
                     select b.nro_cuenta
                     ,to_char(b.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     ,b.monto
                     from tigo_cash_rpt.base_cliente_mfs_daily b
                     join expeam.base_mfs_servicio_preferido p
                     on (b.nro_cuenta=p.nro_cuenta)
                     where b.fecha_datos between date'2018-01-01' and date'2018-08-31'
                     and b.servicio = 'Retiro de dinero con PIN incl'
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$NRO_CUENTA))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
#set.seed(123)
colnames(df) <- c("cust","date","sales")
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-07-01")


dfCBSl<-merge(x = dfCBSl, y = dfCBS[c(1,4)], by = "cust",all.x = TRUE)
dfCBSl<-dfCBSl[c(1,2,3,4,5,6,7,8,9,10,11,12)]
colnames(dfCBSl) <- c("cust","carga","giro","transferencia","minicarga","receptor_giro","receptor_transferencia","cobro_factura","pago_salario","retiro_dinero","pago_comercio","retiro_atm")

dfCBSl[is.na(dfCBSl)]<-0


