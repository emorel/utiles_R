library(ROracle)
library(dplyr)
library(ggplot2)
library(reshape2)
library(scales)
library(xts)
library(TTR)
library(lubridate)
library(ggseas)
drv<- dbDriver("Oracle")
con <- dbConnect(Oracle(), user="expeam", password="!junio2018", dbname="DWH")
query <- dbSendQuery(con,"
                     
                     /*select c.cantidad_num as \"values\"
                     ,to_char(c.fechadatos_dat,'YYYY/MM/DD') as \"date\"
                     from expeam.res_base_mfs_dai_ci_60 c
                     where c.fechadatos_dat BETWEEN DATE'2016-01-01' AND DATE'2017-07-30'
                     and c.indicator_chr = 'Begining Day'*/

                    select sum(p.monto) as \"values\"
                    ,to_char(p.fecha_datos,'YYYY/MM/DD') as \"date\"
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between DATE'2017-01-01' AND DATE'2018-06-09'
                     --and p.servicio like '%inicarga%'
                      and p.servicio in ('Carga de dinero','Giros Nacionales')
                      group by to_char(p.fecha_datos,'YYYY/MM/DD')
                     
                     ")


result <- fetch(query)
df <- result
str(df)


dfs <- xts(df$date, as.Date(df$date, format='%Y/%m/%d'))

dfs <- ts(df$values, start = decimal_date(as.Date("2017-01-01")), frequency = 7)

plot.ts(dfs)

dfts <- ts(dfs)
plot(SMA(dfts,n=30))
dfts = ts(dfs, start=c(2018, yday("2018-01-01")), frequency=7)
dftsdc<-decompose(dfts)
plot(dftsdc)
plot(dfts-dftsdc$trend)
plot(dfts-dftsdc$seasonal)
plot(dfts-dftsdc$random)


dfts <- msts(dfs, seasonal.periods=c(7,365.25))
fit <- tbats(dfts)
fc <- forecast(fit)
plot(fc)


dftsH<- HoltWinters(dfts,gamma=FALSE)

#HoltWinters(dfts, gamma=FALSE, l.start=1147700, b.start=-1980)

dftsHfcst <- forecast.HoltWinters(dftsH, h=19)
plot(dftsHfcst)

