
library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(DataCombine)

###########################
############################

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     select
                     b.circuito
                     ,b.id_pdv
                     --,b.zona
                     --,sum(b.cant_clientes)/count(distinct b.id_pdv) as capilaridad
                     --,sum(b.poblacion-b.cant_clientes)/nullif(sum(case when p.id_pdv is null then 0 else 1 end),0) as oportunidad
                     ,sum(b.cant_clientes) as cant_clientes
                     --,count(distinct b.id_pdv) as cantidad_pdv
                     ,sum(b.poblacion) as poblacion
                     --,sum(b.hs_sin_saldo)/(13*31*count(distinct b.id_pdv)) as quiebre
                     --,sum(b.hs_sin_saldo)/(13*31*1) as quiebre
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                     ,sum(b.ventas) as ventas
                     ,sum(b.compras) as compras
                     ,sum(b.ventas)/NULLIF(sum(b.cant_clientes),0) AS ARPU_CLIENTE
                     --,b.mes
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes = 201812
                     and b.id_pdv in (select id_pdv from expeam.base_pdv_5_meses)
                     and b.circuito in (select p.circuito from  expeam.base_circuito_3_pdv p)
                     --and b.zona = 'ITAP�A'
                     --and b.circuito not in ('ZK000087')
                     group by 
                     b.id_pdv
                     --,b.mes
                     ,b.circuito
                     --,b.zona
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)


library(DMwR)
tic()
df <- knnImputation(select(df,-CIRCUITO,-ID_PDV),k=3)
toc()
anyNA(df)

df$CIRCUITO <- df_bkp$CIRCUITO
df$ID_PDV <- df_bkp$ID_PDV

df<-select (df,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION)

fun <- function(x) (trunc(x,0))
df<-mutate_if(df,is.numeric,fun)
##########################################
###########cut por circuito###############
##########################################


#########################################
#############ARPU_CLIENTE#############
##########################################

#data1<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data1<-subset(df,df$CIRCUITO =='ZK000087')
breaks<-quantile(data1$ARPU_CLIENTE,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-10000000
breaks[4]=breaks[4]+10000000
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data1$ARPU_CLIENTE_C,n=breaks)[2])[,1]
data1$ARPU_CLIENTE_SGM<- cut( data1$ARPU_CLIENTE, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data1$ARPU_CLIENTE_SGM)

data1<-data1[0,]

tic()
for (i in sort(unique(df$CIRCUITO))) {
  data2<-subset(df,df$CIRCUITO ==i)
  #print(i)
  breaks<-quantile(data2$ARPU_CLIENTE,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
  data2$ARPU_CLIENTE_SGM<- cut( data2$ARPU_CLIENTE, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data1<-rbind(data1,data2)
}
toc()



#########################################
#############HS_SIN_SALDO#############
##########################################

#data2<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data3<-subset(df,df$CIRCUITO =='ZK000087')
breaks<-quantile(data3$HS_SIN_SALDO,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-10000000
breaks[4]=breaks[4]+10000000
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data2$HS_SIN_SALDO_C,n=breaks)[2])[,1]
data3$HS_SIN_SALDO_SGM<- cut( data3$HS_SIN_SALDO, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data3$HS_SIN_SALDO_SGM)

data3<-data3[0,]

tic()
for (i in sort(unique(df$CIRCUITO))) {
  data4<-subset(df,df$CIRCUITO ==i)
  #print(i)
  breaks<-quantile(data4$HS_SIN_SALDO,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
  data4$HS_SIN_SALDO_SGM<- cut( data4$HS_SIN_SALDO, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data3<-rbind(data3,data4)
}
toc()

#########################################
#############CANT_CLIENTES#############
##########################################

#data3<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data5<-subset(df,df$CIRCUITO =='ZK000087')
breaks<-quantile(data5$CANT_CLIENTES,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-10000000
breaks[4]=breaks[4]+10000000
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data3$CANT_CLIENTES_C,n=breaks)[2])[,1]
data5$CANT_CLIENTES_SGM<- cut( data5$CANT_CLIENTES, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data5$CANT_CLIENTES_SGM)

data5<-data5[0,]

tic()
for (i in sort(unique(df$CIRCUITO))) {
  data6<-subset(df,df$CIRCUITO ==i)
  #print(i)
  breaks<-quantile(data6$CANT_CLIENTES,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
  data6$CANT_CLIENTES_SGM<- cut( data6$CANT_CLIENTES, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data5<-rbind(data5,data6)
}
toc()

#########################################
#############POBLACION#############
##########################################

#data4<-subset(df_coef_totales,df_coef_totales$CIRCUITO =='ZS000013')
data7<-subset(df,df$CIRCUITO =='ZK000087')
breaks<-quantile(data7$POBLACION,c(0,1/3,2/3,1))
breaks[1]=breaks[1]-10000000
breaks[4]=breaks[4]+10000000
mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
#breaks<-data.frame(classIntervals(data4$POBLACION_C,n=breaks)[2])[,1]
data7$POBLACION_SGM<- cut( data7$POBLACION, breaks = unique(breaks),dig.lab=7,ordered_result = FALSE,labels = mylabels)
table(data7$POBLACION_SGM)

data7<-data7[0,]

tic()
for (i in sort(unique(df$CIRCUITO))) {
  data8<-subset(df,df$CIRCUITO ==i)
  #print(i)
  breaks<-quantile(data8$POBLACION,c(0,1/3,2/3,1))
  breaks[1]=breaks[1]-10000000
  breaks[4]=breaks[4]+10000000
  mylabels<-c("1.-BAJO","2.-MEDIO","3.-ALTO")
  data8$POBLACION_SGM<- cut( data8$POBLACION, breaks = breaks,dig.lab=7,ordered_result = FALSE,labels = mylabels)
  data7<-rbind(data7,data8)
}
toc()


df_sgm<-merge(select(data1,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION,ARPU_CLIENTE_SGM),select(data3,ID_PDV,HS_SIN_SALDO_SGM),by="ID_PDV",all.x=TRUE,no.dups = FALSE)

df_sgm<-merge(select(df_sgm,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION,ARPU_CLIENTE_SGM,HS_SIN_SALDO_SGM),select(data5,ID_PDV,CANT_CLIENTES_SGM),by="ID_PDV",all.x=TRUE,no.dups = FALSE)

df_sgm<-merge(select(df_sgm,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION,ARPU_CLIENTE_SGM,HS_SIN_SALDO_SGM,CANT_CLIENTES_SGM),select(data7,ID_PDV,POBLACION_SGM),by="ID_PDV",all.x=TRUE,no.dups = FALSE)

df_sgm<-select (df_sgm,CIRCUITO,ID_PDV,ARPU_CLIENTE,HS_SIN_SALDO,CANT_CLIENTES,POBLACION,ARPU_CLIENTE_SGM,HS_SIN_SALDO_SGM,CANT_CLIENTES_SGM,POBLACION_SGM)

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
dbWriteTable(con,"TMP_PDV_KPI_SGM", df_sgm, overwrite = TRUE, append = FALSE)
dbDisconnect(con)
