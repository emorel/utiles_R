debug(utils:::unpackPkgZip)
install.packages('e1071')
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggfortify)
library(IDPmisc)
library(e1071)

library(readxl)
base_modelo_cc <- read_excel("segment/2018/febrero/base_modelo_cc_1.xlsx")
df<-base_modelo_cc

df<-scale(df[-c(1)])
#df<-apply(df[-c(1)],2,function(x) log(x) )

#df[is.infinite(df)]<-0

df<-as.data.frame(df)
df$DOCUMENT_NUMBER<-base_modelo_cc$DOCUMENT_NUMBER
str(df)
#df<-NaRV.omit(df)
#df<-na.omit(df)





 outlierKD(df, MONTO_RETIRO_OTC)
 yes
 df<-na.omit(df)
 outlierKD(df, MONTO_COMPRA_CC)
 yes
 df<-na.omit(df)
 outlierKD(df, MONTO_RETIRO_CC)
 yes
 df<-na.omit(df)
 outlierKD(df, RATIO_TRX_RETIRO_OTC)
 yes
 df<-na.omit(df)
 outlierKD(df, RATIO_TRX_COMPRA_CC)
 yes
 df<-na.omit(df)
 outlierKD(df, RATIO_TRX_RETIRO_CC)
 yes
 df<-na.omit(df)



dat<-df
str(df)

fit <- kmeans(dat[,c(-7)],3, iter.max=3000)


table(fit$cluster)



barplot(table(fit$cluster), col="maroon")

pca <- prcomp(dat[,c(-7)])
pca_dat <- mutate(fortify(pca), col=fit$cluster)
ggplot(pca_dat) +
  geom_point(aes(x=PC1, y=PC2, fill=factor(col)), size=3, col="#7f7f7f", shape=21) +
  scale_fill_viridis(name="Cluster", discrete=TRUE) + theme_bw(base_family="Helvetica")

autoplot(fit, data=dat[,c(-7)], frame=TRUE, frame.type='norm')


dat$cluster<-fit$cluster

summary(subset(dat,cluster==1))
summary(subset(dat,cluster==2))
summary(subset(dat,cluster==3))
summary(subset(dat,cluster==4))

## permite convertir a un formato largo para graficar con ggplot
dat.long<-gather(dat[c(-7)],key,value,-cluster)
ggplot(dat.long,aes(x=key,y=value))+
  geom_boxplot()+
  facet_grid(.~cluster)+
  theme(axis.text.x = element_text(angle = 90,size = 7))
