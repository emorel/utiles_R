# Install
#debug(utils:::unpackPkgZip)
#install.packages("psych")

library(psych) #necessary whenever you want to run functions in the psych package
#file.name <- file.choose()
#file.name <- "http://personality-project.org/r/psych/HowTo/scoring.tutorial/small.msq.txt"
#my.data <- read.table(file.name)

library(ROracle)
library(stats)
library(caTools)
library(Amelia)
library(dplyr)
library(tictoc)
con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")
query <- dbSendQuery(con,
                     "

                  
                      SELECT
                      PUNTO_DMS
                     ,HORAS_QUIEBRE
                     ,QUIEBRE
                     ,CANT_CLIENTES_PDV
                     ,PROMEDIO2018
                     ,PROMEDIO_S2
                     ,CANT_MES_ANHO
                     ,CANT_MES_S2
                     ,CARGA_S2
                     ,GIRO_S2
                     ,RETIRO_S2
                     from expeam.tmp_base_modelo_ptm_18
                     
                     ")
dfa <- fetch(query)

df<-dfa
summary(df)
str(df)
df.scale <-as.data.frame(scale(df[-c(1)]))
df.scale$sum<-rowSums(df.scale)
df$SCORE<-df.scale$sum

df.pareto<-subset(df,SCORE > 10)

write.table(df,"C:/Users/expeam/Documents/segment/2019/02-febrero/modelo_ptm/base_ptm.csv",sep = ";",row.names = FALSE)
