
library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(dplyr)
library(scales)
library(ggplot2)
library(reshape2)
library(data.table)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!marzo2019", dbname="DWH/dwh_olap")



tic()
query <- dbSendQuery(con,"
                     
                     
                     
select *
from expeam.tmp_kpi_tg_CLU_pqext t
where t.fct_dt between date'2019-01-01' and date'2019-03-20'
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp
dbDisconnect(con)


str(df)

df$FCT_DT<-as.Date(fasttime::fastPOSIXct(format(df$FCT_DT)))



tail(df)



ggplot(df,aes(x=FCT_DT,y=MB_DATA/NRO_SUBS, group=TIPO_BASE))+
  geom_line(aes(colour= factor(TIPO_BASE)))+
  scale_x_date(breaks = pretty_breaks(n=5))+
  facet_wrap(~NRO_CLUSTER,scales = "free_x",nrow=1,ncol=5)+
  theme(axis.text.x = element_text(angle = 45))+
  #geom_smooth(span=0.5,method='loess',size=0.5)+
  geom_smooth(aes(colour= factor(TIPO_BASE)),span=1)+
  #geom_point(size=1,color="blue")+
  theme(text=element_text(size=10))+
  labs(title="MB DATA por cliente (TARGET = PQ Extendidos, CONTROL = PQ Diarios)",x= "Fecha",y="",color = "BASE")

ggplot(df,aes(x=FCT_DT,y=TOTAL_REV/NRO_SUBS, group=TIPO_BASE))+
  geom_line(aes(colour= factor(TIPO_BASE)))+
  scale_x_date(breaks = pretty_breaks(n=5))+
  facet_wrap(~NRO_CLUSTER,scales = "free_x",nrow=1,ncol=5)+
  theme(axis.text.x = element_text(angle = 45))+
  #geom_smooth(span=0.5,method='loess',size=0.5)+
  geom_smooth(aes(colour= factor(TIPO_BASE)),span=1)+
  #geom_point(size=1,color="blue")+
  theme(text=element_text(size=10))+
  labs(title="TOTAL REVENUE por cliente (TARGET = PQ Extendidos, CONTROL = PQ Diarios)",x= "Fecha",y="",color = "BASE")

ggplot(df,aes(x=FCT_DT,y=DATA_REV/NRO_SUBS, group=TIPO_BASE))+
  geom_line(aes(colour= factor(TIPO_BASE)))+
  scale_x_date(breaks = pretty_breaks(n=5))+
  facet_wrap(~NRO_CLUSTER,scales = "free_x",nrow=1,ncol=5)+
  theme(axis.text.x = element_text(angle = 45))+
  #geom_smooth(span=0.5,method='loess',size=0.5)+
  geom_smooth(aes(colour= factor(TIPO_BASE)),span=1)+
  #geom_point(size=1,color="blue")+
  theme(text=element_text(size=10))+
  labs(title="DATA REVENUE por cliente (TARGET = PQ Extendidos, CONTROL = PQ Diarios)",x= "Fecha",y="",color = "BASE")

#dev.off()