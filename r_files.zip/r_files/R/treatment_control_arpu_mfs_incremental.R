

library(BTYDplus)
library(BTYD)
library(reshape2)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!july2018", dbname="DWH/dwh_olap")

tic()
query <- dbSendQuery(con,"
                     
                     
                     select *
                     from expeam.tmp_pqtm_1
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$DOCUMENT_NUMBER))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
df<-subset(df,cust %in%(sample(df$cust,size = 5000)))
length(unique(df$cust))
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
length(unique(dfCBS$cust))
length(dfCBS$cust)



###########################
#Propensity Score Matching#
########RMatchit###########
###########################
dfCBS_1<-dfCBS
dfCBS_1$treat<-1


tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select *
                     from expeam.tmp_pqtm_00
                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df<-df_bkp


length(unique(df$DOCUMENT_NUMBER))
df$FECHA_DATOS <- as.Date(df$FECHA_DATOS,  "%Y-%m-%d")
colnames(df) <- c("cust","date","sales")
df<-subset(df,cust %in%(sample(df$cust,size = 20000)))
length(unique(df$cust))

####en dias
dfCBS <- elog2cbs(df,units = 'day' ,T.cal = "2018-05-01")
length(unique(dfCBS$cust))
length(dfCBS$cust)

###########################
#Propensity Score Matching#
########RMatchit###########
###########################
dfCBS_2<-dfCBS
dfCBS_2$treat<-0




dfCBS_t<-rbind(dfCBS_1,dfCBS_2)
dfCBS_t$treat<-as.factor(dfCBS_t$treat)

m.out<- matchit(treat~x+t.x+litt+sales+T.cal+x.star+sales.star
                ,data=dfCBS_t,method = "nearest",ratio=1)
summary(m.out)
#plot(m.out,type = "jitter")
plot(m.out,type = "hist")

dfCBS_matched<-match.data(m.out)

####################
###ARP Incremental##
###################

base.insertar <-(subset(dfCBS_matched,treat == 1))$cust
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)


tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select sum(ar.revenue)/count(distinct ar.nro_cuenta) as arpu
                      from expeam.product_tracking_rev_mensual ar
                     where
                     --ar.AR_KEY in
                     ar.nro_cuenta in
                     (
                     select  t.document_number
                     from expeam.tmp_ci_app_ussd t
                     )
                     and ar.fecha_datos = last_day(date'2018-06-01')
                     
                     
                     
                     ")
arpu1 <- fetch(query)
toc()

base.insertar <-(subset(dfCBS_matched,treat == 0))$cust
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(:1)", data=base.insertar)
dbCommit(con)


tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select sum(ar.revenue)/count(distinct ar.nro_cuenta) as arpu
                     from expeam.product_tracking_rev_mensual ar
                     where
                     --ar.AR_KEY in
                     ar.nro_cuenta in
                     (
                     select  t.document_number
                     from expeam.tmp_ci_app_ussd t
                     )
                     and ar.fecha_datos = last_day(date'2018-06-01')
                     
                     
                     
                     ")
arpu0 <- fetch(query)
toc()


arpu1$ARPU-arpu0$ARPU

#write.table(dfCBS_matched,"C:/Users/expeam/Documents/segment/2018/junio/oferta_prepago/paquetones_treatment_control_1.csv",sep = ";",row.names = FALSE,)
