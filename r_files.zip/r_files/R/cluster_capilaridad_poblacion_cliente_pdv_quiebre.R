
debug(utils:::unpackPkgZip)
#devtools::install_github("dgrtwo/gganimate")
install.packages("sqldf")


library("PerformanceAnalytics")


library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)
library(rcompanion)
library(classInt)
library(lpSolveAPI)
library(ensembleBMA)
library(regclass)
library(Metrics)
library(corrplot)
library(GGally)
library(classInt)
library(naniar)
library(Epicalc)
library(sqldf)


library(tidyverse)
library(cluster)
library(factoextra)
library(caret)


## FUNCION ELIMINAR OUTLIERS
outlierKD <- function(dt, var) {
  var_name <- eval(substitute(var),eval(dt))
  na1 <- sum(is.na(var_name))
  m1 <- mean(var_name, na.rm = T)
  par(mfrow=c(2, 2), oma=c(0,0,3,0))
  #boxplot(var_name, main="With outliers")
  #hist(var_name, main="With outliers", xlab=NA, ylab=NA)
  outlier <- boxplot.stats(var_name)$out
  mo <- mean(outlier)
  var_name <- ifelse(var_name %in% outlier, NA, var_name)
  #boxplot(var_name, main="Without outliers")
  #hist(var_name, main="Without outliers", xlab=NA, ylab=NA)
  #title("Outlier Check", outer=TRUE)
  na2 <- sum(is.na(var_name))
  cat("Outliers identified:", na2 - na1, "n")
  cat("Propotion (%) of outliers:", round((na2 - na1) / sum(!is.na(var_name))*100, 1), "n")
  cat("Mean of the outliers:", round(mo, 2), "n")
  m2 <- mean(var_name, na.rm = T)
  cat("Mean without removing outliers:", round(m1, 2), "n")
  cat("Mean if we remove outliers:", round(m2, 2), "n")
  #response <- readline(prompt="Do you want to remove outliers and to replace with NA? [yes/no]: ")
  #if(response == "y" | response == "yes"){
  dt[as.character(substitute(var))] <- invisible(var_name)
  assign(as.character(as.list(match.call())$dt), dt, envir = .GlobalEnv)
  cat("Outliers successfully removed", "n")
  return(invisible(dt))
  #} else{
  #     cat("Nothing changed", "n")
  #     return(invisible(var_name))
  #}
}


############################
############################

con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                     select
                     b.id_pdv
                     ,b.circuito
                     --,sum(b.cant_clientes)/count(distinct b.id_pdv) as capilaridad
                     --,sum(b.poblacion-b.cant_clientes)/nullif(sum(case when p.id_pdv is null then 0 else 1 end),0) as oportunidad
                     ,sum(b.cant_clientes) as cant_clientes
                     --,count(distinct b.id_pdv) as cantidad_pdv
                     --,sum(b.poblacion) as poblacion
                     --,sum(b.hs_sin_saldo)/(13*31*count(distinct b.id_pdv)) as quiebre
                     --,sum(b.hs_sin_saldo)/(13*31*1) as quiebre
                     ,sum(b.ventas) as ventas
                     ,sum(b.hs_sin_saldo) as hs_sin_saldo
                     from expeam.base_distrib_kpi_mapeo b
                     left join rpt_bo.pda_pdv_dms p on (b.id_pdv = p.id_pdv)
                     where b.mes in (201812)
                     --and b.zona = 'ITAP�A'
                     --and b.circuito = 'ZAA000001'
                     group by 
                     b.id_pdv
                     ,b.circuito
                     
                     
                     ")
df_bkp<- fetch(query)
toc()
dbDisconnect(con)
##########################

df<-df_bkp

#df<-base_circuito_variacion
#df<-na.omit(df)
summary(df)
str(df)

library(naniar)
vis_miss(df)

## insertamos NA en vez de ceros para imputarlos con KNN
df$CANT_CLIENTES<-ifelse(df$CANT_CLIENTES==0,NA,df$CANT_CLIENTES)
#df$QUIEBRE<-ifelse(df$QUIEBRE==0,NA,df$QUIEBRE)
df$VENTAS<-ifelse(df$VENTAS==0,NA,df$VENTAS)
df$HS_SIN_SALDO<-ifelse(df$HS_SIN_SALDO==0,NA,df$HS_SIN_SALDO)

#df$REVENUE_MFS<-ifelse(df$REVENUE_MFS<0,0,df$REVENUE_MFS)
#df$MONTO_MFS<-ifelse(df$MONTO_MFS<0,0,df$MONTO_MFS)
#df$ARPU_MOBILE<-ifelse(df$ARPU_MOBILE<0,0,df$ARPU_MOBILE)

#summary(df)
##seleccionamos solo las columnas pertinentes
df<-select (df,-ID_PDV,-ZONA,-CIRCUITO)

##################################
#for (i in 1:10) {
#  outlierKD(df, CANTIDAD_PDV)
#}
##################################
#for (i in 1:10) {
#  outlierKD(df, POBLACION)
#}
##################################
#for (i in 1:10) {
#  outlierKD(df, QUIEBRE)
#}
#################################
###  marcamos  outliers con NA
for (i in 1:10) {
  outlierKD(df, CANT_CLIENTES)
}
##################################
for (i in 1:10) {
  outlierKD(df, VENTAS)
}
##################################
for (i in 1:10) {
  outlierKD(df, HS_SIN_SALDO)
}
####reemplazo de outliers con KNN##
library(DMwR)
df <- knnImputation(df,k=100)
anyNA(df)


##################################
summary(select (df_bkp,CANT_CLIENTES,VENTAS,HS_SIN_SALDO))
summary(df)


##################################
##volvemos a agregarla primera columna de las etiquetas de circuito

df$CIRCUITO<-df_bkp$CIRCUITO
df$ZONA<-df_bkp$ZONA
df$ID_PDV<-df_bkp$ID_PDV

df<-select(df,ID_PDV,CIRCUITO,ZONA,CANT_CLIENTES,HS_SIN_SALDO,VENTAS)

###################
df<-na.omit(df)
##################

# 
boxplot(df$CANT_CLIENTES,main="CANT_CLIENTES")
#boxplot(df$QUIEBRE,main="QUIEBRE")
boxplot(df$VENTAS,main="VENTAS")
boxplot(df$HS_SIN_SALDO,main="HS_SIN_SALDO")
# boxplot(df$CANTIDAD_PDV,main="CANTIDAD_PDV")
# boxplot(df$POBLACION,main="POBLACION")




#KMEANS
##saber cuantos clusters
##################################
mydata<-select(df,CANT_CLIENTES,VENTAS,HS_SIN_SALDO)
mydata<-scale(mydata)
##################################
# wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var))
# for (i in 2:15) wss[i] <- sum(kmeans(mydata, 
#                                      centers=i)$withinss)
# plot(1:15, wss, type="b", xlab="Number of Clusters",
#      ylab="Within groups sum of squares")

fit <- kmeans(mydata, 6) # 5 cluster solution
#fviz_cluster(fit,data=mydata)
# get cluster means 
#aggregate(mydata,by=list(fit$cluster),FUN=median)
#aggregate(mydata,by=list(fit$cluster),FUN=length)
# append cluster assignment
df$CLUSTER <- fit$cluster
#aggregate(select(df,CANT_CLIENTES,CANTIDAD_PDV,POBLACION),by=list(fit$cluster),FUN=median)
#aggregate(select(df,CANT_CLIENTES,CANTIDAD_PDV,POBLACION),by=list(fit$cluster),FUN=length)

# df$TIPO<-ifelse(df$CLUSTER==3,'VERY LOW'
#         ,ifelse(df$CLUSTER==5,'LOW'
#         ,ifelse(df$CLUSTER==4,'MEDIUM'
#         ,ifelse(df$CLUSTER==1,'HIGH'
#         ,ifelse(df$CLUSTER==2,'VERY HIGH','TBD')))))

#df$CANT_CLIENTES_GROUP<-ifelse(df$CLUSTER_CANT_CLIENTES==1,"=",ifelse(df$CLUSTER_CANT_CLIENTES==2,"-","+"))

##########################
#write.table(df,"C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/kpi/base_circuito_variacion_cluster.csv",row.names = FALSE,sep = ";")
#str(df)
#colnames(df)<-c("GRUPO_CIRCUITO_VENTA","CANT_PDV_GROUP")


df$CLUSTER<-as.factor(df$CLUSTER)
str(df)

dfcircuito<-'ZAA000001'
dfcircuito<-'ZD000016'

ggplot(filter(df,CIRCUITO==dfcircuito),
       aes(x     = CANT_CLIENTES, 
           y     = VENTAS,
           color = CLUSTER,
           size = HS_SIN_SALDO/(13*31))) +
  geom_point(size=3) +
  geom_jitter(width = 0.4, height = 0.4) +
  labs(color="CLUSTER", size="QUIEBRE")+
  theme_bw()

##cluster4 
aggregate(select(filter(df,CIRCUITO==dfcircuito),CANT_CLIENTES,VENTAS,HS_SIN_SALDO),by=list(fit$cluster),FUN=median)

# #make bubble chart
# ggplot(df, aes(x = CANT_CLIENTES, y = CANTIDAD_PDV)) +
#   xlab("Cantidad de clientes") +
#   ylab("Cantidad de PDV") +
#   theme_minimal(base_size = 12, base_family = "Georgia") +
#   geom_point(aes(size = QUIEBRE, color = CLUSTER), alpha = 0.7) +
#   #scale_size_area(guide = FALSE, max_size = 5) +
#   #scale_x_continuous(labels = dollar) +
#   #stat_smooth(formula = y ~ log10(x), se = FALSE, size = 0.5, color = "black", linetype="dotted") +
#   scale_color_brewer(name = "", palette = "Set2")+
#   geom_smooth()+
#   labs(color="CLUSTER", size="QUIEBRE")
# #+theme(legend.position=c(0.8,0.4))



#base.insertar<-select (df,CIRCUITO,TIPO)
#base.insertar<-df
# con <- dbConnect(Oracle(), user="expeam", password="!abril2019", dbname="DWH/dwh_olap")
# dbWriteTable(con,"TMP_CLUSTER_CIRCUITO", base.insertar, rownames=FALSE, overwrite = TRUE, append = FALSE)
# dbDisconnect(con)

write.table(filter(df,ZONA==dfzona),paste0("C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/framework/optimos/cluster_","_",dfzona,".csv"),row.names = FALSE,sep = ";")


cluster.optimo<-4
df.pdv.optimos<-filter(df,CLUSTER ==cluster.optimo)



#summary(filter(df,CIRCUITO =='ZI000045'))

summary(filter(df.pdv.optimos,CIRCUITO =='ZI000045'))



#aggregate(select(df.pdv.optimos,CANT_CLIENTES,VENTAS,HS_SIN_SALDO),by=list(df.pdv.optimos$CLUSTER),FUN = mean)



df.pdv.optimos.insert<-sqldf("SELECT 
                             CIRCUITO
                             ,AVG(CANT_CLIENTES) CANT_CLIENTES
                             ,AVG(VENTAS) VENTAS
                             ,AVG(HS_SIN_SALDO) HS_SIN_SALDO
                             ,COUNT(*) as CANT_PDV
                             FROM \"df.pdv.optimos\"
                             GROUP BY CIRCUITO
                             ORDER BY 1")


filter(df.pdv.optimos.insert,CIRCUITO =='ZI000045')


write.table(df.pdv.optimos,"C:/Users/expeam/Documents/BI/2019/02-febrero/quiebre_ventas_epin/framework/optimos/optimos_circuito.csv",row.names = FALSE,sep = ";")





for (z in sort(unique(df$CIRCUITO))) {
  dfcircuito<-z
  opt.val<-filter(aggregate(select(filter(df,CIRCUITO==dfcircuito),CANT_CLIENTES,VENTAS,HS_SIN_SALDO),by=list(filter(df,CIRCUITO==dfcircuito)$CLUSTER),FUN=median),Group.1==cluster.optimo)
  print(paste(z,opt.val$CANT_CLIENTES,opt.val$VENTAS,opt.val$HS_SIN_SALDO,sep = ";"))
}


