
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(ROracle)
library(tictoc)
library(gridExtra)
library(grid)


con <- dbConnect(Oracle(), user="expeam", password="!diciembre2018", dbname="DWH/dwh_olap")
tic()
query <- dbSendQuery(con,"
                     
                     
                     
                      select hora
                      ,median(monto)/1000 as monto
                     ,'MONTO PROMEDIO' as tipo
                     from
                     (
                     select to_char(t.TS_TRANSACTION,'yyyymmddhh24') as fechahora
                     ,to_char(t.TS_TRANSACTION,'hh24') as hora
                     ,count(t.TRANSACTION_ID) as monto
                     from rpl_tigo_cash.transaction t
                     where t.FECHA >= trunc(sysdate-400)
                     group by 
                     to_char(t.TS_TRANSACTION,'yyyymmddhh24')
                     ,to_char(t.TS_TRANSACTION,'hh24')
                     )
                     group by hora
        
                     
                     ")
df_bkp <- fetch(query)
toc()
dfa1<-df_bkp



p <- list()

f<-seq(as.Date("2018/12/08"), as.Date("2018/12/16"), "days")

fc<-as.character(f)

for (i in 1:9)
{
    tic()
    query <- dbSendQuery(con,"
                         
                         
                         
                         select to_char(t.TS_TRANSACTION,'hh24') as hora
                         ,count(t.TRANSACTION_ID)/1000 as monto
                         ,'MONTO ACTUAL' as tipo
                         from rpl_tigo_cash.transaction t
                         where t.FECHA = to_date(:1,'yyyy-mm-dd')
                         group by 
                         to_char(t.TS_TRANSACTION,'hh24')
                         order by 3,1
                         
                         ",data=fc[i])
    
    df_bkp <- fetch(query)
    toc()
    dfa2<-df_bkp
    
    dfa<-rbind(dfa1,dfa2)
    

    p[[i]] <-ggplot(dfa,aes(HORA, MONTO, fill=TIPO,alpha=TIPO))+
      geom_bar(stat = "identity",position ="identity")+
      #scale_x_date(breaks=pretty_breaks(n=56))+
      scale_colour_manual(values=c("blue","grey")) +
      scale_fill_manual(values=c("blue","grey")) +
      scale_alpha_manual(values=c(.3, .9))+
      xlab("HORA")+ 
      ylab("CANT TRX (K)")+
      theme(axis.text.x = element_text(angle=0,size = 20),axis.text.y = element_text(angle=0,size = 20),legend.position="none",title = element_text(size = 20))+
      ggtitle(paste(format(f[i],format="%a %m/%d/%y")))+
      theme(plot.title = element_text(hjust=0.5),legend.text = element_text(size = 30))


}
summary(p)
tiff('C:/Users/expeam/Documents/segment/2018/12-diciembre/analisis_hora_trx/promedio_dia_hora_dic_08_16.tiff', width = 55, height = 25, units = 'in', res = 100)
do.call(grid.arrange,p)
dev.off()


