library(prophet)
library(dplyr)
library(ROracle)
con <- dbConnect(Oracle(), user="expeam", password="!agosto2018", dbname="DWH/dwh_olap")
query <- dbSendQuery(con,"
                     
                      /*select sum(p.monto) as monto
                      ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha_datos
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2016-01-01' and date'2018-07-31'
                     and p.servicio in ('Giros Nacionales')
                      group by p.fecha_datos
                     order by 2*/



                    /*SELECT sum(t.monto) as monto
                     ,to_char(t.fecha,'YYYY-MM-DD') as fecha_datos
                     FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
                     LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON (T.PK_CATEGORIA=C.PK_CATEGORIA)
                     WHERE T.FECHA BETWEEN DATE'2016-01-01' AND DATE'2018-07-31'
                     AND T.SERVICE_ID = 2
                     AND T.RESULT = 0
                     AND T.TYPE_AUX=1
                     AND T.WALLET_TYPE_ID = 1
                    GROUP BY to_char(t.fecha,'YYYY-MM-DD')*/

                      select sum(p.monto) as monto
                      ,sum(p.cant_trx) as cant_trx
                     ,sum(p.monto)/count(distinct p.nro_cuenta) as ticket_cliente
                     ,sum(p.monto)/sum(p.cant_trx) as ticket_trx
                     ,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha
                     from tigo_cash_rpt.product_tracking p
                     where p.fecha_datos between date'2016-01-01' and date'2018-07-31'
                     AND p.categoria = 'Self Top Up'
                      --and p.subcategoria = 'OTC Payments'
                      --and p.servicio = 'Tigo TV'
                     group by to_char(p.fecha_datos,'YYYY-MM-DD')
                     order by 5
                     
                     

                     ")


result <- fetch(query)


df <- result


df$FECHA <- as.Date(df$FECHA, format = "%Y-%m-%d")
t<-df
##############
##############


str(t)
feriados <- data_frame(
  holiday = 'feriados',
  ds = as.Date(c('2016-01-01','2016-02-29','2016-03-24','2016-03-25','2016-03-26','2016-03-27'
                 ,'2016-05-01','2016-05-15','2016-06-12','2016-08-15','2016-10-03','2016-12-08'
                 ,'2016-12-25','2017-01-01','2017-02-27','2017-04-13','2017-04-14','2017-04-15'
                 ,'2017-04-16','2017-05-01','2017-05-14','2017-05-15','2017-06-12','2017-08-15'
                 ,'2017-10-02','2017-12-08','2017-12-25','2018-01-01','2018-02-26','2018-03-29'
                 ,'2018-03-30','2018-03-31','2018-04-01','2018-05-01','2018-05-14','2018-05-15'
                 ,'2018-06-11','2018-08-15','2018-09-29','2018-12-08','2018-12-25','2019-01-01'
                 ,'2019-03-04','2019-04-18','2019-04-19','2019-04-20','2019-04-21','2019-05-01'
                 ,'2019-05-14','2019-05-15','2019-06-10','2019-08-15','2019-09-29','2019-12-08'
                 ,'2019-12-25')),
  lower_window = 0,
  upper_window = 2
)


df<-t[,c("MONTO","FECHA")]

colnames(df)<-c("y","ds")
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality=TRUE,holidays = feriados,holidays.prior.scale = 0.05)
future <- make_future_dataframe(m, periods = 518)#+212
forecast <- predict(m, future)
plot(m, forecast)
write.table(subset(forecast[c("ds","yhat_upper","yhat", "yhat_lower")],as.numeric(as.Date(forecast$ds)) >= as.numeric(as.Date('2018-08-01'))),"C:/Users/expeam/Documents/segment/2018/agosto/budget/giros/forecast_self_top_up.csv",sep = ";",row.names = FALSE,col.names = TRUE)



df<-t[,c("cant_trx","fecha")]

colnames(df)<-c("y","ds")
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality=TRUE,holidays = feriados,holidays.prior.scale = 5)
future <- make_future_dataframe(m, periods = 518)#+212
forecast <- predict(m, future)
plot(m, forecast)
write.table(subset(forecast[c("ds","yhat_upper","yhat", "yhat_lower")],as.numeric(as.Date(forecast$ds)) >= as.numeric(as.Date('2018-08-01'))),"C:/Users/expeam/Documents/segment/2018/agosto/budget/giros/forecast_giros_cant_trx.csv",sep = ";",row.names = FALSE,col.names = TRUE)


df<-t[,c("ticket_trx","fecha")]

colnames(df)<-c("y","ds")
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality=TRUE,holidays = feriados)
future <- make_future_dataframe(m, periods = 518)#+212
forecast <- predict(m, future)
plot(m, forecast)
write.table(subset(forecast[c("ds","yhat_upper","yhat", "yhat_lower")],as.numeric(as.Date(forecast$ds)) >= as.numeric(as.Date('2018-08-01'))),"C:/Users/expeam/Documents/segment/2018/agosto/budget/giros/forecast_giros_ticket_trx.csv",sep = ";",row.names = FALSE,col.names = TRUE)


df<-t[,c("ticket_cliente","fecha")]


colnames(df)<-c("y","ds")
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality=TRUE,holidays = feriados)
future <- make_future_dataframe(m, periods = 518)#+212
forecast <- predict(m, future)
plot(m, forecast)
write.table(subset(forecast[c("ds","yhat_upper","yhat", "yhat_lower")],as.numeric(as.Date(forecast$ds)) >= as.numeric(as.Date('2018-08-01'))),"C:/Users/expeam/Documents/segment/2018/agosto/budget/giros/forecast_giros_ticket_cliente.csv",sep = ";",row.names = FALSE,col.names = TRUE)


