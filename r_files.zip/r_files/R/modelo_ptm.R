library(ROracle)
library(stats)
library(caTools)
library(Amelia)
library(dplyr)
library(tictoc)
con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")
query <- dbSendQuery(con,
                     "
                 select *  from expeam.tmp_base_pdv_ptm_pmodelo
                     
                     ")
dfa <- fetch(query)

df<-dfa
summary(df)
str(df)
table(df$ES_PTM)


df$ES_PTM<-as.factor(df$ES_PTM)


# tratamiento basico para bases
df<-na.omit(df)
df<-mutate_if(df,is.character,as.factor)
df.idpdv.sample <- sample(unique(df$ID_PDV),3000)
df<- subset(df,ID_PDV %in% df.idpdv.sample)


summary(df)
length(unique(df$ID_PDV))

table(df$ES_PTM)

#GENERAR MODELO
df <- select(df,c(-ID_PDV,-FECHA_CREACION))
set.seed(123)
sample <- sample.split(df$ES_PTM,SplitRatio=0.70)
trainData <- subset(df,sample==TRUE)
testData <- subset(df,sample==FALSE)
telecomModel <- glm(ES_PTM ~COMPRAS+ANTIGUEDAD_MESES+CATEGORIA+CANT_COMPRAS30+VENTA_MES+COMPRA_MES+VENTA_DOM+VENTA_LUN+VENTA_MAR+VENTA_MIE+VENTA_JUE+VENTA_VIE+VENTA_SAB+SEGMENTO_PDV,family=binomial(link="logit"),data=trainData)
print(summary(telecomModel))
test.predictions <- predict(telecomModel,newdata=testData,type="response")
fitted.results <- ifelse(test.predictions > 0.5,1,0)
testData$ES_PTM <- as.character(testData$ES_PTM)
testData$ES_PTM[testData$ES_PTM=="No"] <- "0"
testData$ES_PTM[testData$ES_PTM=="Yes"] <- "1"
misClasificationError <- mean(fitted.results!=testData$ES_PTM)
print(misClasificationError)
accuracyRate <- 1-misClasificationError
print(accuracyRate)

cm<-table(testData$ES_PTM,test.predictions > 0.5)
Accuracy <- print((cm[2,2]+cm[1,1])/sum(cm) * 100)
Sensitivity<-print(cm[2,2]/(cm[2,2]+cm[1,2])*100)
Specificity<-print(cm[1,1]/(cm[1,1]+cm[2,1])*100)


options(max.print=5000)
summary(telecomModel)

tic()
anova(telecomModel, test="Chisq")
toc()

library(pscl)
pR2(telecomModel)

library(ROCR)
#p <- predict(telecomModel, newdata=subset(test,select=c('COMPRAS','ANTIGUEDAD_MESES','CATEGORIA','CANT_COMPRAS30','VENTA_MES','COMPRA_MES','VENTA_DOM','VENTA_LUN','VENTA_MIE','VENTA_VIE','VENTA_SAB')), type="response")
pr <- prediction(test.predictions, testData$ES_PTM)
prf <- performance(pr, measure = "tpr", x.measure = "fpr")
plot(prf)

auc <- performance(pr, measure = "auc")
auc <- auc@y.values[[1]]
auc

