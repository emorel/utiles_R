dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 1'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )                     
                     
                     ")
arpu1 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 2'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu2 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 3'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu3 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 4'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu4 <- fetch(query)
toc()


dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 5'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu5 <- fetch(query)
toc()



dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 6'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu6 <- fetch(query)
toc()



dfa$cluster<-cl4.lab
base.insertar <-(subset(dfa,cluster == 'Cluster 7'))$DOCUMENT_NUMBER
rs <- dbSendQuery(con, "truncate table expeam.tmp_ci_app_ussd")
dbCommit(con)
rs <- dbSendQuery(con, "insert into expeam.tmp_ci_app_ussd values(to_number(:1))", data=base.insertar)
dbCommit(con)

tic()
query <- dbSendQuery(con,"
                     
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-01-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-02-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-03-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-04-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-05-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     union all
                     select
                     sum(p.revenue)/ count(distinct p.nro_cuenta)  as arpu
                     from expeam.product_tracking_rev_mensual p
                     where p.fecha_datos = last_day(date'2018-06-01')
                     and p.nro_cuenta in
                     (
                     
                     SELECT c.ar_sscrbr_dd
                     from expeam.tmp_ci_app_ussd b
                     join expeam.base_finan_7_10 c
                     on (b.document_number=c.ar_key)
                     
                     
                     )
                     
                     
                     ")
arpu7 <- fetch(query)
toc()
head(arpu1)
head(arpu2)
head(arpu3)
head(arpu4)
head(arpu5)
head(arpu6)
head(arpu7)