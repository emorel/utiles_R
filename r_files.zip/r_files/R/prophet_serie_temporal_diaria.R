
library(prophet)
library(dplyr)
library(bsts)
library(lubridate)
library(ROracle)



df<-as.data.frame(base_arpu_diario_cluster[,c(7,1)])
str(df)
colnames(df)<-c("y","ds")
#df$y<-as.Date(df$y, origin = lubridate::origin)
#str(df)
m <- prophet(df,weekly.seasonality = TRUE,daily.seasonality = TRUE)
future <- make_future_dataframe(m, periods = 60)
tail(future)
forecast <- predict(m, future)
#tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])
#plot(m, forecast)
#prophet_plot_components(m, forecast)
write.table(forecast$trend,"C:/Users/expeam/Documents/BI/2019/03-marzo/sombra_paquetes_1/trend.csv",row.names = FALSE,col.names = FALSE,sep = ";")
