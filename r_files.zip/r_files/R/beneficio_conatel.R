
library(reshape2)
library(knitr)
library(kableExtra)
library(htmltools)
library(dplyr)
library(tictoc)
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(gtable) 
library(ggfortify)
library(factoextra)
library(plotly)
library(gridExtra)
library(grid)
library(MatchIt)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2019", dbname="DWH/dwh_olap")


###############
####CONTROL###
###############

tic()
query <- dbSendQuery(con,"
                     
                     
                     
select *
from db_panza.prd_stg_lst_out_daily p
join expeam.tmp_base_benef_int_conatel_mor m
on (p.AR_KEY = m.ar_key)
where p.FCT_DT = date'2018-12-31'                     
                     
                     
                     ")
df_bkp <- fetch(query)
toc()
df_control<-df_bkp

length(unique(df_control$AR_KEY))
df_tg<-df_control

options(scipen=999)
breaks<-5
df_tg$DAYS_LAST_OUT_ANY_SGM<- cut( df_tg$DAYS_LAST_OUT_ANY, breaks = breaks,dig.lab=4,ordered_result = FALSE)

breaks<-data.frame(classIntervals(my_data$HS_SIN_SALDO,n=3)[2])[,1]
df_tg$HS_SIN_SALDO_sgm<- cut( df_tg$P, breaks = breaks,dig.lab=4,ordered_result = FALSE)

#CUT POR QUANTILES - PRETTY PRINT
a<-c(1,10,100,1000,100000,1000000)
my_data$HS_SIN_SALDO_SGM<-cut(my_data$HS_SIN_SALDO,breaks=data.frame(classIntervals(my_data$HS_SIN_SALDO,n=3)[2])[,1],include.lowest=T,dig.lab=10)
table(my_data$HS_SIN_SALDO_SGM)

df_tg[c(2,15)] %>%
  group_by(DAYS_LAST_OUT_ANY_SGM) %>%
  summarize (unique_types= n_distinct (AR_KEY))

summarize(df_tg[c(2,15)],AR_KEY,count)
