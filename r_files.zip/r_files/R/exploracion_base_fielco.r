
library(dplyr)    
library(tidyr)    
library(viridis)   
library(ggplot2)   
library(ggplot2)
library(tictoc)
library("PerformanceAnalytics")

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"

                      select *
                      from expeam.tmp_base_modelo_fielco_1


                     
                     
                     ")
t <- fetch(query)
#summary(t)
str(t)
length(unique(t$AR_KEY))

t<-subset(t,ANTIGUEDAD_MESES>=7 & REVENUE_PROM_4M >=30000 & EDAD >= 18)
length(unique(t$AR_KEY))

t$ESTADO<-as.factor(t$ESTADO)
t$TIPO_CUENTA_MODALIDAD<-as.factor(t$TIPO_CUENTA_MODALIDAD)
t$MODALIDAD_PAGO<-as.factor(t$MODALIDAD_PAGO)
t$DESCRIPCION_BILLING<-as.factor(t$DESCRIPCION_BILLING)
t$TIPO_PERSONA<-as.factor(t$TIPO_PERSONA)
t$COD_PLAN_CONSUMO<-as.factor(t$COD_PLAN_CONSUMO)
t$ESTADO_CIVIL<-as.factor(t$ESTADO_CIVIL)
t$SEXO<-as.factor(t$SEXO)
t$DEPARTAMENTO<-as.factor(t$DEPARTAMENTO)
t$DISTRITO<-as.factor(t$DISTRITO)
t$EDAD<-as.factor(t$EDAD)
t$MOROSO<-as.factor(t$MOROSO)
t$MOROSO<-ifelse(t$MOROSO=="SI",1,0)



t <- t[,c('REVENUE_PROM_4M','MOROSO')]


outlierKD(t, ANTIGUEDAD_MESES)
yes
t<-na.omit(t)
outlierKD(t, EDAD)
yes
t<-na.omit(t)
outlierKD(t, REVENUE_PROM_4M)
yes
t<-na.omit(t)
outlierKD(t, RECARGA_PROM_4M)
yes
t<-na.omit(t)

t$ANTIGUEDAD_MESES<-log(t$ANTIGUEDAD_MESES)
t$EDAD<-log(t$EDAD)
t$REVENUE_PROM_4M<-log(t$REVENUE_PROM_4M)
t$RECARGA_PROM_4M<-log(t$RECARGA_PROM_4M)


plot(t)

chart.Correlation(t, histogram=TRUE, pch=19)

write.csv(t,file = "customer_fielco_antiguedad_mes.csv")



t$revenue_rango<-cut(t$REVENUE_PROM_4M/1000, c(0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200))
t$recarga_rango<-cut(t$RECARGA_PROM_4M/1000, c(0,10,20,30,40,50,60,70,80,90,100,110,120,130,140,150,160,170,180,190,200))
t$edad_rango<-cut(t$EDAD, c(0,10,20,30,40,50,60,70,80,90,100))
t$antiguedad_rango<-cut(t$ANTIGUEDAD_CLIENTE, c(0,3,6,9,12,15,18,21,24,27,30))
t$antiguedad_mes_rango<-cut(t$ANTIGUEDAD_MESES, c(0,5,10,15,20,25,30,35,40,45,50,55,60,65,70,75,80,85,90,95,100,105,110,115,120,125,130,135,140,145,150,155,160))

par(mfrow=c(2,2)) 

bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=RECARGA_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity", alpha=.5)+
  #geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = 0,size=1) +
  #geom_text(aes(label = round((..count../sum(..count..))*100,0)))+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="RECARGA PROMEDIO (4M)")



bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=REVENUE_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity", alpha=.5)+
  #geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = 0,size=1) +
  #geom_text(aes(label = round((..count../sum(..count..))*100,0)))+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="REVENUE PROMEDIO (4M)")


bins <- c(0,10,20,30,40,50,60,70,80,90,100)
ggplot(t,aes(fill=MOROSO,x=EDAD,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=12))+
  ylab(label="PORCENTAJE")+
  xlab(label="EDAD")

bins <- c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30)
ggplot(t,aes(fill=MOROSO,x=ANTIGUEDAD_CLIENTE,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  ylab(label="PORCENTAJE")+
  xlab(label="ANTIGUEDAD_CLIENTE")


bins <- c(0,10000,20000,30000,40000,50000,60000,70000,80000,90000,100000,110000,120000,130000,140000,150000,160000,170000,180000,190000,200000)
ggplot(t,aes(fill=MOROSO,x=REVENUE_PROM_4M,y=(..count../sum(..count..))*100))+
  geom_histogram(breaks=bins,position="identity")+
  scale_y_continuous(breaks=scales::pretty_breaks(n=20))+
  scale_x_continuous(breaks=scales::pretty_breaks(n=20))+
  facet_wrap(~DEPARTAMENTO, scales = 'free_y', ncol = 2)+
  ylab(label="PORCENTAJE")+
  xlab(label="REVENUE_PROM_4M")


ggplot(t, aes(x=TOTAL_CARGA)) +
  theme_bw() +
  scale_x_continuous(breaks = pretty(t$TOTAL_CARGA, n = 10)) +
  geom_histogram(alpha=0.6, binwidth=2500) +
  ggtitle("Distribucion por TOTAL_CARGA")+
  theme(axis.text.x = element_text(angle=45))


basedate <- as.POSIXct(t$DIA,origin ="1582-10-14", tz = "GMT")
#tiff('C:/Users/edgar/Documents/analisis_envio/comparativo_var_envio_abandono_1.tiff', width = 35, height = 15, units = 'in', res = 300)
ggplot(t, aes(x=DIA,y=DATA )) +
  ggtitle("CORE Vs Envio")+
  geom_line()	+	
  scale_x_datetime(minor_breaks = basedate,breaks=pretty_breaks(n=30)) +
  facet_wrap(~TYPE+BASE, scales = 'free_y', ncol = 2)+
  theme(axis.text.x = element_text(angle=45))+
  geom_smooth(span=1)+geom_point(size=1/9)+theme(text = element_text(size=10),plot.title = element_text(hjust = 0.5))
#dev.off()




ggplot(t, aes(x= RECARGA_MENSUAL)) + 
  geom_bar(aes(y = ..prop.., fill = factor(..x..)), stat="count") +
  geom_text(aes( label = scales::percent(..prop..),y= ..prop.. ), stat= "count", vjust = -.5,size=1) +
  labs(y = "Percent", fill="day") +
  scale_y_continuous(labels = scales::percent)


ggplot(t, aes(x=RECARGA_MENSUAL,y=(..count../sum(..count..))*100, fill=MOROSO)) +
  geom_histogram(binwidth=10000, alpha=.5, position="identity")
