library(prophet)
library(dplyr)
library(bsts)
library(lubridate)
library(ROracle)

con <- dbConnect(Oracle(), user="expeam", password="!febrero2018", dbname="DWH/dwh_olap")

query <- dbSendQuery(con,"

	/*SELECT
	SUM(CASE WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'OTC Remittances'           THEN p.revenue/1.1
			  WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'P2P Remittances'           THEN p.revenue/1.1
			  WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'APP P2P Remittances'       THEN p.revenue/1.1
			  WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'P2P Envio'                 THEN p.revenue/1.1
			  WHEN p.categoria    = 'Remittances'          AND p.subcategoria = 'APP P2P Envio'             THEN p.revenue/1.1
			  WHEN p.categoria    = 'Salary Payment'       AND p.subcategoria = 'Salary Payment - Bulk'     THEN p.revenue/1.1
			  WHEN p.categoria    = 'Cash Out'             AND p.subcategoria = 'Cash Out'                  THEN p.revenue/1.1
			  WHEN p.categoria    = 'Cash Out'             AND p.subcategoria = 'Companion Card'            THEN p.revenue/1.1
			
	 ELSE p.monto*d.fee
	 END) AS monto
	 ,p.fecha_datos as fecha
	FROM
	( SELECT * FROM expeam.product_tracking_rev2 p
	  UNION ALL
	  SELECT * FROM expeam.product_tracking_rev2_o p
	) p
	JOIN expeam.product_daily_bdgt_fcst_v4 d
	ON (p.fecha_datos = d.fecha
	AND p.categoria= d.categoria
	AND p.subcategoria= d.subcategoria)
	WHERE p.fecha_datos BETWEEN DATE'2016-01-01' AND DATE'2018-01-31'
	AND p.categoria NOT IN ('Microcredits')
	--AND p.subcategoria NOT IN ('Error','Salary Payment')
	GROUP BY p.fecha_datos*/

/*SELECT
--sum(p.monto) as monto
sum(p.cant_trx) as monto
,to_char(p.fecha_datos,'YYYY-MM-DD') as fecha
FROM tigo_cash_rpt.product_tracking p
WHERE p.fecha_datos BETWEEN date'2015-01-01' AND date'2018-01-31'
--and p.servicio in ('Ande','Ande-NV','Chacomer','Electroban','FPUNA','Fundacion Pya.','Inverfin','La Red','Pago de Servicios')
and p.servicio in ('Ande','Ande-NV')
--and p.servicio in ('Pago de Servicios')
--and p.servicio in ('Chacomer','Electroban','FPUNA','Fundacion Pya.','Inverfin','La Red')
--and p.categoria = 'Self Top Up'
group by to_char(p.fecha_datos,'YYYY-MM-DD')*/
	
/*SELECT v.cantidad
,to_char(v.fecha_datos,'YYYY-MM-DD') as fecha
from expeam.res_base_mfs_dai_cat_ci_60 v
where v.fecha_datos BETWEEN date'2015-01-01' AND date'2018-01-31'
AND v.categoria IN ('Merchant Payments')
AND v.disconnects_indicator = 'Begining Day'*/

/*SELECT v.cantidad_num
,to_char(v.fechadatos_dat,'YYYY-MM-DD') as fecha
from expeam.res_base_mfs_dai_ci_60_menu v
where v.fechadatos_dat BETWEEN date'2015-01-01' AND TRUNC(SYSDATE-1)
AND v.indicator_chr = 'Begining Day'
order by 2*/

/*with
pt as
(
SELECT sum(p.monto) as monto
,p.fecha_datos as fecha
FROM tigo_cash_rpt.product_tracking p
WHERE p.fecha_datos BETWEEN date'2016-01-01' AND date'2018-01-31'
and p.categoria = 'Merchant Payments'
group by p.fecha_datos
)
,base as
(
SELECT v.cantidad
,v.fecha_datos as fecha
from expeam.res_base_mfs_dai_cat_ci_60 v
where v.fecha_datos BETWEEN date'2016-01-01'-60 AND date'2018-01-31'
AND v.categoria = 'Merchant Payments'
AND v.disconnects_indicator = 'Begining Day'
)
select pt.monto/base.cantidad as MONTO
,to_char(pt.fecha,'YYYY-MM-DD') as fecha
from pt
join base on
(pt.fecha=base.fecha)
order by 1*/

                     
SELECT SUM(T.MONTO) AS MONTO
,to_char(t.fecha,'YYYY-MM-DD') as fecha
FROM TIGO_CASH_RPT.BASE_MFS_DET_TRX T
LEFT JOIN RPL_TIGO_CASH.SERVICE S ON(T.SERVICE_ID=S.SERVICE_ID)
LEFT JOIN TIGO_CASH_RPT.BASE_MFS_CATEGORIA C ON(T.PK_CATEGORIA=C.PK_CATEGORIA)
WHERE T.FECHA BETWEEN DATE'2016-01-01' AND DATE'2017-12-31'
AND NOT(T.SERVICE_ID IN(4,36,46,401,402) AND T.TYPE_AUX=2)
AND T.RESULT =0
--and c.servicio in ('Ande','Ande-NV','Chacomer','Chacomer-NV','Electroban','Electroban-NV','FPUNA','Fundacion Pya.','Fundacion Pya-NV','Inverfin','La Red','La Red-NV','Pago de Servicios')
and c.servicio in ('Ande')
GROUP BY to_char(t.fecha,'YYYY-MM-DD')

")


result <- fetch(query)


df <- result

df$FECHA <- as.Date(df$FECHA, format = "%Y-%m-%d")

outlierKD(df, MONTO)
yes
#df<-na.omit(df)

outlierKD(df, MONTO)
yes
#df<-na.omit(df)


colnames(df)<-c("y","ds")

library(dplyr)
playoffs <- data_frame(
  holiday = 'feriados',
  ds = as.Date(c('2016-01-01', '2016-02-29','2016-03-24', '2016-03-25', '2016-05-01','2016-05-14','2016-05-15','2016-06-12','2016-08-15','2016-10-03','2016-12-08','2016-12-25',
                 '2017-01-01', '2017-02-27','2017-04-13', '2017-04-14','2017-05-01','2017-05-14','2017-05-15','2017-06-12','2017-08-14','2017-10-02','2017-12-08','2017-12-25',
                 '2018-01-01', '2018-02-26','2018-03-24', '2018-03-25', '2018-05-01','2018-05-14','2018-05-15','2018-06-11','2018-08-15','2018-10-03','2018-12-08','2018-12-25')),
  lower_window = 0,
  upper_window = 1
)
holidays <- bind_rows(playoffs)
m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE,daily.seasonality = TRUE, holidays = holidays,seasonality.prior.scale = 200)
#m <- prophet(df,yearly.seasonality = TRUE)
#m <- prophet(df,seasonality.prior.scale = 20,changepoint.prior.scale = 0.001)
#m <- prophet()
#m <- add_seasonality(  m, name='weekly', period=7, fourier.order=3, prior.scale=150)



#Daily
future <- make_future_dataframe(m, periods = 334)
tail(future)
#Monthly
#future <- make_future_dataframe(m, periods = 12, freq = 'month')
#tail(future)


##OUTLIERS
# outliers <- (as.Date(df$ds) > as.Date('2015-01-01')
#             & as.Date(df$ds) < as.Date('2016-01-31'))



#df$y[outliers] = NA
#m <- prophet(df,yearly.seasonality = TRUE,weekly.seasonality = TRUE)
#m <- prophet(df)



forecast <- predict(m, future)
tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

#prophet_plot_components(m, forecast)
plot(m, forecast)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
##definimos las fechas para el subset
#sf <- c(as.Date('2017-04-01', format = "%Y-%m-%d"),as.Date('2017-04-08', format = "%Y-%m-%d"))
#i <- as.Date('2017-04-15', format = "%Y-%m-%d")
#while (i<=Sys.Date()+28){
#	sf <- append(sf,i)
#	i<-i+7
#}
#solo seleccionamos las fechas del reporte del comite
##cada 7 dias
#subset(forecast[c("ds","yhat")],forecast$ds %in% sf)
#write.csv(subset(forecast[c("ds","yhat")],forecast$ds %in% sf),"forecast_merchant_payment.csv")

df_month<-forecast %>% group_by(month=floor_date(ds,'month')) %>%  summarize(amount=sum(yhat))


# df_month<-data.frame(
# "FECHA"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,as.character(as.Date(forecast$ds, format = "%Y-%m-%d")),NA)
# ,"DATO"=ifelse(forecast$ds==LastDayInMonth(forecast$ds) ,forecast$yhat,NA)
# )
# df_month<-na.omit(df_month)
# df_month<-as.data.frame(df_month)

#write.csv(df_month,"forecast_1.csv",row.names=FALSE)
write.table(df_month,file="forecast_1.csv",sep=";",row.names = FALSE)
write.table(forecast[c("ds","yhat")],file="forecast_1.csv",sep=";",row.names = FALSE)
#write.csv(forecast[c("ds","yhat")],"forecast_1.csv")

