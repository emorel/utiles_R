options(repos = c(CRAN = "http://cran.rstudio.com"))
library(ggplot2)
library(plyr)
library(scales)

kmeans_data<-df[c(2,7)]
kmeans_data<-scale(kmeans_data)
ingresos_clusters <- kmeans(kmeans_data, 3)

ggplot(df, aes(total_ingreso_mensual, a�os_de_estudio, color = as.factor(ingresos_clusters$cluster))) + 
  geom_point() + 
  labs(title= "Clusters de Ingreso por Unidad Familiar"
       ,subtitle = "(USD)"
       ,caption = "Fuente: Direccion general de Estadisticas, Encuestas y Censos - Encuesta Permanente de Hogares - Paraguay 2018"
       ,x = "Ingreso por actividad principal"
       ,y="Ingreso per c�pita mensual") +
  labs(color='Clusters') +
  scale_color_brewer(palette = "Dark2")+
  scale_x_continuous(labels = comma) +
  scale_y_continuous(labels = comma) +
  theme(plot.title = element_text(hjust = 0.5)
        ,plot.subtitle = element_text(hjust = 0.5))

########################
### outlier detection
######################
kmeans_data<-df[c(2,7)]
kmeans.result <- kmeans(kmeans_data, centers=5)
kmeans.result$centers
kmeans.result$cluster

centers <- kmeans.result$centers[kmeans.result$cluster, ] # "centers" is a data frame of 3 centers but the length of iris dataset so we can canlculate distance difference easily.

distances <- sqrt(rowSums((kmeans_data - centers)^2))

outliers <- order(distances, decreasing=T)[1:5]

print(outliers) # these rows are 5 top outliers

print(kmeans_data[outliers,])


plot(kmeans_data[,c("a�os_de_estudio", "total_ingreso_mensual")], pch=19, col=kmeans.result$cluster, cex=1)

points(kmeans.result$centers[,c("a�os_de_estudio", "total_ingreso_mensual")], col=1:3, pch=15, cex=2)

points(kmeans_data[outliers, c("a�os_de_estudio", "total_ingreso_mensual")], pch="+", col=4, cex=3)




for (i in 1:500) {
  ###########################
  ## excluimos los outliers##
  ###########################
  
  
  kmeans_data<-kmeans_data[-outliers,]
  
  
  kmeans.result <- kmeans(kmeans_data, centers=5)
  kmeans.result$centers
  kmeans.result$cluster
  
  centers <- kmeans.result$centers[kmeans.result$cluster, ] # "centers" is a data frame of 3 centers but the length of iris dataset so we can canlculate distance difference easily.
  
  distances <- sqrt(rowSums((kmeans_data - centers)^2))
  
  outliers <- order(distances, decreasing=T)[1:5]
  
  #print(outliers) # these rows are 5 top outliers
  
  #print(kmeans_data[outliers,])
  
  
  #plot(kmeans_data[,c("a�os_de_estudio", "total_ingreso_mensual")], pch=19, col=kmeans.result$cluster, cex=1)
  
  #points(kmeans.result$centers[,c("a�os_de_estudio", "total_ingreso_mensual")], col=1:3, pch=15, cex=2)
  
  #points(kmeans_data[outliers, c("a�os_de_estudio", "total_ingreso_mensual")], pch="+", col=4, cex=3)
  
}


plot(kmeans_data[,c("a�os_de_estudio", "total_ingreso_mensual")], pch=19, col=kmeans.result$cluster, cex=1)

points(kmeans.result$centers[,c("a�os_de_estudio", "total_ingreso_mensual")], col=1:5, pch=15, cex=2)

points(kmeans_data[outliers, c("a�os_de_estudio", "total_ingreso_mensual")], pch="+", col=4, cex=3)
